﻿using System;
using System.Collections.Generic;
using System.Text;

namespace uni2uni.com.MotoLibrary
{
    public class MotoResultModel
    {
        private string result;
        /// <summary>
        /// 返回码result：0可以成功查询到此交易；以”E”开头的错误代号，则说明查询失败
        /// </summary>
        public string Result
        {
            get { return result; }
            set { result = value; }
        }

        private int authid;
        /// <summary>
        /// 银行授权号
        /// </summary>
        public int Authid
        {
            get { return authid; }
            set { authid = value; }
        }

        private int _amount;
        /// <summary>
        /// 金额_amount: 交易金额，以分为单位
        /// </summary>
        public int Amount
        {
            get { return _amount; }
            set { _amount = value; }
        }

        private int _cardname;
        /// <summary>
        /// 卡类型_cardname: 交易银行卡类型
        /// </summary>
        public int CardName
        {
            get { return _cardname; }
            set { _cardname = value; }
        }

        private string _state;
        /// <summary>
        /// 交易状态_state：返回中文，可能的返回值有成功，撤销，确认预授权，退款，部分退款，冲正，处理中
        /// </summary>
        public string State
        {
            get { return _state; }
            set { _state = value; }
        }

        private int _statecode;
        /// <summary>
        /// 交易状态码 _statecode:返回数字码 ，和交易状态中文返回一一对应详见附录
        /// </summary>
        public int StateCode
        {
            get { return _statecode; }
            set { _statecode = value; }
        }

        private string _code;
        /// <summary>
        /// 交易返回码_code：可能的值是0000和以”E”开头的错误代码，分别说明最初交易成功，失败编号
        /// </summary>
        public string Code
        {
            get { return _code; }
            set { _code = value; }
        }

        private int _bankname;
        /// <summary>
        /// 银行类型_bankname：交易卡的银行类型
        /// </summary>
        public int BankName
        {
            get { return _bankname; }
            set { _bankname = value; }
        }

        private string _card;
        /// <summary>
        /// 卡号_card: 交易卡号 如4380****0852
        /// </summary>
        public string Card
        {
            get { return _card; }
            set { _card = value; }
        }

        private string _oid;
        /// <summary>
        /// 交易号_oid：商户交易号
        /// </summary>
        public string Oid
        {
            get { return _oid; }
            set { _oid = value; }
        }

        private string _aid;
        /// <summary>
        /// 授权号_aid：银行给的授权号
        /// </summary>
        public string Aid
        {
            get { return _aid; }
            set { _aid = value; }
        }

        private DateTime _date;
        /// <summary>
        /// 交易日期_date：交易日期 如2007-03-19 10:50:25
        /// </summary>
        public DateTime Date
        {
            get { return _date; }
            set { _date = value; }
        }

        private string _type;
        /// <summary>
        /// 交易类型_type ：可能的值有消费，撤销消费，预授权，撤销预授权，确认预授权，撤销确认预授权，退款，冲正
        /// </summary>
        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }

        private int _typecode;
        /// <summary>
        /// 交易类型码_typecode:返回数字码，与交易类型中文一一对应，详见附录
        /// </summary>
        public int TypeCode
        {
            get { return _typecode; }
            set { _typecode = value; }
        }

        private int _settle;
        /// <summary>
        /// 结算标识 _settle:是否结算，判断退款还是撤销交易的标识，注意只有消费成功，确认成功和退款成功的交易参与结算
        /// </summary>
        public int Settle
        {
            get { return _settle; }
            set { _settle = value; }
        }
    }
}
