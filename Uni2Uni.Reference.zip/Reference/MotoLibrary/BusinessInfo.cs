﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace uni2uni.com.MotoLibrary
{
    public class BusinessInfo
    {
        #region
        public static IDictionary BusinessCode = new Dictionary<string, string>();

        public static IDictionary BankCode = new Dictionary<string, string>();

        public static IDictionary CardCode = new Dictionary<string, string>();

        public static IDictionary BusinessTypeCode = new Dictionary<string, string>();

        public static IDictionary BusinessStateCode = new Dictionary<string, string>();

        public static IDictionary BalanceCode = new Dictionary<string, string>();

        private static readonly BusinessInfo bInfo = new BusinessInfo();
        #endregion

        #region
        private BusinessInfo()
        {
            BusinessCode = BusinessCodeInit();
            BankCode = BankCodeInit();
            CardCode = CardCodeInit();
            BusinessTypeCode = BusinessTypeCodeInit();
            BusinessStateCode = BusinessStateCodeInit();
            BalanceCode = BalanceCodeInit();
        }

        public static BusinessInfo Instance()
        {
            return bInfo;
        }

        private static IDictionary BusinessCodeInit()
        {
            IDictionary Idc = new Dictionary<string, string>();

            #region
            Idc.Add("0", "交易成功");
            Idc.Add("1", "交易处理中");
            Idc.Add("E12041000", "交易失败");
            Idc.Add("E12041001", "内部错误");
            Idc.Add("E12041002", "通讯错误");
            Idc.Add("E12041003", "数据库错误");
            Idc.Add("E12041004", "安全验证失败");
            Idc.Add("E12041005", "交易号格式错误");
            Idc.Add("E12041006", "信用卡格式错误");
            Idc.Add("E12041007", "信用卡有效期格式错误");
            Idc.Add("E12041008", "交易金额格式错误");
            Idc.Add("E12041009", "持卡人姓名格式错误");
            Idc.Add("E12041010", "持卡人证件格式错误");
            Idc.Add("E12041011", "持卡人电话格式错误");
            Idc.Add("E12041012", "备注格式错误");
            Idc.Add("E12041013", "商户号错误");
            Idc.Add("E12041014", "终端号错误");
            Idc.Add("E12041015", "商户信息不完整");
            Idc.Add("E12041016", "终端没有消费权限");
            Idc.Add("E12041017", "终端没有撤销消费权限");
            Idc.Add("E12041018", "终端没有预授权权限");
            Idc.Add("E12041019", "终端没有撤销预授权权限");
            Idc.Add("E12041020", "终端没有预授权确认权限");
            Idc.Add("E12041021", "终端没有撤销预授权确认权限");
            Idc.Add("E12041022", "终端没有退款权限");
            Idc.Add("E12041023", "超出单笔交易限额");
            Idc.Add("E12041024", "MOTO不支持此信用卡");
            Idc.Add("E12041025", "商户不支持此信用卡");
            Idc.Add("E12041026", "信用卡日交易次数限制");
            Idc.Add("E12041027", "信用卡日交易有效期错误次数限制");
            Idc.Add("E12041028", "信用卡日交易金额上限错误次数限制");
            Idc.Add("E12041029", "超出日交易限额");
            Idc.Add("E12041030", "商户交易号重复");
            Idc.Add("E12041031", "原交易不存在");
            Idc.Add("E12041032", "信用卡原交易不符");
            Idc.Add("E12041033", "金额原交易不符");
            Idc.Add("E12041034", "原交易不允许此操作");
            Idc.Add("E12041035", "原交易不存在");
            Idc.Add("E12041036", "超出预授权金额浮动范围");
            Idc.Add("E12041037", "退款金额不正确");
            Idc.Add("E12041038", "查询无此交易");
            Idc.Add("E12041039", "无此交易查询权限");
            Idc.Add("E12041040", "交易成功,更新失败。交易状态更新中......");
            Idc.Add("E12041041", "终端接入方式错误");
            Idc.Add("E12041042", "此卡不允许做此交易");
            Idc.Add("E12041043", "持卡人邮件格式不正确");
            Idc.Add("E12041044", "客户端版本号不正确");
            Idc.Add("E12041045", "CVV2不允许为空");
            Idc.Add("E12041046", "IP校检失败");
            Idc.Add("E12041047", "此卡为风险卡");
            Idc.Add("E12041048", "交易速度过快");
            Idc.Add("E12042000", "银行不允许此交易");
            Idc.Add("E12042001", "请与信用卡中心联系");
            Idc.Add("E12042002", "查询发卡行");
            Idc.Add("E12042003", "无效特约商户");
            Idc.Add("E12042004", "没收卡");
            Idc.Add("E12042005", "不批准交易");
            Idc.Add("E12042006", "交易已冲正");
            Idc.Add("E12042007", "特殊条件下没收卡");
            Idc.Add("E12042008", "联系卡中心");
            Idc.Add("E12042009", "正在处理请求");
            Idc.Add("E12042010", "无效交易");
            Idc.Add("E12042011", "无效金额");
            Idc.Add("E12042012", "无效卡号");
            Idc.Add("E12042013", "无此发卡行");
            Idc.Add("E12042014", "请重做交易");
            Idc.Add("E12042015", "无效应答");
            Idc.Add("E12042016", "不做任何处理");
            Idc.Add("E12042017", "怀疑操作有误");
            Idc.Add("E12042018", "不可接受的交易费");
            Idc.Add("E12042019", "无此交易");
            Idc.Add("E12042020", "格式错误");
            Idc.Add("E12042021", "该发卡银行未开通");
            Idc.Add("E12042022", "有效期错误");
            Idc.Add("E12042023", "有作弊嫌疑");
            Idc.Add("E12042024", "联系保安");
            Idc.Add("E12042025", "受限制的卡");
            Idc.Add("E12042026", "联系卡中心");
            Idc.Add("E12042027", "PIN输入超次");
            Idc.Add("E12042028", "无此信用卡账户");
            Idc.Add("E12042029", "非法功能");
            Idc.Add("E12042030", "挂失卡");
            Idc.Add("E12042031", "无此账户");
            Idc.Add("E12042032", "被窃卡");
            Idc.Add("E12042033", "无此投资账户");
            Idc.Add("E12042034", "余额不足或透支");
            Idc.Add("E12042035", "无此支票账户");
            Idc.Add("E12042036", "无此储蓄卡账户");
            Idc.Add("E12042037", "过期卡");
            Idc.Add("E12042038", "重输个人密码");
            Idc.Add("E12042039", "无此卡记录");
            Idc.Add("E12042040", "非法交易");
            Idc.Add("E12042041", "非法交易");
            Idc.Add("E12042042", "有作弊嫌疑");
            Idc.Add("E12042043", "请与信用卡中心联系");
            Idc.Add("E12042044", "超出取款限额");
            Idc.Add("E12042045", "受限制卡");
            Idc.Add("E12042046", "违反安全保密规定");
            Idc.Add("E12042047", "无效原金额");
            Idc.Add("E12042048", "取款次数超过次数");
            Idc.Add("E12042049", "请与信用卡中心联");
            Idc.Add("E12042050", "捕捉");
            Idc.Add("E12042051", "主机轧帐稍候工作");
            Idc.Add("E12042052", "PIN输入超过次数");
            Idc.Add("E12042053", "非法操作员");
            Idc.Add("E12042054", "结算不平");
            Idc.Add("E12042055", "止付卡");
            Idc.Add("E12042056", "交易拒绝");
            Idc.Add("E12042057", "卡已作废");
            Idc.Add("E12042058", "联网暂断");
            Idc.Add("E12042059", "非法终端号");
            Idc.Add("E12042060", "主机轧帐稍候工作");
            Idc.Add("E12042061", "交易超时");
            Idc.Add("E12042062", "重做交易");
            Idc.Add("E12042063", "交易违法");
            Idc.Add("E12042064", "重复交易");
            Idc.Add("E12042065", "结算不平");
            Idc.Add("E12042066", "系统异常");
            Idc.Add("E12042067", "终端号错");
            Idc.Add("E12042068", "暂与发卡行失去联系");
            Idc.Add("E12042069", "PIN格式错");
            #endregion

            return Idc;
        }

        private static IDictionary BankCodeInit()
        {
            IDictionary Idc = new Dictionary<string, string>();

            #region
            Idc.Add("01", "人行");
            Idc.Add("02", "工商银行");
            Idc.Add("03", "农业银行");
            Idc.Add("04", "中国银行");
            Idc.Add("05", "建设银行");
            Idc.Add("06", "交通银行");
            Idc.Add("07", "民生银行");
            Idc.Add("08", "华夏银行");
            Idc.Add("09", "广东发展银行");
            Idc.Add("10", "国家邮政");
            Idc.Add("11", "邮政储蓄");
            Idc.Add("12", "中兴实业银行");
            Idc.Add("13", "光大银行");
            Idc.Add("14", "招商银行");
            Idc.Add("15", "深圳发展银行");
            Idc.Add("16", "商业银行");
            Idc.Add("17", "兴业银行");
            Idc.Add("18", "北京银行");
            Idc.Add("19", "上海银行");
            Idc.Add("20", "浦东发展银行");
            Idc.Add("21", "集友银行");
            Idc.Add("22", "农信类");
            Idc.Add("23", "恒丰银行");
            Idc.Add("24", "汇丰银行");
            Idc.Add("25", "东亚银行");
            Idc.Add("26", "花旗银行");
            Idc.Add("27", "大新银行");
            Idc.Add("28", "恒生银行");
            Idc.Add("29", "美国银行");
            Idc.Add("30", "永隆银行");
            Idc.Add("31", "中信嘉华银行");
            Idc.Add("33", "星展银行");
            Idc.Add("34", "浙商银行");
            Idc.Add("35", "Travelx");
            Idc.Add("36", "渤海银行");
            Idc.Add("37", "廖创兴银行");
            Idc.Add("38", "永亨银行");
            Idc.Add("39", "商行类");
            Idc.Add("40", "中信银行");
            Idc.Add("51", "威士卡");
            Idc.Add("52", "万事达卡");
            Idc.Add("53", "运通卡");
            Idc.Add("54", "大莱卡");
            Idc.Add("55", "JCB");
            #endregion

            return Idc;
        }

        private static IDictionary CardCodeInit()
        {
            IDictionary Idc = new Dictionary<string, string>();
            
            #region
            Idc.Add("01", "信用卡");
            Idc.Add("02", "借记卡");
            Idc.Add("03", "贷记卡");
            Idc.Add("51", "威士卡");
            Idc.Add("52", "万事达卡");
            Idc.Add("53", "运通卡");
            Idc.Add("54", "大莱卡");
            Idc.Add("55", "JCB卡");
            #endregion

            return Idc;
        }

        private static IDictionary BusinessTypeCodeInit()
        {
            IDictionary Idc = new Dictionary<string, string>();

            #region
            Idc.Add("1", "消费");
            Idc.Add("2", "撤销消费");
            Idc.Add("3", "预授权");
            Idc.Add("4", "撤销预授权");
            Idc.Add("5", "确认");
            Idc.Add("6", "撤销确认");
            Idc.Add("7", "退款");
            Idc.Add("8", "冲正");
            #endregion

            return Idc;
        }

        private static IDictionary BusinessStateCodeInit()
        {
            IDictionary Idc = new Dictionary<string, string>();

            #region
            Idc.Add("0", "成功");
            Idc.Add("1", "撤销");
            Idc.Add("2", "确认");
            Idc.Add("3", "退款");
            Idc.Add("4", "部分退款");
            Idc.Add("5", "冲正");
            Idc.Add("6", "处理中");
            Idc.Add("7", "失败");
            #endregion

            return Idc;
        }

        private static IDictionary BalanceCodeInit()
        {
            IDictionary Idc = new Dictionary<string, string>();

            #region
            Idc.Add("0", "未结算");
            Idc.Add("1", "已结算");
            Idc.Add("", "未结算，处理中或失败的订单");
            #endregion

            return Idc;
        }
        #endregion

        #region code 交易号

        public string GeCodeByID(string ID,IDictionary Idc)
        {
            string ReturnStrValue = string.Empty;
            if (Idc.Contains(ID)) ReturnStrValue = Idc[ID].ToString();
            return ReturnStrValue;
        }
        #endregion

    }
}
