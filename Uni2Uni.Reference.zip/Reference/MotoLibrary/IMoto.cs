﻿/*----------------------------------------------------------------
// Copyright (C) 2009 北京时空信联网络技术有限公司版权所有。 
//
//  文 件 名：IMoto
//  功能描述：接口IMoto
//
//	 
//  创建时间：2009-03-17
//  创 建 人：黄炜
//  部    门：技术部
//  职    务：
//
//----------------------------------------------------------------*/


using System;
using System.Collections.Generic;
using System.Text;


using com.chinabank.gw.result;
using System.Collections;

namespace uni2uni.com.MotoLibrary
{
    public interface IMoto
    {
        string MotoDispose(MotoType motoType, MotoModel motoModel);
    }

}
