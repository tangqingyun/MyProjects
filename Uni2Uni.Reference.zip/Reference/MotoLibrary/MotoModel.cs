﻿/*----------------------------------------------------------------
// Copyright (C) 2009 北京时空信联网络技术有限公司版权所有。 
//
//  文 件 名：MotoModel
//  功能描述：Moto执行方法参数实体
//
//	 
//  创建时间：2009-03-17
//  创 建 人：黄炜
//  部    门：技术部
//  职    务：
//
//----------------------------------------------------------------*/


using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace uni2uni.com.MotoLibrary
{
    /// <summary>
    /// Moto执行方法参数实体
    /// </summary>
    public class MotoModel
    {
        string merchant = "20340465";//"1000";
        /// <summary>
        /// 商户号
        /// </summary>
        public string Merchant
        {
            get { return merchant; }
            //set { merchant = value; }
        }
        string terminal = "00000001";
        /// <summary>
        /// 终端号
        /// </summary>
        public string Terminal
        {
            get { return terminal; }
            //set { terminal = value; }
        }
        string orderid;
        /// <summary>
        /// 交易号
        /// </summary>
        public string Orderid
        {
            get { return orderid; }
            set { orderid = value; }
        }
        string oldid;
        /// <summary>
        /// 原交易号
        /// </summary>
        public string Oldid
        {
            get { return oldid; }
            set { oldid = value; }
        }
        string card;
        /// <summary>
        /// 信用卡号
        /// </summary>
        public string Card
        {
            get { return card; }
            set { card = value; }
        }
        string cardexp;
        /// <summary>
        /// 信用卡有效期（YYMM）
        /// </summary>
        public string Cardexp
        {
            get { return cardexp; }
            set { cardexp = value; }
        }
        int amount;
        /// <summary>
        /// 消费金额（人民币分）
        /// </summary>
        public int Amount
        {
            get { return amount; }
            set { amount = value; }
        }
        DateTime date = DateTime.Now;
        /// <summary>
        /// 交易时间
        /// </summary>
        public DateTime Date
        {
            get { return date; }
            //set { date = value; }
        }
        IDictionary extend;
        /// <summary>
        /// 扩展参数
        /// </summary>
        public IDictionary Extend
        {
            get { return extend; }
            set { extend = value; }
        }
        string version = "3.0(C#)";
        /// <summary>
        /// 客户端版本
        /// </summary>
        public string Version
        {
            get { return version; }
            //set { version = value; }
        }
    }
}
