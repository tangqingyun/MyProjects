﻿/*----------------------------------------------------------------
// Copyright (C) 2009 北京时空信联网络技术有限公司版权所有。 
//
//  文 件 名：Moto
//  功能描述：实现接口IMoto
//
//	 
//  创建时间：2009-03-17
//  创 建 人：黄炜
//  部    门：技术部
//  职    务：
//
//----------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using com.chinabank.gw.result;
using com.chinabank.moto;
using com.chinabank.moto.win32;
using uni2uni.com.Framework.Common;
using System.Collections;

namespace uni2uni.com.MotoLibrary
{
    public class Moto : IMoto
    {
        MOTOService2 service = ServiceFactory.getService();

        #region IMoto 成员

        public string MotoDispose(MotoType motoType, MotoModel motoModel)
        {
            CBResult result = null;
            switch (motoType)
            {
                case MotoType.anthorize:
                    result = service.authorize(motoModel.Merchant, motoModel.Terminal, motoModel.Orderid, motoModel.Card, motoModel.Cardexp, motoModel.Amount, motoModel.Date, motoModel.Extend, motoModel.Version);
                    break;
                case MotoType.authorizeRevoke:
                    result = service.authorizeRevoke(motoModel.Merchant, motoModel.Terminal, motoModel.Orderid, motoModel.Oldid, motoModel.Card, motoModel.Cardexp, motoModel.Amount, motoModel.Date, motoModel.Extend, motoModel.Version);
                    break;
                case MotoType.confirm:
                    result = service.confirm(motoModel.Merchant, motoModel.Terminal, motoModel.Orderid, motoModel.Oldid, motoModel.Card, motoModel.Cardexp, motoModel.Amount, motoModel.Date, motoModel.Extend, motoModel.Version);
                    break;
                case MotoType.confirmRevoke:
                    result = service.confirmRevoke(motoModel.Merchant,motoModel.Terminal,motoModel.Orderid,motoModel.Oldid,motoModel.Card,motoModel.Cardexp,motoModel.Amount,motoModel.Date,motoModel.Extend,motoModel.Version);
                    break;
                case MotoType.consume:
                    result = service.consume(motoModel.Merchant, motoModel.Terminal, motoModel.Orderid, motoModel.Card, motoModel.Cardexp, motoModel.Amount, motoModel.Date, motoModel.Extend, motoModel.Version);
                    break;
                case MotoType.consumeRevoke:
                    result = service.consumeRevoke(motoModel.Merchant, motoModel.Terminal, motoModel.Orderid, motoModel.Oldid, motoModel.Card, motoModel.Cardexp, motoModel.Amount, motoModel.Date, motoModel.Extend, motoModel.Version);
                    break;
                case MotoType.refund:
                    result = service.refund(motoModel.Merchant, motoModel.Terminal, motoModel.Orderid, motoModel.Oldid, motoModel.Card, motoModel.Cardexp, motoModel.Amount, motoModel.Date, motoModel.Extend, motoModel.Version);
                    break;
                case MotoType.reverse:
                    result = service.reverse(motoModel.Merchant, motoModel.Terminal, motoModel.Orderid);
                    break;
                case MotoType.search:
                    result = service.search(motoModel.Merchant, motoModel.Terminal, motoModel.Orderid);
                    break;
                case MotoType.searchCard:
                    result = service.searchCard(motoModel.Merchant, motoModel.Card);
                    break;
                default:
                    break;
            }
            StringBuilder StrTemp = new StringBuilder();
            StrTemp.Append("---------------------------------------------------------------------------------------------------------------\n");
            StrTemp.Append("result: " + result.getRtcode() + "=" + BusinessInfo.Instance().GeCodeByID(result.getRtcode(), BusinessInfo.BusinessCode) + "\n");
            IDictionary extend = result.getMap();
            foreach (DictionaryEntry de in extend)
            {
                switch (de.Key.ToString())
                {
                    case "cardname":
                        StrTemp.Append(string.Format("Key -- {0}; Value -- {1}; Name --{2}.", de.Key, de.Value, BusinessInfo.Instance().GeCodeByID(de.Value.ToString(), BusinessInfo.CardCode)) + "\n");
                        break;
                    case "bankname":
                        StrTemp.Append(string.Format("Key -- {0}; Value -- {1}; Name --{2}.", de.Key, de.Value, BusinessInfo.Instance().GeCodeByID(de.Value.ToString(), BusinessInfo.BankCode)) + "\n");
                        break;
                    case "type":
                        StrTemp.Append(string.Format("Key -- {0}; Value -- {1}; Name --{2}.", de.Key, de.Value, BusinessInfo.Instance().GeCodeByID(de.Value.ToString(), BusinessInfo.BusinessStateCode)) + "\n");
                        break;
                    case "typecode":
                        StrTemp.Append(string.Format("Key -- {0}; Value -- {1}; Name --{2}.", de.Key, de.Value, BusinessInfo.Instance().GeCodeByID(de.Value.ToString(), BusinessInfo.BusinessCode)) + "\n");
                        break;
                    case "settle":
                        StrTemp.Append(string.Format("Key -- {0}; Value -- {1}; Name --{2}.", de.Key, de.Value, BusinessInfo.Instance().GeCodeByID(de.Value.ToString(), BusinessInfo.BalanceCode)) + "\n");
                        break;
                    case "statecode":
                        StrTemp.Append(string.Format("Key -- {0}; Value -- {1}; Name --{2}.", de.Key, de.Value, BusinessInfo.Instance().GeCodeByID(de.Value.ToString(), BusinessInfo.BusinessTypeCode)) + "\n");
                        break;
                    default:
                        StrTemp.Append(string.Format("Key -- {0}; Value --{1}.", de.Key, de.Value) + "\n");
                        break;
                }
            }
            StrTemp.Append("---------------------------------------------------------------------------------------------------------------\n");
            FileHelper.WriteText(AppDomain.CurrentDomain.BaseDirectory  + "\\log\\MotoPay\\" + DateTime.Now.ToString("yyyy-MM-dd") + "\\" + DateTime.Now.ToString("HH-mm-ss_fff") + ".txt", StrTemp);

            return BusinessInfo.Instance().GeCodeByID(result.getRtcode(), BusinessInfo.BusinessCode);
        }

        #endregion
    }
}
