﻿/*----------------------------------------------------------------
// Copyright (C) 2009 北京时空信联网络技术有限公司版权所有。 
//
//  文 件 名：MotoType
//  功能描述：Moto执行方法类型
//
//	 
//  创建时间：2009-03-17
//  创 建 人：黄炜
//  部    门：技术部
//  职    务：
//
//----------------------------------------------------------------*/


using System;
using System.Collections.Generic;
using System.Text;

namespace uni2uni.com.MotoLibrary
{
    /// <summary>
    /// moto执行方法类型
    /// </summary>
    public enum MotoType
    {
        /// <summary>
        /// 预授权交易
        /// </summary>
        anthorize = 1,
        /// <summary>
        /// 撤销预授权交易
        /// </summary>
        authorizeRevoke,
        /// <summary>
        /// 预授权确认交易
        /// </summary>
        confirm,
        /// <summary>
        /// 撤销预授权确认交易
        /// </summary>
        confirmRevoke,
        /// <summary>
        /// 消费交易
        /// </summary>
        consume,
        /// <summary>
        /// 撤销消费交易
        /// </summary>
        consumeRevoke,
        /// <summary>
        /// 退款申请
        /// </summary>
        refund,
        /// <summary>
        /// 冲正交易
        /// </summary>
        reverse,
        /// <summary>
        /// 查询返回结果集
        /// </summary>
        search,
        /// <summary>
        /// 查询商户受理卡
        /// </summary>
        searchCard
    }
}
