
/// Used with permission from Mariano Omar Rodriguez
/// http://weblogs.asp.net/marianor/archive/2007/10/15/a-wpf-wrapper-around-windows-form-notifyicon.aspx

namespace WPFTaskbarNotifier
{
	public enum BalloonTipIcon
	{
		None = 0,
		Info = 1,
		Warning = 2,
		Error = 3,
	}
}