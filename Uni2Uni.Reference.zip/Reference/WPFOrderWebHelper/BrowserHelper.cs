﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace WPFOrderWebHelper
{
    public class BrowserHelper
    {

        private System.Windows.Forms.WebBrowser myBrowser;

        public BrowserHelper(System.Windows.Forms.WebBrowser myBrowser)
        {
            this.myBrowser = myBrowser;
        }
        /// <summary>
        /// 获取或设置浏览地址
        /// </summary>
        public  Uri BrowserURL
        {
            get { return myBrowser.Url; }
            set
            {
                myBrowser.Navigate(value);
            }
        }

        /// <summary>
        /// 获得网页文档结构
        /// </summary>
        public HtmlDocument BrowserDocument
        {

            get
            {
                return myBrowser.Document;
            }
        }

        /// <summary>
        /// 根据ID获取html控件
        /// </summary>
        /// <param name="name">控件ID</param>
        /// <returns>html控件</returns>
        public HtmlElement GetElementByTagID(string name)
        {
            if (BrowserDocument != null)
            {
                return BrowserDocument.GetElementById(name);
            }
            return null;
        }

        /// <summary>
        /// 根据标记名称获取html控件
        /// </summary>
        /// <param name="name">标记名称</param>
        /// <returns>html控件列表</returns>
        public HtmlElementCollection GetElementByTagName(string name)
        {
            if (BrowserDocument != null)
            {
                return BrowserDocument.GetElementsByTagName(name);
            }
            return null;
        }
        /// <summary>
        /// 设值html元素文本
        /// </summary>
        /// <param name="element">控件ID</param>
        /// <param name="text">文本</param>
        public void SetElementText(string elementID, string text)
        {
            HtmlElement element = GetElementByTagID(elementID);
            if (element != null)
            {
                element.InnerText = text;
            }
        }

        /// <summary>
        /// 设置html元素属性值
        /// </summary>
        /// <param name="elementID">控件ID</param>
        /// <param name="AttributeName">属性名称</param>
        /// <param name="AttributeValue">属性值</param>
        public void SetElementAttribute(string elementID, string AttributeName, string AttributeValue)
        {
            HtmlElement element = GetElementByTagID(elementID);
            if (element != null)
            {
                element.SetAttribute(AttributeName, AttributeValue);
            }
        }

        /// <summary>
        /// 执行html控件的方法
        /// </summary>
        /// <param name="elementID">控件ID</param>
        /// <param name="eventName">方法名称</param>
        public void RaiseElementEvent(string elementID, string eventName)
        {
            HtmlElement element = GetElementByTagID(elementID);
            if (element != null)
            {
                element.InvokeMember(eventName);
            }
        }

        public IList<HtmlElement> GetHtmlElementChildrenByTagname(HtmlElement sendinfoDiv, string typename)
        {
            HtmlElementCollection tds = sendinfoDiv.All;
            IList<HtmlElement> collection = new List<HtmlElement>();
            foreach (HtmlElement element in tds)
            {
                if (element.TagName.Equals(typename))
                {
                    collection.Add(element);
                }
            }
            return collection;
        }

        public IList<HtmlElement> GetHtmlElementChildrenIncludeID(HtmlElement sendinfoDiv, string typename, string substr)
        {
            HtmlElementCollection tds = sendinfoDiv.All;
            IList<HtmlElement> collection = new List<HtmlElement>();
            foreach (HtmlElement element in tds)
            {
                if (element.TagName.Equals(typename))
                {
                    if (element.Id != null && element.Id.IndexOf(substr) >= 0)
                    {
                        collection.Add(element);
                    }
                }
            }
            return collection;
        }
    }
}
