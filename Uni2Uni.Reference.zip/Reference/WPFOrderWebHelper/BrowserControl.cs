﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace WPFOrderWebHelper
{

    public enum AutoOrderState
    {
        ProductAdding = 1,
        ProductAddFinished = 2,
        UserLogin = 3,
        AddConnectInformation = 4,
        OrderSuccess = 5
    }

    public delegate void ShowMessage(string message,Color color);

    public delegate void DoProductAddedEvent(string infocode, string infoname, bool isAdded);

    public delegate void ProductAddedFinnishededEvent(int count);

    public delegate void LoginedEvent(string username);

    public delegate void SendInforSuccessedEvent(string orderData);

    public delegate void OrderSuccessEvent(string originalOrderid, decimal amount, string sData);

    public delegate void ErrorEvent(bool isStop, string errorMessage);

    public delegate void DoAddProduct(uni2uni.com.Model.Order_Order.ProductOrderDetail detail);

    public delegate void DOLogin();

    public delegate void DOLoginAction();

    public delegate void DoConnectEditAction();

    public delegate void DOeditTicketAction();

    public delegate void DoSaveAddressAction(uni2uni.com.Model.Order_Order.OrderLinkDetail detail);

    public delegate string DOconnectInfor(uni2uni.com.Model.Order_Order.OrderLinkDetail detail);

    public delegate void DOTicketInfoAction(uni2uni.com.Model.Order_Order.OrderLinkDetail linkdetail);

    public delegate void DoOrderOKInfor(out string oid, out string oprice, out string otherData);

    public partial class BrowserControl : UserControl
    {
        /// <summary>
        /// 内部的浏览控件
        /// </summary>
        private System.Windows.Forms.WebBrowser myBrowser;
        public System.Windows.Forms.WebBrowser Browser
        {
            get { return myBrowser; }
            set { myBrowser = value; }
        }

        private DoAddProduct doAddProduct;
        private DOLogin login;
        private DOconnectInfor doconnectInfor;
        private DoOrderOKInfor doOrderOKInfor;
        private DOLoginAction doLoginAction;
        private DoConnectEditAction doConnectEditAction;
        private DoSaveAddressAction doSaveAddressAction;
        private DOeditTicketAction doeditTicketAction;
        private DOTicketInfoAction doTicketInfoAction;

        private IWebSiteOrder siteOrder;

        private uni2uni.com.Model.Order_Order.GeneralOrder gorder;

        private IList<uni2uni.com.Model.Order_Order.ProductOrderDetail> productList;

        private uni2uni.com.Model.Order_Order.OrderLinkDetail linkdetail;

        private ShowMessage showMessage;

        public event DoProductAddedEvent oneProductAdded;

        public event ProductAddedFinnishededEvent productAddFinnisheded;

        public event LoginedEvent loginEvent;

        public event SendInforSuccessedEvent sendInforSuccessedEvent;

        public event OrderSuccessEvent orderSuccess;

        public event ErrorEvent errorEvent;

        private AutoResetEvent productResetEvent = new AutoResetEvent(false);
        
        private AutoResetEvent productAddedEvent = new AutoResetEvent(false);

        private AutoResetEvent LoginPageLoadEvent = new AutoResetEvent(false);
        
        private AutoResetEvent shoppingcarPageLoadedEvent = new AutoResetEvent(false);
        
        private AutoResetEvent dosendinformationEvent = new AutoResetEvent(false);
        
        private AutoResetEvent waitLoadedEvent = new AutoResetEvent(false);
        
        private AutoResetEvent orderPageLoadedEvent = new AutoResetEvent(false);

        private AutoResetEvent LoginOKEvent = new AutoResetEvent(false);

        private AutoResetEvent AddressAddedEvent = new AutoResetEvent(false);

        private AutoResetEvent confirmOrderEvent = new AutoResetEvent(false);

        public BrowserControl()
        {
            InitializeComponent();
            showMessage = new ShowMessage(DisplayMessage);
            myBrowser = new System.Windows.Forms.WebBrowser();
            myBrowser.Dock = DockStyle.Fill;
            panel1.Controls.Add(myBrowser);
            myBrowser.NewWindow += new System.ComponentModel.CancelEventHandler(myBrowser_NewWindow);
            myBrowser.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(myBrowser_DocumentCompleted);
        }

        void myBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            if (!myBrowser.IsBusy)
            {
                if (myBrowser.ReadyState == WebBrowserReadyState.Complete)
                {
                    if (myBrowser.Url.OriginalString.Equals(siteOrder.ProductURl) || WebSiteOrder.IsProductURL(siteOrder.ProductURl,myBrowser.Url.OriginalString))
                    {
                        productResetEvent.Set();
                    }
                    else if (myBrowser.Url.OriginalString.StartsWith(siteOrder.ShoppingcarAddURL))
                    {
                        productAddedEvent.Set();
                    }
                    else if (myBrowser.Url.OriginalString.StartsWith(siteOrder.LoginUrl))//登录页面加载完成
                    {
                        LoginPageLoadEvent.Set();
                    }
                    else if (myBrowser.Url.OriginalString.StartsWith(siteOrder.LoginOKUrl))
                    {
                        LoginOKEvent.Set();
                    }
                    else if (myBrowser.Url.OriginalString.StartsWith(siteOrder.ShoppingcarURL))//加入购物车完成
                    {
                        shoppingcarPageLoadedEvent.Set();
                    }
                    else if (myBrowser.Url.OriginalString.StartsWith(siteOrder.ConnectInformationURL))//订单生成
                    {
                        dosendinformationEvent.Set();
                    }
                    else if (myBrowser.Url.OriginalString.StartsWith(siteOrder.OrderSuccessURL))//订单生成
                    {
                        orderPageLoadedEvent.Set();
                    }

                }
            }
        }

        void myBrowser_NewWindow(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            try
            {
                string url = this.myBrowser.Document.ActiveElement.GetAttribute("href");

                this.myBrowser.Url = new Uri(url);
            }
            catch
            {
            }
        }

        private void DisplayMessage(string addStr, Color color)
        {
            int start = this.browserMessager.Text.Length;
            int length = addStr.Length;
            this.browserMessager.AppendText(addStr + "\r\n");
            this.browserMessager.SelectionStart = start;
            this.browserMessager.SelectionLength = length;
            this.browserMessager.SelectionColor = color;
        }

        private bool isAlive;
        public bool IsAlive { get { return isAlive; } }

        private AutoOrderState currentState;
        public AutoOrderState CurrentState
        {
            get { return currentState; }
        }

        private string orderid;
        public string OrderID
        {
            get { return orderid; }
            set
            {
                orderid = value;
                InitOrder(orderid);
                if (WebSiteOrder == null)
                {
                    System.Windows.Forms.MessageBox.Show("没有该供应商的处理程序！");
                }
                else
                {
                    System.Threading.Thread workThread = new System.Threading.Thread(new System.Threading.ThreadStart(WorkBrowserThread));
                    workThread.Start();
                }
            }
        }

        private void WorkBrowserThread()
        {
            if (WebSiteOrder != null)
            {
                while (!this.IsHandleCreated)
                {
                    ;
                }
               DoShoppingWork(gorder, productList, linkdetail);
            }
        }

        private void InitOrder(string orderid)
        {
            gorder = OrderHelper.GetOrder(orderid);
            productList = OrderHelper.GetProductList(orderid);
            linkdetail = OrderHelper.GetOrderLinkDetail(orderid);
            WebSiteOrder = OrderHelper.GetInstance(gorder.ProviderID.ToString());
            WebSiteOrder.Browser = myBrowser;

            doAddProduct = new DoAddProduct(WebSiteOrder.DoAddShoppingCar);
            login = new DOLogin(WebSiteOrder.DoLogin);
            doconnectInfor = new DOconnectInfor(WebSiteOrder.DoConnectInformation);
            doOrderOKInfor = new DoOrderOKInfor(WebSiteOrder.DoOrderSuccess);
            doLoginAction = new DOLoginAction(WebSiteOrder.DoLoginAction);
            doConnectEditAction = new DoConnectEditAction(WebSiteOrder.DoConnectEditAction);
            doSaveAddressAction = new DoSaveAddressAction(WebSiteOrder.DoSaveAddressAction);
            doeditTicketAction = new DOeditTicketAction(WebSiteOrder.DoeditTicketAction);
            doTicketInfoAction = new DOTicketInfoAction(WebSiteOrder.DoTicketInfoAction);

            if (WebSiteOrder != null)
            {
                this.oneProductAdded += new DoProductAddedEvent(WebSiteOrder_oneProductAdded);
                this.productAddFinnisheded += new ProductAddedFinnishededEvent(WebSiteOrder_productAddFinnisheded);
                this.loginEvent += new LoginedEvent(WebSiteOrder_loginEvent);
                this.sendInforSuccessedEvent += new SendInforSuccessedEvent(WebSiteOrder_sendInforSuccessedEvent);
                this.orderSuccess += new OrderSuccessEvent(WebSiteOrder_orderSuccess);
                this.errorEvent += new ErrorEvent(WebSiteOrder_errorEvent);
                WebSiteOrder.linkInfoEvent += new LinkInfoEvent(WebSiteOrder_linkInfoEvent);
                WebSiteOrder.AddressAddedEvent += new LinkInfoEvent(WebSiteOrder_AddressAddedEvent);
                WebSiteOrder.confirmOrderEvent += new LinkInfoEvent(WebSiteOrder_confirmOrderEvent);
            }
        }

        void WebSiteOrder_confirmOrderEvent()
        {
           confirmOrderEvent.Set();
        }

        void WebSiteOrder_AddressAddedEvent()
        {
            AddressAddedEvent.Set();
        }

        void WebSiteOrder_linkInfoEvent()
        {
            waitLoadedEvent.Set();
        }

        void WebSiteOrder_errorEvent(bool isStop, string errorMessage)
        {
            if (isStop)
            {   
                this.Invoke(showMessage, new object[] { "预定进程已停止！错误原因：" + errorMessage,Color.Red });
            }
            else
            {
                this.Invoke(showMessage, new object[] { "预定进程过程有错！错误原因：" + errorMessage,Color.Red });
            }
        }

        void WebSiteOrder_orderSuccess(string originalOrderid, decimal amount, string sData)
        {
            this.Invoke(showMessage, new object[] { "订单号：" + originalOrderid + "金额：" + amount.ToString() + "已成功！", Color.Blue });
        }

        void WebSiteOrder_sendInforSuccessedEvent(string orderData)
        {
            System.Windows.Forms.MessageBox.Show(orderData);
        }

        void WebSiteOrder_loginEvent(string username)
        {
            this.Invoke(showMessage, new object[] { "用户名：" + username + "已登录！", Color.Blue });
        }

        void WebSiteOrder_productAddFinnisheded(int count)
        {
            this.Invoke(showMessage, new object[] { "共有" + count.ToString() + "种商品加入购物车！", Color.Blue });
        }

        void WebSiteOrder_oneProductAdded(string infocode, string infoname, bool isAdded)
        {
            if (isAdded)
            {
                this.Invoke(showMessage, new object[] { infoname + "(" + infocode + ")已经加入购物车！", Color.Blue });
            }
            else
            {
                this.Invoke(showMessage, new object[] { infoname + "(" + infocode + ")加入购物车失败！", Color.Blue });
            }
        }

        public IWebSiteOrder WebSiteOrder
        {
            get { return siteOrder; }
            set
            {
                siteOrder = value;
            }
        }

        public void DoShoppingWork(uni2uni.com.Model.Order_Order.GeneralOrder gorder, IList<uni2uni.com.Model.Order_Order.ProductOrderDetail> proList, uni2uni.com.Model.Order_Order.OrderLinkDetail linkdetail)
        {
            currentState = AutoOrderState.ProductAdding;
            isAlive = true;
            int pcount = DoProductsAdd(proList);
            if (pcount == 0)
            {
                isAlive = false;
                errorEvent(true, "没有可预订的商品！程序停止！");
                return;
            }
            if (WebSiteOrder.IsLoginFirst)
            {
                try
                {
                    DoLogin();
                }
                catch (Exception ne)
                {
                    isAlive = false;
                    errorEvent(true, "用户登录失败！程序停止！（" + ne.StackTrace + ")");
                    return;
                }
            }
           
            try
            {
                DoConnectInformation(linkdetail);
            }
            catch (Exception ne)
            {
                isAlive = false;
                errorEvent(true, "填写用户信息失败！（" + ne.StackTrace + ")");
                return;
            }
            try
            {
                DoOrderSuccess();
            }
            catch (Exception ne)
            {
                isAlive = false;
                errorEvent(true, "获取订单成功信息失败！（" + ne.StackTrace + ")");
                return;
            }
        }

        public int DoProductsAdd(IList<uni2uni.com.Model.Order_Order.ProductOrderDetail> proList)
        {
            if (proList != null && proList.Count > 0)
            {
                int i = 0;
                foreach (uni2uni.com.Model.Order_Order.ProductOrderDetail detail in proList)
                {
                    try
                    {
                        string URL = OrderHelper.GetProductUrl(detail.ProductCode, detail.ProviderID);
                        if (URL.Length > 0)
                        {
                            WebSiteOrder.ProductURl = URL;
                            myBrowser.Navigate(WebSiteOrder.ProductURl);
                            productResetEvent.WaitOne();
                            this.Invoke(doAddProduct,new object[]{detail});
                            productAddedEvent.WaitOne();
                            oneProductAdded(detail.ProductCode.ToString(), detail.ProductName, true);
                            i++;
                        }
                        else
                        {
                            errorEvent(false, "商品：" + detail.ProductName + "(" + detail.ProductCode.ToString() + ")没有找到地址！");
                        }
                    }
                    catch (Exception ne)
                    {
                        errorEvent(false, "商品：" + detail.ProductName + "(" + detail.ProductCode.ToString() + ")预定失败！" + ne.StackTrace);
                        oneProductAdded(detail.ProductCode.ToString(), detail.ProductName, false);
                    }
                }
                productAddFinnisheded(i);
                currentState = AutoOrderState.ProductAddFinished;
                return i;
            }
            return 0;
        }

        public void DoLogin()
        {
            currentState = AutoOrderState.UserLogin;
            myBrowser.Navigate(WebSiteOrder.LoginUrl);
            LoginPageLoadEvent.WaitOne();
            this.Invoke(login);
            LoginOKEvent.WaitOne();
            loginEvent(WebSiteOrder.UserName);
        }

        public void DoConnectInformation(uni2uni.com.Model.Order_Order.OrderLinkDetail linkdetail)
        {
            currentState = AutoOrderState.AddConnectInformation;
            myBrowser.Navigate(WebSiteOrder.ShoppingcarURL);
            shoppingcarPageLoadedEvent.WaitOne();
            this.Invoke(doLoginAction);
            if (!WebSiteOrder.IsLoginFirst)
            {
                LoginPageLoadEvent.WaitOne();
                this.Invoke(login);
            }
            dosendinformationEvent.WaitOne();
            if (WebSiteOrder.IsLinkInfoAction)
            {
                this.Invoke(doConnectEditAction);
                waitLoadedEvent.WaitOne();
            }
            if (WebSiteOrder.IsSaveAddressAction)
            {
                this.Invoke(doSaveAddressAction, new object[] { linkdetail });
                AddressAddedEvent.WaitOne();
            }
            if (linkdetail.TicketState == 0)
            {
                if (WebSiteOrder.IsTicketAction)
                {
                    this.Invoke(doeditTicketAction);
                    waitLoadedEvent.WaitOne();
                }
                this.Invoke(doTicketInfoAction, new object[] { linkdetail });
                confirmOrderEvent.WaitOne();
            }

            //获得商品与价格数据
            string strOrderXml = this.Invoke(doconnectInfor, new object[] { linkdetail }) as string;
            sendInforSuccessedEvent(strOrderXml);
        }

        public void DoOrderSuccess()
        {
            currentState = AutoOrderState.OrderSuccess;
            orderPageLoadedEvent.WaitOne();
            string oid = "";
            string oprice = "0";
            string otherData = "";
            this.Invoke(doOrderOKInfor,new object[]{oid,oprice,otherData});
            orderSuccess(oid, decimal.Parse(oprice), otherData);
        }
    }
}
