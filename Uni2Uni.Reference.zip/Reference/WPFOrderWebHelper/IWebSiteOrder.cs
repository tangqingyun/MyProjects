﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace WPFOrderWebHelper
{
    
    public delegate void LinkInfoEvent();

    public interface IWebSiteOrder
    {

        event LinkInfoEvent linkInfoEvent;

        event LinkInfoEvent AddressAddedEvent;

        event LinkInfoEvent confirmOrderEvent;

        string ProductURl { get; set; }

        string UserName { get; }

        string ShoppingcarAddURL { get; set; }

        string LoginUrl { get; set; }

        string LoginOKUrl { get; set; }

        System.Windows.Forms.WebBrowser Browser { get; set; }

        string ShoppingcarURL { get; set; }

        string ConnectInformationURL { get; set; }

        string OrderSuccessURL { get; set; }

        void DoAddShoppingCar(uni2uni.com.Model.Order_Order.ProductOrderDetail detail);

        void DoLogin();

        void DoLoginAction();

        string DoConnectInformation(uni2uni.com.Model.Order_Order.OrderLinkDetail linkdetail);

        void DoOrderSuccess(out string oid, out string amount, out string sOrderDate);

        string GetUserName();

        string GetUserPassword();

        bool IsLinkInfoAction { get; }

        void DoConnectEditAction();

        bool IsSaveAddressAction { get; }

        bool IsTicketAction { get; }

        void DoSaveAddressAction(uni2uni.com.Model.Order_Order.OrderLinkDetail linkdetail);

        void DoeditTicketAction();

         void DoTicketInfoAction(uni2uni.com.Model.Order_Order.OrderLinkDetail linkdetail);

         bool IsLoginFirst { get; }

         bool IsProductURL(string oldurl, string newUrl);
    }


}
