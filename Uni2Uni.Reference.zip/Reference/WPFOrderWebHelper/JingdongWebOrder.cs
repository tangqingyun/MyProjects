﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace WPFOrderWebHelper
{
    public class JingdongWebOrder:IWebSiteOrder
    {
        #region IWebSiteOrder 成员

        public event LinkInfoEvent linkInfoEvent;

        public event LinkInfoEvent AddressAddedEvent;

        public event LinkInfoEvent confirmOrderEvent;

        private string productURl;
        public string ProductURl
        {
            get
            {
                return productURl;
            }
            set
            {
                productURl = value;
            }
        }

        private string shoppingcarAddURL = "http://jd2008.360buy.com/purchase/InitCart.aspx";
        public string ShoppingcarAddURL
        { get { return shoppingcarAddURL; }
          set { shoppingcarAddURL = value; }
        }

        private string loginUrl = "https://passport.360buy.com/new/login.aspx";
        public string LoginUrl
        {
            get { return loginUrl; }
            set { loginUrl = value; }
        }


        public bool IsLinkInfoAction {

            get { return true; }
        }

        public bool IsSaveAddressAction
        {
            get { return true; }
        }

        public bool IsTicketAction
        {
            get { return true; }
        }

        public bool IsLoginFirst 
        {
            get { return true; }
        }

        private System.Windows.Forms.WebBrowser browser;
        public System.Windows.Forms.WebBrowser Browser
        {
            get { return browser; }
            set { browser = value; }
        }
        private string loginOKUrl = "http://www.360buy.com/";
        public string LoginOKUrl
        {
            get { return loginOKUrl; }
            set { loginOKUrl = value; }
        }
        private string username;
        public string UserName
        {
            get { return username; }
        }
        private string shoppingcarURL = "http://jd2008.360buy.com/purchase/shoppingcart_pop.aspx";
        public string ShoppingcarURL
        {
            get
            {
                return shoppingcarURL;
            }
            set
            {
                shoppingcarURL = value;
            }
        }

        private string connectInformationURL = "http://jd2008.360buy.com/purchase/orderinfo_pop_main.aspx";
        public string ConnectInformationURL
        {
            get
            {
                return connectInformationURL;
            }
            set
            {
                connectInformationURL = value;
            }
        }

        private string orderSuccessURL = "http://jd2008.360buy.com/purchase/succeed_online.aspx";
        public string OrderSuccessURL
        {
            get
            {
                return orderSuccessURL;
            }
            set
            {
                orderSuccessURL = value; 
            }
        }

        public JingdongWebOrder()
        {
        }

        public void DoAddShoppingCar(uni2uni.com.Model.Order_Order.ProductOrderDetail detail)
        {
            //更改商品数量
            BrowserHelper bhelper = new BrowserHelper(Browser);
            bhelper.SetElementAttribute("pamount","value", detail.OrderNumber.ToString());
            //点击加入购物车按钮
            HtmlElement InitCartUrlElement = bhelper.GetElementByTagID("InitCartUrl");
            if (InitCartUrlElement != null)
            {
                bhelper.RaiseElementEvent("InitCartUrl", "click");
            }
            else
            {
                throw new Exception("该商品无货！");
            }
        }


        public void DoLoginAction()
        {
            BrowserHelper bhelper = new BrowserHelper(Browser);
            bhelper.RaiseElementEvent("gotoOrderInfo", "click");
        }

        public void DoLogin()
        {
            BrowserHelper bhelper = new BrowserHelper(Browser);
            username = GetUserName();
            string loginpwd = GetUserPassword();
            if (bhelper.BrowserURL.OriginalString.StartsWith("https://passport.360buy.com/new/login.aspx"))
            {
                bhelper.SetElementText("loginname", username);
                bhelper.SetElementText("loginpwd", loginpwd);
                bhelper.RaiseElementEvent("loginsubmit", "click");
            }
        }

        public void DoSaveAddressAction(uni2uni.com.Model.Order_Order.OrderLinkDetail linkdetail)
        {
            BrowserHelper bhelper = new BrowserHelper(Browser);
            if (linkdetail.LinkMan.Length > 0)
            {
                HtmlElement passDiv = bhelper.GetElementByTagID("consignee_addressName");
                passDiv.SetAttribute("value", linkdetail.LinkMan);
            }
            if (linkdetail.Address.Length > 0)
            {
                HtmlElement addressDiv = bhelper.GetElementByTagID("consignee_address");
                addressDiv.SetAttribute("value", linkdetail.Address);
            }
            if (linkdetail.Mobile.Length > 0)
            {
                HtmlElement mobileDiv = bhelper.GetElementByTagID("consignee_message");
                mobileDiv.SetAttribute("value", linkdetail.Mobile);
            }
            if (linkdetail.Telephone.Length > 0)
            {
                HtmlElement telDiv = bhelper.GetElementByTagID("consignee_phone");
                telDiv.SetAttribute("value", linkdetail.Telephone);
            }
            if (linkdetail.Email.Length > 0)
            {
                HtmlElement emailDiv = bhelper.GetElementByTagID("consignee_email");
                emailDiv.SetAttribute("value", linkdetail.Email);
            }
            if (linkdetail.Zip.Length > 0)
            {
                HtmlElement zipDiv = bhelper.GetElementByTagID("consignee_postcode");
                zipDiv.SetAttribute("value", linkdetail.Zip);
            }
            HtmlElement infoDiv = bhelper.GetElementByTagID("part_consignee");
            IList<HtmlElement> inputLists = bhelper.GetHtmlElementChildrenByTagname(infoDiv, "INPUT");
            inputLists[inputLists.Count - 1].AttachEventHandler("onclick", new EventHandler(addressaddedhandler));
            inputLists[inputLists.Count - 1].InvokeMember("click");
        }

        public string DoConnectInformation(uni2uni.com.Model.Order_Order.OrderLinkDetail linkdetail)
        {
            BrowserHelper bhelper = new BrowserHelper(Browser);
            //获得商品与价格数据
            string strOrderXml = GetOrderinfo(bhelper);
            return strOrderXml;
        }

        public void DoeditTicketAction()
        {
            BrowserHelper bhelper = new BrowserHelper(Browser);
            HtmlElement infoDiv = bhelper.GetElementByTagID("part_invoice");
            IList<HtmlElement> inputLists = bhelper.GetHtmlElementChildrenByTagname(infoDiv, "A");
            infoDiv.AttachEventHandler("onpropertychange", new EventHandler(handler));
            inputLists[0].InvokeMember("click");
        }

        public void DoTicketInfoAction(uni2uni.com.Model.Order_Order.OrderLinkDetail linkdetail)
        {

            BrowserHelper bhelper = new BrowserHelper(Browser);
            if (linkdetail.TicketObject == 0)
            {
                HtmlElement infoDiv = bhelper.GetElementByTagID("invoince_pttt4");
                infoDiv.InvokeMember("click");
            }
            else
            {
                HtmlElement infoDiv = bhelper.GetElementByTagID("invoince_pttt5");
                infoDiv.InvokeMember("click");
            }
            HtmlElement titleElement = bhelper.GetElementByTagID("invoice_Unit_TitName");
            titleElement.SetAttribute("value", linkdetail.TicketTitle);
            HtmlElement ticketDiv = bhelper.GetElementByTagID("part_invoice");
            IList<HtmlElement> inputLists = bhelper.GetHtmlElementChildrenByTagname(ticketDiv, "INPUT");
            inputLists[inputLists.Count - 1].AttachEventHandler("onclick", new EventHandler(tickethandler));
        }

        private void handler(Object sender, EventArgs e)
        {
             linkInfoEvent();
        }

        private void addressaddedhandler(Object sender, EventArgs e)
        {
            AddressAddedEvent();
        }

        private void tickethandler(Object sender, EventArgs e)
        {
            confirmOrderEvent();
        }

        public void DoConnectEditAction()
        {
            BrowserHelper bhelper = new BrowserHelper(Browser);
            if (bhelper.BrowserURL.OriginalString.StartsWith(ConnectInformationURL))
            {
                HtmlElement infoDiv = bhelper.GetElementByTagID("part_consignee");
                if (infoDiv != null)
                {
                    infoDiv.AttachEventHandler("onpropertychange", new EventHandler(handler));
                }
                HtmlElement editHref = bhelper.GetElementByTagID("lbtnConsigneeWrite");
                if (editHref != null)
                {
                    editHref.InvokeMember("click");
                }
            }
        }


        private string GetOrderinfo(BrowserHelper bhelper)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("<?xml version=\"1.0\" encoding=\"gb2312\"?><Order>");
            //送货人信息
            System.Windows.Forms.HtmlElement sendinfoDiv = bhelper.GetElementByTagID("part_consignee");
            GetLinkInfo(builder, sendinfoDiv);
            //支付及配送信息
            System.Windows.Forms.HtmlElement payinfoDiv = bhelper.GetElementByTagID("part_payTypeAndShipType");
            GetPayInfo(builder, payinfoDiv, bhelper);
            //发票信息
            System.Windows.Forms.HtmlElement invoiceDiv = bhelper.GetElementByTagID("part_invoice");
            GetInvoiceinfo(builder, invoiceDiv, bhelper);
            //备注
            System.Windows.Forms.HtmlElement attchDiv = bhelper.GetElementByTagID("part_remark");
            GetRemark(builder, attchDiv, bhelper);
            //商品列表
            System.Windows.Forms.HtmlElement productInfo = bhelper.GetElementByTagID("part_cart");
            GetProduct(builder, productInfo, bhelper);
            //结算信息
            System.Windows.Forms.HtmlElement feeInfo = bhelper.GetElementByTagID("ware_info");
            GetWare(builder, feeInfo,bhelper);
            builder.Append("</Order>");
            return builder.ToString();

        }

        private void GetWare(StringBuilder builder, HtmlElement sendinfoDiv, BrowserHelper bhelper)
        {
            builder.Append("<ware>");
            IList<HtmlElement> tds = bhelper.GetHtmlElementChildrenByTagname(sendinfoDiv, "DIV");
            if (tds.Count > 0)
            {
                HtmlElement infoDiv = tds[1];
                IList<HtmlElement> LIs = bhelper.GetHtmlElementChildrenByTagname(infoDiv, "LI");
                string infos = LIs[0].InnerText;
                string jine = infos.Replace("商品金额：", "").Replace("￥", "");
                string goods = jine.Substring(0, jine.IndexOf("元"));
                string yuns = jine.Replace(goods, "").Replace("元 + 运费：", "").Replace("￥", "");
                string yunfee = yuns.Substring(0, yuns.IndexOf("元"));
                IList<HtmlElement> Spans = bhelper.GetHtmlElementChildrenByTagname(infoDiv, "SPAN");
                string yhis = Spans[0].InnerText;
                string lipins = Spans[1].InnerText;
                builder.Append("<amount>" + goods + "</amount>");
                builder.Append("<freight>" + yunfee + "</freight>");
                builder.Append("<off>" + yhis + "</off>");
                builder.Append("<goodscard>" + lipins + "</goodscard>");
            }
            builder.Append("</ware>");
        }

        private void GetProduct(StringBuilder builder, HtmlElement sendinfoDiv, BrowserHelper bhelper)
        {
            builder.Append("<products>");
            IList<HtmlElement> tds = bhelper.GetHtmlElementChildrenByTagname(sendinfoDiv, "TR");
            if (tds.Count > 0)
            {
                for (int i = 1; i < tds.Count; i++)
                {
                    builder.Append("<product>");
                    IList<HtmlElement> tdproducts = bhelper.GetHtmlElementChildrenByTagname(tds[i], "TD");
                    builder.Append("<productid>" + tdproducts[0].InnerText + "</productid>");
                    builder.Append("<productname>" + tdproducts[1].InnerText + "</productname>");
                    builder.Append("<price>" + tdproducts[2].InnerText + "</price>");
                    builder.Append("<returncash>" + tdproducts[3].InnerText + "</returncash>");
                    builder.Append("<jifen>" + tdproducts[4].InnerText + "</jifen>");
                    builder.Append("<stocktype>" + tdproducts[5].InnerText + "</stocktype>");
                    builder.Append("<count>" + tdproducts[6].InnerText + "</count>");
                    builder.Append("</product>");
                }
            }
            builder.Append("</products>");
        }

        private void GetRemark(StringBuilder builder, HtmlElement sendinfoDiv, BrowserHelper bhelper)
        {
            builder.Append("<remark>");
            IList<HtmlElement> tds = bhelper.GetHtmlElementChildrenByTagname(sendinfoDiv, "TD");
            builder.Append("<remark>" + tds[0].InnerText + "</remark>");
            builder.Append("</remark>");
        }

        private void GetPayInfo(StringBuilder builder, HtmlElement sendinfoDiv,BrowserHelper bhelper)
        {
            builder.Append("<payinfo>");
            IList<HtmlElement> tds = bhelper.GetHtmlElementChildrenByTagname(sendinfoDiv, "TD");
            builder.Append("<paytype>" + tds[1].InnerText + "</paytype>");
            builder.Append("<sendtype>" + tds[3].InnerText + "</sendtype>");
            builder.Append("<freight>" + tds[5].InnerText + "</freight>");
            builder.Append("<sendtime>" + tds[7].InnerText + "</sendtime>");
            builder.Append("</payinfo>");
        }

        private void GetInvoiceinfo(StringBuilder builder, HtmlElement sendinfoDiv, BrowserHelper bhelper)
        {
            builder.Append("<invoice>");
            IList<HtmlElement> tds = bhelper.GetHtmlElementChildrenByTagname(sendinfoDiv, "TD");
            builder.Append("<invtype>" + tds[1].InnerText + "</invtype>");
            builder.Append("<invtitle>" + tds[3].InnerText + "</invtitle>");
            builder.Append("<invdetail>" + tds[5].InnerText + "</invdetail>");
            builder.Append("</invoice>");
        }
        
        private void GetLinkInfo(StringBuilder builder, HtmlElement sendinfoDiv)
        {
            builder.Append("<sendinfo>");
            HtmlDocument doc = sendinfoDiv.Document;
            HtmlElementCollection tds = doc.GetElementsByTagName("TD");
            builder.Append("<linkname>" + tds[1].InnerText + "</linkname>");
            builder.Append("<dirct>" + tds[3].InnerText + "</dirct>");
            builder.Append("<address>" + tds[5].InnerText + "</address>");
            builder.Append("<zip>" + tds[7].InnerText + "</zip>");
            builder.Append("<tel>" + tds[9].InnerText + "</tel>");
            builder.Append("<mobile>" + tds[11].InnerText + "</mobile>");
            builder.Append("<Email>" + tds[13].InnerText + "</Email>");
            builder.Append("</sendinfo>");
        }

        public void DoOrderSuccess(out string oid, out string oprice, out string otherData)
        {
            BrowserHelper bhelper = new BrowserHelper(Browser);
            HtmlElementCollection pList = bhelper.BrowserDocument.GetElementsByTagName("P");
            HtmlElement priceElement = pList[1];
            HtmlElementCollection strongList = priceElement.GetElementsByTagName("STRONG");
            oid = strongList[0].InnerText;
            oprice = strongList[1].InnerText;
            otherData = priceElement.InnerText;
        }

        public string GetUserName()
        {
            return "gathersite";
        }

        public string GetUserPassword()
        {
            return "aaa111";
        }

        public bool IsProductURL(string oldurl, string newUrl)
        {
            if (oldurl.Equals(newUrl))
            {
                return true;
            }
            return false;
        }
        #endregion

        
    }
}
