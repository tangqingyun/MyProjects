﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WPFOrderWebHelper
{
    public class AmazonWebOrder:IWebSiteOrder
    {
        #region IWebSiteOrder 成员

        public event LinkInfoEvent linkInfoEvent;

        public event LinkInfoEvent AddressAddedEvent;

        public event LinkInfoEvent confirmOrderEvent;

        private string productURl;
        public string ProductURl
        {
            get
            {
                return productURl;
            }
            set
            {
                productURl = value;
            }
        }

        private string username;
        public string UserName
        {
            get { return username; }
        }

        private string shoppingcarAddURL = "http://www.amazon.cn/gp/cart/view-upsell.html?";
        public string ShoppingcarAddURL
        {
            get
            {
                return shoppingcarAddURL;
            }
            set
            {
                shoppingcarAddURL = value;
            }
        }

        private string loginUrl = "https://www.amazon.cn/gp/cart/view.html/ref=ox_sc_proceed";
        public string LoginUrl
        {
            get
            {
                return loginUrl;
            }
            set
            {
                loginUrl = value;
            }
        }

        private string loginOKUrl = "https://www.amazon.cn/mn/yourStoreApp?";
        public string LoginOKUrl
        {
            get
            {
                return loginOKUrl;
            }
            set
            {
                loginOKUrl = value;
            }
        }

        private System.Windows.Forms.WebBrowser browser;
        public System.Windows.Forms.WebBrowser Browser
        {
            get
            {
                return browser;
            }
            set
            {
                browser = value;
                browser.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(browser_DocumentCompleted);
            }
        }

        void browser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            if (!Browser.IsBusy)
            {
                if (Browser.ReadyState == WebBrowserReadyState.Complete)
                {
                    if (Browser.Url.OriginalString.StartsWith("https://www.amazon.cn/gp/checkout/address/create.html/ref=ox_shipaddress_add_new_addr"))
                    {
                        AddressAddedEvent();
                    }
                    else if (Browser.Url.OriginalString.StartsWith("https://www.amazon.cn/gp/buy/payselect/handlers/continue.html/ref=ox_pay_page_continue_bottom"))
                    {
                        confirmOrderEvent();
                    }
                    else if (Browser.Url.OriginalString.StartsWith("https://www.amazon.cn/gp/checkout/confirm/select.html/ref=ox_spc_change_ship_addr_1"))
                    {
                        linkInfoEvent();
                    }
                }
            }
        }

        private string shoppingcarURL = "http://www.amazon.cn/gp/cart/view.html/ref=gno_cart";
        public string ShoppingcarURL
        {
            get
            {
                return shoppingcarURL;
            }
            set
            {
                shoppingcarURL = value;
            }
        }

        private string connectInformationURL = "https://www.amazon.cn/gp/buy/signin/handlers/continue.html?";
        public string ConnectInformationURL
        {
            get
            {
                return connectInformationURL;
            }
            set
            {
                connectInformationURL = value;
            }
        }

        private string orderSuccessURL = "https://www.amazon.cn/gp/checkout/confirm/select.html/ref=ox_spc_place_order_bottom";
        public string OrderSuccessURL
        {
            get
            {
                return orderSuccessURL;
            }
            set
            {
                orderSuccessURL = value;
            }
        }

        public bool IsProductURL(string oldurl, string newUrl)
        {
            if (oldurl.Equals(newUrl))
            {
                return true;
            }
            else
            {
                string[] oldStrArr = oldurl.Split(char.Parse("="));
                if (newUrl.StartsWith("http://www.amazon.cn/") && newUrl.EndsWith(oldStrArr[1]))
                {
                    return true;
                }
            }
            return false;
        }

        public void DoAddShoppingCar(uni2uni.com.Model.Order_Order.ProductOrderDetail detail)
        {
            //更改商品数量
            BrowserHelper bhelper = new BrowserHelper(Browser);
            bhelper.SetElementAttribute("quantity", "value", detail.OrderNumber.ToString());
            //点击加入购物车按钮
            HtmlElement buttonElement = bhelper.GetElementByTagID("bb_atc_button");
            if (buttonElement != null)
            {
                bhelper.RaiseElementEvent("bb_atc_button", "click");
            }
            else
            {
                throw new Exception("该商品无货！");
            }
        }

        public void DoLogin()
        {
            BrowserHelper bhelper = new BrowserHelper(Browser);
            username = GetUserName();
            string loginpwd = GetUserPassword();
            bhelper.SetElementText("ap_email", username);
            bhelper.SetElementText("ap_password", loginpwd);
            bhelper.RaiseElementEvent("signInSubmit", "click");
        }

        public void DoLoginAction()
        {
            BrowserHelper bhelper = new BrowserHelper(Browser);
            HtmlElement formElement = bhelper.GetElementByTagID("gutterCartViewForm");
            IList<HtmlElement> inputs = bhelper.GetHtmlElementChildrenByTagname(formElement,"INPUT");
            inputs[0].InvokeMember("click");
        }

        public string DoConnectInformation(uni2uni.com.Model.Order_Order.OrderLinkDetail linkdetail)
        {
            BrowserHelper bhelper = new BrowserHelper(Browser);

            //获得商品与价格数据
            string strOrderXml = GetOrderinfo(bhelper);
            if (linkdetail.TicketState == 0)
            {
                HtmlElement checkBoxElement = bhelper.GetElementByTagID("needChinaInvoice");
                checkBoxElement.InvokeMember("click");
                HtmlElement titleElement = bhelper.GetElementByTagID("chinaInvoiceTitle");
                titleElement.SetAttribute("value", linkdetail.TicketTitle);
                HtmlElement detailElement = bhelper.GetElementByTagID("chinaInvoiceCategoryID");
                detailElement.SetAttribute("value", "6");
            }
            return strOrderXml;
        }

        public void DoOrderSuccess(out string oid, out string amount, out string sOrderDate)
        {
           BrowserHelper bhelper = new BrowserHelper(Browser);
           HtmlElement checkBoxElement = bhelper.GetElementByTagID("orders-list");
           IList<HtmlElement> bElement = bhelper.GetHtmlElementChildrenByTagname(checkBoxElement,"B");
           oid = bElement[0].InnerText;
           amount = "0";
           sOrderDate = checkBoxElement.InnerText;
        }

        public string GetUserName()
        {
            return "haixv@sina.com";
        }

        public string GetUserPassword()
        {
            return "gathersite";
        }

        public bool IsLinkInfoAction
        {
            get { return true; }
        }

        public void DoConnectEditAction()
        {
            BrowserHelper bhelper = new BrowserHelper(Browser);
            HtmlElementCollection inputElements = bhelper.GetElementByTagName("INPUT");
            inputElements[2].InvokeMember("click");
        }

        public bool IsSaveAddressAction
        {
            get { return true; }
        }

        public bool IsLoginFirst
        {
            get { return false; }
        }

        public bool IsTicketAction
        {
            get { return false; }
        }

        public void DoSaveAddressAction(uni2uni.com.Model.Order_Order.OrderLinkDetail linkdetail)
        {
            BrowserHelper bhelper = new BrowserHelper(Browser);
            if (linkdetail.LinkMan.Length > 0)
            {
                HtmlElement passDiv = bhelper.GetElementByTagID("enterAddressFullName");
                passDiv.SetAttribute("value", linkdetail.LinkMan);
            }
            if (linkdetail.Address.Length > 0)
            {
                HtmlElement addressDiv = bhelper.GetElementByTagID("enterAddressAddressLine1");
                addressDiv.SetAttribute("value", linkdetail.Address);
            }
            if (linkdetail.Mobile.Length > 0)
            {
                HtmlElement mobileDiv = bhelper.GetElementByTagID("enterAddressPhoneNumber");
                mobileDiv.SetAttribute("value", linkdetail.Mobile);
            }
            if (linkdetail.Telephone.Length > 0)
            {
                HtmlElement telDiv = bhelper.GetElementByTagID("enterAddressPhoneNumber");
                telDiv.SetAttribute("value", linkdetail.Telephone);
            }
            if (linkdetail.Zip.Length > 0)
            {
                HtmlElement zipDiv = bhelper.GetElementByTagID("enterAddressPostalCode");
                zipDiv.SetAttribute("value", linkdetail.Zip);
            }
        }

        private string GetOrderinfo(BrowserHelper bhelper)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("<?xml version=\"1.0\" encoding=\"gb2312\"?><Order>");
            //送货人信息
            GetLinkInfo(builder, bhelper);
            //获得信息form
            System.Windows.Forms.HtmlElement payinfoDiv = bhelper.GetElementByTagID("SPCConfirmPurchaseForm");
            //获得主信息table
            IList<System.Windows.Forms.HtmlElement> mainTables = bhelper.GetHtmlElementChildrenByTagname(payinfoDiv, "TABLE");
            System.Windows.Forms.HtmlElement mainTable = mainTables[3];

            //获取主信息table中的信息块
            IList<System.Windows.Forms.HtmlElement> infoTables = bhelper.GetHtmlElementChildrenByTagname(mainTable, "TABLE");
            System.Windows.Forms.HtmlElement middleTable = infoTables[2];

            IList<System.Windows.Forms.HtmlElement> listTables = bhelper.GetHtmlElementChildrenByTagname(middleTable, "TABLE");

            IList<System.Windows.Forms.HtmlElement> detailTDs = bhelper.GetHtmlElementChildrenByTagname(listTables[0], "TD");

            IList<System.Windows.Forms.HtmlElement> tdTables = bhelper.GetHtmlElementChildrenByTagname(detailTDs[0], "TABLE");
            //商品列表
            System.Windows.Forms.HtmlElement productTable = tdTables[tdTables.Count - 2];
            GetProduct(builder, productTable, bhelper);
            //结算信息
            System.Windows.Forms.HtmlElement feeInfo = bhelper.GetElementByTagID("SPCSubtotals-marketplace");
            GetWare(builder, feeInfo, bhelper);
            builder.Append("</Order>");
            return builder.ToString();

        }

        private void GetWare(StringBuilder builder, HtmlElement sendinfoDiv, BrowserHelper bhelper)
        {
            builder.Append("<ware>");
            IList<HtmlElement> tds = bhelper.GetHtmlElementChildrenByTagname(sendinfoDiv, "TABLE");
            if (tds.Count > 0)
            {
                HtmlElement infoDiv = tds[0];
                IList<HtmlElement> LIs = bhelper.GetHtmlElementChildrenByTagname(infoDiv, "TD");
                //string infos = LIs[0].InnerText;
                //string jine = infos.Replace("商品金额：", "").Replace("￥", "");
                string goods = LIs[1].InnerText.Replace("￥", "").Trim();// jine.Substring(0, jine.IndexOf("元"));
                //string yuns = jine.Replace(goods, "").Replace("元 + 运费：", "").Replace("￥", "");
                string yunfee = LIs[3].InnerText.Replace("￥", "").Trim();
                string yhis = LIs[7].InnerText.Replace("-￥", "").Trim();
                //string lipins = LIs[7].InnerText.Replace("-￥", "").Trim();
                builder.Append("<amount>" + goods + "</amount>");
                builder.Append("<freight>" + yunfee + "</freight>");
                builder.Append("<off>" + yhis + "</off>");
                builder.Append("<goodscard></goodscard>");
            }
            builder.Append("</ware>");
        }

        private void GetProduct(StringBuilder builder, HtmlElement sendinfoDiv, BrowserHelper bhelper)
        {
            builder.Append("<products>");
            IList<HtmlElement> tds = bhelper.GetHtmlElementChildrenByTagname(sendinfoDiv, "TR");
            if (tds.Count > 1)
            {
                for (int i = 1; i < tds.Count;i=i+2)
                {
                    builder.Append("<product>");
                    IList<HtmlElement> tdproducts = bhelper.GetHtmlElementChildrenByTagname(tds[i], "SPAN");
                    HtmlElement detailinfo = tdproducts[0];
                    IList<HtmlElement> nameAndPrice = bhelper.GetHtmlElementChildrenByTagname(detailinfo, "B");
                    builder.Append("<productid></productid>");
                    builder.Append("<productname>" + nameAndPrice[0].InnerText + "</productname>");
                    builder.Append("<price>" + nameAndPrice[1].InnerText.Replace("￥","") + "</price>");
                    builder.Append("<returncash></returncash>");
                    builder.Append("<jifen></jifen>");
                    IList<HtmlElement> countSpan = bhelper.GetHtmlElementChildrenByTagname(detailinfo, "SPAN");
                    string counttext = countSpan[0].InnerText;// - 数量： 1 - 现在有货。
                    string[] countArr = counttext.Split(char.Parse("。"));
                    string countstr = countArr[0].Replace(" - 数量：", "");
                    string[] nowCountArr = countstr.Split(char.Parse("-"));
                    builder.Append("<stocktype>" + nowCountArr[nowCountArr.Length-1].Trim() + "</stocktype>");
                    builder.Append("<count>" + nowCountArr[0].Trim() + "</count>");
                    builder.Append("</product>");
                }
            }
            builder.Append("</products>");
        }

        private void GetLinkInfo(StringBuilder builder, BrowserHelper bhelper)
        {
            builder.Append("<sendinfo>");
            HtmlElementCollection tds = bhelper.GetElementByTagName("LI");
            builder.Append("<linkname>" + tds[0].InnerText + "</linkname>");
            builder.Append("<dirct>" + tds[2].InnerText + "</dirct>");
            builder.Append("<address>" + tds[1].InnerText + "</address>");
            builder.Append("<zip>" + tds[3].InnerText + "</zip>");
            builder.Append("<tel>" + tds[4].InnerText + "</tel>");
            builder.Append("<mobile>" + tds[4].InnerText + "</mobile>");
            builder.Append("<Email></Email>");
            builder.Append("</sendinfo>");
        }

        public void DoeditTicketAction()
        {
            throw new NotImplementedException();
        }

        public void DoTicketInfoAction(uni2uni.com.Model.Order_Order.OrderLinkDetail linkdetail)
        {
            confirmOrderEvent();
        }

        #endregion
    }
}
