﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using uni2uni.com.Model.Order_Order;
using uni2uni.com.BLL.Order_Order;


namespace WPFOrderWebHelper
{
    public class OrderHelper
    {

        public static string GetProductUrl(int infocode, Guid providerid)
        {
            uni2uni.com.DAL.GoodsInfo.SqlGoodsInfoDataProvider sqlGoodsInfoDataProvider = new uni2uni.com.DAL.GoodsInfo.SqlGoodsInfoDataProvider();
            uni2uni.com.Model.GoodsInfo.Entity.Entity_GoodsRelations relation = sqlGoodsInfoDataProvider.GetGoodsRelationsByInfoCode(infocode, providerid);
            if (relation != null && relation.SourceURL!=null)
            {
                return relation.SourceURL;
            }
            return "";
        }

        public static IList<uni2uni.com.Model.Order_Order.ProductOrderDetail> GetProductList(string orderid)
        {
            uni2uni.com.BLL.Order_Order.ProductOrderDetailBll productOrderDetailBll = new ProductOrderDetailBll();
            return productOrderDetailBll.SelectProductOrderDetailByOrderID(orderid);
        }

        public static uni2uni.com.Model.Order_Order.GeneralOrder GetOrder(string orderid)
        {
            uni2uni.com.BLL.Order_Order.GeneralOrderBll generalOrderBll = new GeneralOrderBll();
            return generalOrderBll.SelectGeneralOrderByOrderID(orderid);
        }

        public static uni2uni.com.Model.Order_Order.OrderLinkDetail GetOrderLinkDetail(string orderid)
        {
            uni2uni.com.BLL.Order_Order.OrderLinkDetailBll OrderLinkDetail = new uni2uni.com.BLL.Order_Order.OrderLinkDetailBll();
            return OrderLinkDetail.SelectOrderLinkDetailByOrderID(orderid);
        }

        public static IWebSiteOrder GetInstance(string providerid)
        {
            switch (providerid)
            {
                case "2bb6a65e-6b46-4726-8a6c-a9f1a6c75e78":
                    return new JingdongWebOrder();
                case "ae7bed47-1534-45ea-8557-fb58e58da72b":
                    return new AmazonWebOrder();
                default:
                    return null;
            }
        }
    }
}
