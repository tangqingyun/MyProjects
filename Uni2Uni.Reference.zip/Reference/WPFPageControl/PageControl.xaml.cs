﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace WPFPageControl
{
    /// <summary>
    /// UserControl1.xaml 的交互逻辑
    /// </summary>
    public partial class PageControl : UserControl
    {
        /// <summary>
        /// 注册总页数属性
        /// </summary>
        public static readonly DependencyProperty TotalPageCountProperty = 
            DependencyProperty.Register("TotalPageCount", typeof(int), typeof(PageControl), 
            new FrameworkPropertyMetadata(0, FrameworkPropertyMetadataOptions.AffectsRender, 
                new PropertyChangedCallback(OnTotalPageCountChanged),new CoerceValueCallback(CoerceValue)));

        /// <summary>
        /// 注册页数变化事件
        /// </summary>
        public static readonly RoutedEvent PageChangedEvent =
            EventManager.RegisterRoutedEvent("PageChanged",
             RoutingStrategy.Bubble, typeof(RoutedPropertyChangedEventHandler<int>), typeof(PageControl));

        /// <summary>
        /// 当前的数字按钮
        /// </summary>
        public Button CurrntPageNumberButton;
        /// <summary>
        /// 记录当前点击的页数
        /// </summary>
        private int oldPage = 1;

        public PageControl()
        {
            InitializeComponent();
            if (TotalPageCount > 1)
            {
                RaiseButtonClickEvent(button1);
            }
        }
        /// <summary>
        /// 定义页面总数
        /// </summary>
        [Description("获取或设置总页数")]
        [Category("Common Properties")]
        public int TotalPageCount
        {
            get { return (int)GetValue(TotalPageCountProperty); }
            set
            {
                SetValue(TotalPageCountProperty, 0);
                if (value > 0)
                {   
                    SetValue(TotalPageCountProperty, value);
                }
                else
                {
                    SetValue(TotalPageCountProperty, 1);
                }
            }
        }

        /// <summary>
        /// 定义页面变化事件
        /// </summary>
        [Description("当前页发生变化后发生")]
        public event RoutedPropertyChangedEventHandler<int> PageChanged
        {
            add
            {
                this.AddHandler(PageChangedEvent, value);
            }
            remove
            {
                this.RemoveHandler(PageChangedEvent, value);
            }
        }

        /// <summary>
        /// 引发页面变化事件
        /// </summary>
        /// <param name="oldValue"></param>
        /// <param name="newValue"></param>
        protected virtual void OnPageChanged(int oldValue, int newValue)
        {
            if (newValue > 0)
            {
                RoutedPropertyChangedEventArgs<int> arg =
                    new RoutedPropertyChangedEventArgs<int>(oldValue, newValue, PageChangedEvent);
                this.RaiseEvent(arg);
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether,获得最后一页的余数
        /// </summary>
        private int GetLastPage
        {
            get { return TotalPageCount % 5; }
        }

        /// <summary>
        ///总页数输入值检验回调
        /// </summary>
        /// <param name="element"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        private static object CoerceValue(DependencyObject element, object value)
        {
            int newValue = (int)value;
            
            newValue = Math.Max(0, Math.Min(int.MaxValue, newValue));

            return newValue;
        }

        /// <summary>
        /// 总页数变化回调
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="args"></param>
        private static void OnTotalPageCountChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            PageControl myControl = (PageControl)obj;
            int newValue = (int)args.NewValue;
            myControl.CurrntPageNumberButton = myControl.button1;
            if (newValue == 1)
            {
                myControl.OnPageChanged(1,1);
                myControl.Visibility = Visibility.Hidden;
                return;
            }
            else
            {
                myControl.Visibility = Visibility.Visible;
            }
            myControl.totalPage.Text = "共 " + newValue.ToString()+" 页";
            myControl.cPage.Text = "第 1 页";
            if (newValue > 1 && newValue < 6)
            {
                //PageButtonHidden(myControl);
                switch (newValue)
                {
                    case 2:
                        myControl.button3.Visibility = Visibility.Hidden;
                        myControl.button4.Visibility = Visibility.Hidden;
                        myControl.button5.Visibility = Visibility.Hidden;
                        break;
                    case 3:
                        myControl.button3.Visibility = Visibility.Visible;
                        myControl.button4.Visibility = Visibility.Hidden;
                        myControl.button5.Visibility = Visibility.Hidden;
                        break;
                    case 4:
                        myControl.button3.Visibility = Visibility.Visible;
                        myControl.button4.Visibility = Visibility.Visible;
                        myControl.button5.Visibility = Visibility.Hidden;
                        break;
                    case 5:
                        myControl.button3.Visibility = Visibility.Visible;
                        myControl.button4.Visibility = Visibility.Visible;
                        myControl.button5.Visibility = Visibility.Visible;
                        break;
                }
            }
            else
            {
                PageNumberButtonVisible(myControl);
                PageButtonVisible(myControl);
                PageNumberButtonSetBegin(myControl);
            }
            RaiseButtonClickEvent(myControl.button1);
        }

        /// <summary>
        /// 使页面控制按钮隐藏
        /// </summary>
        /// <param name="myControl"></param>
        private static void PageButtonHidden(PageControl myControl)
        {
            myControl.firstPage.Visibility = Visibility.Hidden;
            myControl.prePage.Visibility = Visibility.Hidden;
            myControl.lastPage.Visibility = Visibility.Hidden;
            myControl.nextPage.Visibility = Visibility.Hidden;
        }

        /// <summary>
        /// 使页面控制按钮可用
        /// </summary>
        /// <param name="myControl"></param>
        private static void PageButtonVisible(PageControl myControl)
        {
            myControl.firstPage.Visibility = Visibility.Visible;
            myControl.prePage.Visibility = Visibility.Visible;
            myControl.lastPage.Visibility = Visibility.Visible;
            myControl.nextPage.Visibility = Visibility.Visible;
        }

        /// <summary>
        /// 使页面数字按钮可用
        /// </summary>
        /// <param name="myControl"></param>
        private static void PageNumberButtonVisible(PageControl myControl)
        {
            myControl.button1.Visibility = Visibility.Visible;
            myControl.button2.Visibility = Visibility.Visible;
            myControl.button3.Visibility = Visibility.Visible;
            myControl.button4.Visibility = Visibility.Visible;
            myControl.button5.Visibility = Visibility.Visible;
        }

        /// <summary>
        /// 使页面数字按钮初始化
        /// </summary>
        /// <param name="myControl"></param>
        private static void PageNumberButtonSetBegin(PageControl myControl)
        {
            myControl.button1.Content = "1";
            myControl.button2.Content = "2";
            myControl.button3.Content = "3";
            myControl.button4.Content = "4";
            myControl.button5.Content = "5";
        }

        /// <summary>
        /// 首页按钮控件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void firstPage_Click(object sender, RoutedEventArgs e)
        {

            if (TotalPageCount < 6)
            {
                switch (TotalPageCount)
                {
                    case 2:
                        this.button1.Visibility = Visibility.Visible;
                        this.button1.Content = "1";
                        this.button2.Visibility = Visibility.Visible;
                        this.button2.Content = "2";
                        this.button3.Visibility = Visibility.Hidden;
                        this.button4.Visibility = Visibility.Hidden;
                        this.button5.Visibility = Visibility.Hidden;
                        break;
                    case 3:
                        this.button1.Visibility = Visibility.Visible;
                        this.button1.Content = "1";
                        this.button2.Visibility = Visibility.Visible;
                        this.button2.Content = "2";
                        this.button3.Visibility = Visibility.Visible;
                        this.button3.Content = "3";
                        this.button4.Visibility = Visibility.Hidden;
                        this.button5.Visibility = Visibility.Hidden;
                        break;
                    case 4:
                        this.button1.Visibility = Visibility.Visible;
                        this.button1.Content = "1";
                        this.button2.Visibility = Visibility.Visible;
                        this.button2.Content = "2";
                        this.button3.Visibility = Visibility.Visible;
                        this.button3.Content = "3";
                        this.button4.Visibility = Visibility.Visible;
                        this.button4.Content = "4";
                        this.button5.Visibility = Visibility.Hidden;
                        break;
                    default:
                        PageNumberButtonVisible(this);
                        PageNumberButtonSetBegin(this);
                        break;
                }
                
            }
            else
            {
                PageNumberButtonVisible(this);
                PageNumberButtonSetBegin(this);
            }
            this.CurrntPageNumberButton = this.button1;
            RaiseButtonClickEvent(this.button1);
        }

        /// <summary>
        /// 激发按钮的点击事件
        /// </summary>
        /// <param name="myButton">按钮控件</param>
        private static void RaiseButtonClickEvent(Button myButton)
        {
            myButton.Focus();
            RoutedEventArgs thise = new RoutedEventArgs();
            thise.RoutedEvent = Button.ClickEvent;
            thise.Source = myButton;
            myButton.RaiseEvent(thise);
        }

        /// <summary>
        /// 尾页按钮事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lastPage_Click(object sender, RoutedEventArgs e)
        {
            switch (GetLastPage)
            {
                case 0:
                    PageNumberButtonVisible(this);
                    this.button1.Content =  (TotalPageCount-4).ToString();
                    this.button2.Content = (TotalPageCount - 3).ToString();
                    this.button3.Content = (TotalPageCount - 2).ToString();
                    this.button4.Content = (TotalPageCount - 1).ToString();
                    this.button5.Content = TotalPageCount.ToString();
                    RaiseButtonClickEvent(this.button5);
                    break;
                case 1:
                    this.button1.Visibility = Visibility.Visible;
                    this.button1.Content = TotalPageCount.ToString();
                    this.button2.Visibility = Visibility.Hidden;
                    this.button3.Visibility = Visibility.Hidden;
                    this.button4.Visibility = Visibility.Hidden;
                    this.button5.Visibility = Visibility.Hidden;
                    RaiseButtonClickEvent(this.button1);
                    break;
                case 2:
                    this.button1.Visibility = Visibility.Visible;
                    this.button1.Content = (TotalPageCount - 1).ToString();
                    this.button2.Visibility = Visibility.Visible;
                    this.button2.Content = TotalPageCount.ToString();
                    this.button3.Visibility = Visibility.Hidden;
                    this.button4.Visibility = Visibility.Hidden;
                    this.button5.Visibility = Visibility.Hidden;
                    RaiseButtonClickEvent(this.button2);
                    break;
                case 3:
                    this.button1.Visibility = Visibility.Visible;
                    this.button1.Content = (TotalPageCount - 2).ToString();
                    this.button2.Visibility = Visibility.Visible;
                    this.button2.Content = (TotalPageCount - 1).ToString();
                    this.button3.Visibility = Visibility.Visible;
                    this.button3.Content = TotalPageCount.ToString();
                    this.button4.Visibility = Visibility.Hidden;
                    this.button5.Visibility = Visibility.Hidden;
                    RaiseButtonClickEvent(this.button3);
                    break;
                case 4:
                    this.button1.Visibility = Visibility.Visible;
                    this.button1.Content = (TotalPageCount - 3).ToString();
                    this.button2.Visibility = Visibility.Visible;
                    this.button2.Content = (TotalPageCount - 2).ToString();
                    this.button3.Visibility = Visibility.Visible;
                    this.button3.Content = (TotalPageCount - 1).ToString();
                    this.button4.Visibility = Visibility.Visible;
                    this.button4.Content = TotalPageCount.ToString();
                    this.button5.Visibility = Visibility.Hidden;
                    RaiseButtonClickEvent(this.button4);
                    break;

            }
        }

        /// <summary>
        /// 页码数字按钮控件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            this.CurrntPageNumberButton = (Button)e.Source;
            int currentPage = int.Parse(CurrntPageNumberButton.Content.ToString());
            this.cPage.Text = "第 " + currentPage.ToString() + " 页";
            this.OnPageChanged(oldPage, currentPage);
            oldPage = currentPage;
        }

        /// <summary>
        /// 上一页按钮事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void prePage_Click(object sender, RoutedEventArgs e)
        {
            if (CurrntPageNumberButton == this.button1)
            {
                if (oldPage > 5)
                {
                    PageNumberButtonVisible(this);
                    this.button1.Content = (oldPage - 5).ToString();
                    this.button2.Content = (oldPage - 4).ToString();
                    this.button3.Content = (oldPage - 3).ToString();
                    this.button4.Content = (oldPage - 2).ToString();
                    this.button5.Content = (oldPage - 1).ToString();
                    RaiseButtonClickEvent(this.button5);
                    return;
                }
                else
                {
                    RaiseButtonClickEvent(this.button1);
                }
            }
            if (CurrntPageNumberButton == this.button2)
            {
                RaiseButtonClickEvent(this.button1);
                return;
            }
            if (CurrntPageNumberButton == this.button3)
            {
                RaiseButtonClickEvent(this.button2);
                return;
            }
            if (CurrntPageNumberButton == this.button4)
            {
                RaiseButtonClickEvent(this.button3);
                return;
            }
            if (CurrntPageNumberButton == this.button5)
            {
                RaiseButtonClickEvent(this.button4);
                return;
            }
        }

        /// <summary>
        /// 下一页按钮事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void nextPage_Click(object sender, RoutedEventArgs e)
        {
            if (oldPage < TotalPageCount)
            {
                if (CurrntPageNumberButton == this.button1)
                {
                    RaiseButtonClickEvent(this.button2);
                    return;
                }
                if (CurrntPageNumberButton == this.button2)
                {
                    RaiseButtonClickEvent(this.button3);
                    return;
                }
                if (CurrntPageNumberButton == this.button3)
                {
                    RaiseButtonClickEvent(this.button4);
                    return;
                }
                if (CurrntPageNumberButton == this.button4)
                {
                    RaiseButtonClickEvent(this.button5);
                    return;
                }
                if (CurrntPageNumberButton == this.button5)
                {
                    int hasPage = TotalPageCount - oldPage;
                    switch (hasPage)
                    {

                        case 1:
                            this.button1.Visibility = Visibility.Visible;
                            this.button1.Content = (oldPage + 1).ToString();
                            this.button2.Visibility = Visibility.Hidden;
                            this.button3.Visibility = Visibility.Hidden;
                            this.button4.Visibility = Visibility.Hidden;
                            this.button5.Visibility = Visibility.Hidden;
                            RaiseButtonClickEvent(this.button1);
                            break;
                        case 2:
                            this.button1.Visibility = Visibility.Visible;
                            this.button1.Content = (oldPage + 1).ToString();
                            this.button2.Visibility = Visibility.Visible;
                            this.button2.Content = (oldPage + 2).ToString();
                            this.button3.Visibility = Visibility.Hidden;
                            this.button4.Visibility = Visibility.Hidden;
                            this.button5.Visibility = Visibility.Hidden;
                            RaiseButtonClickEvent(this.button1);
                            break;
                        case 3:
                            this.button1.Visibility = Visibility.Visible;
                            this.button1.Content = (oldPage + 1).ToString();
                            this.button2.Visibility = Visibility.Visible;
                            this.button2.Content = (oldPage + 2).ToString();
                            this.button3.Visibility = Visibility.Visible;
                            this.button3.Content = (oldPage + 3).ToString();
                            this.button4.Visibility = Visibility.Hidden;
                            this.button5.Visibility = Visibility.Hidden;
                            RaiseButtonClickEvent(this.button1);
                            break;
                        case 4:
                            this.button1.Visibility = Visibility.Visible;
                            this.button1.Content = (oldPage + 1).ToString();
                            this.button2.Visibility = Visibility.Visible;
                            this.button2.Content = (oldPage + 2).ToString();
                            this.button3.Visibility = Visibility.Visible;
                            this.button3.Content = (oldPage + 3).ToString();
                            this.button4.Visibility = Visibility.Visible;
                            this.button4.Content = (oldPage + 4).ToString();
                            this.button5.Visibility = Visibility.Hidden;
                            RaiseButtonClickEvent(this.button1);
                            break;
                        default:
                            PageNumberButtonVisible(this);
                            this.button1.Content = (oldPage + 1).ToString();
                            this.button2.Content = (oldPage + 2).ToString();
                            this.button3.Content = (oldPage + 3).ToString();
                            this.button4.Content = (oldPage + 4).ToString();
                            this.button5.Content = (oldPage + 5).ToString();
                            RaiseButtonClickEvent(this.button1);
                            break;
                    }
                }
            }
            else
            {
                RaiseButtonClickEvent(CurrntPageNumberButton);
            }
        }
    }
}
