﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace WPFPageControl
{
    /// <summary>
    /// AutoCompleteTextBox.xaml 的交互逻辑
    /// </summary>
    public partial class AutoCompleteTextBox : Canvas
    {
        #region Members
        private VisualCollection controls;
        private TextBox textBox;
        private ComboBox comboBox;
        private ObservableCollection<AutoCompleteEntry> autoCompletionList;
        private System.Timers.Timer keypressTimer;
        private delegate void TextChangedCallback();
        private bool insertText;
        private int delayTime;
        private int searchThreshold;
        private int dropCount;// 下拉数量
        private bool changText = false; //控件文本是否改变过
        private string OrigalText = string.Empty;//Text属性所赋的值
        private bool isOpenWaterMark;
        #endregion

        #region Constructor
        public AutoCompleteTextBox()
        {
            controls = new VisualCollection(this);
            InitializeComponent();

            autoCompletionList = new ObservableCollection<AutoCompleteEntry>();
            searchThreshold = 1;        // default threshold to 1 char
            dropCount = 10;             //default dropCount is 10
            // set up the key press timer
            keypressTimer = new System.Timers.Timer();
            keypressTimer.Elapsed += new System.Timers.ElapsedEventHandler(OnTimedEvent);

            // set up the text box and the combo box
            comboBox = new ComboBox();
            comboBox.IsSynchronizedWithCurrentItem = true;
            comboBox.IsTabStop = false;
            comboBox.SelectionChanged += new SelectionChangedEventHandler(comboBox_SelectionChanged);

            textBox = new TextBox();
            textBox.TextWrapping = TextWrapping.Wrap;
            textBox.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            textBox.TextChanged += new TextChangedEventHandler(textBox_TextChanged);
            textBox.PreviewKeyDown += new KeyEventHandler(textBox_PreviewKeyDown);
            textBox.KeyDown += new KeyEventHandler(textBox_KeyDown);
            textBox.GotFocus += new RoutedEventHandler(textBox_GotFocus);
            textBox.LostFocus += new RoutedEventHandler(textBox_LostFocus);
            textBox.VerticalContentAlignment = VerticalAlignment.Top;
            textBox.Style = (Style)this.FindResource("searchTextBoxStyle");
            controls.Add(comboBox);
            controls.Add(textBox);
        }

        #endregion

        #region Methods

        public int MaxLength
        {
            get { return textBox.MaxLength; }
            set { textBox.MaxLength = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether,设置输入文本框的纵向滚动条
        /// </summary>
        public ScrollBarVisibility VerticalScrollBarVisibility
        {
            get { return textBox.VerticalScrollBarVisibility; }
            set { textBox.VerticalScrollBarVisibility = value; }
        }

        /// <summary>
        ///  Gets or sets a value indicating whether ,是否允许换行
        ///  </summary>
        public bool AcceptsReturn
        {
            set { textBox.AcceptsReturn = value; }
            get { return textBox.AcceptsReturn; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether,联想词下拉个数
        /// </summary>
        public int DropCount
        {
            get { return dropCount; }
            set { dropCount = value; }
        }

        /// <summary>
        ///Gets or sets a value indicating whether,设置默认文本
        /// </summary>
        public string Text
        {
            get { return textBox.Text; }
            set
            {
                insertText = true;
                textBox.Text = value;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether,设置输入等待时间
        /// </summary>
        public int DelayTime
        {
            get { return delayTime; }
            set { delayTime = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether,设置联想词字符数
        /// </summary>
        public int Threshold
        {
            get { return searchThreshold; }
            set { searchThreshold = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether,设置是否打开水印功能
        /// </summary>
        public bool IsOpenWaterMark
        {
            get { return isOpenWaterMark; }
            set { isOpenWaterMark = value; }
        }

        /// <summary>
        /// 添加一个联想词
        /// </summary>
        /// <param name="entry"></param>
        public void AddItem(AutoCompleteEntry entry)
        {
            autoCompletionList.Add(entry);
        }

        /// <summary>
        /// 清除缓存中的联想词
        /// </summary>
        public void Clear()
        {
            autoCompletionList.Clear();
        }

        void textBox_KeyDown(object sender, KeyEventArgs e)
        {
            changText = true;
        }

        void textBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (comboBox.IsDropDownOpen == true) //如果没有出现下来联想词，就会移动光标
                if (e.Key == Key.Down)
                    comboBox.Focus();
        }
        void textBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (IsOpenWaterMark && textBox.Text.Length <= 0)
            {

                textBox.Text = OrigalText;

            }
        }
        void textBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (IsOpenWaterMark && (OrigalText.Length <= 0 || textBox.Text == OrigalText) && textBox.Text.Length < 3)
            {
                OrigalText = textBox.Text;
                textBox.Text = "";
            }
        }
        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (null != comboBox.SelectedItem)
            {
                insertText = true;
                ComboBoxItem cbItem = (ComboBoxItem)comboBox.SelectedItem;
                textBox.Text = cbItem.Content.ToString();
                textBox.Focus();
            }
        }

        private void TextChanged()
        {
            try
            {
                comboBox.Items.Clear();
                if (textBox.Text.Trim().Length >= searchThreshold)
                {
                    foreach (AutoCompleteEntry entry in autoCompletionList)
                    {
                        foreach (string word in entry.KeywordStrings)
                        {
                            // if (word.StartsWith(textBox.Text, StringComparison.CurrentCultureIgnoreCase))
                            if (word.Trim().ToUpper().Contains(textBox.Text.Trim().ToUpper()))
                            {
                                ComboBoxItem cbItem = new ComboBoxItem();
                                cbItem.Content = entry.ToString();
                                if (comboBox.Items.Count <= DropCount)
                                    comboBox.Items.Add(cbItem);
                                break;
                            }
                        }
                    }
                    comboBox.IsDropDownOpen = comboBox.HasItems;
                }
                else
                {
                    comboBox.IsDropDownOpen = false;
                }
            }
            catch { }
        }

        private void OnTimedEvent(object source, System.Timers.ElapsedEventArgs e)
        {
            keypressTimer.Stop();
            Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal,
                new TextChangedCallback(this.TextChanged));
        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (textBox.Text == OrigalText && IsOpenWaterMark)
            {
                return;
            }
            // text was not typed, do nothing and consume the flag
            if (insertText == true) insertText = false;

            // if the delay time is set, delay handling of text changed
            else
            {
                if (delayTime > 0)
                {
                    keypressTimer.Interval = delayTime;
                    keypressTimer.Start();
                }
                else TextChanged();
            }
        }

        protected override Size ArrangeOverride(Size arrangeSize)
        {
            textBox.Arrange(new Rect(arrangeSize));
            comboBox.Arrange(new Rect(arrangeSize));
            return base.ArrangeOverride(arrangeSize);
        }

        protected override Visual GetVisualChild(int index)
        {
            return controls[index];
        }

        protected override int VisualChildrenCount
        {
            get { return controls.Count; }
        }
        #endregion
    }
}
