﻿using System;
using System.Collections.Generic;
using System.Text;
using uni2uni.com.Model.Order.Entity;


namespace WebbrowserControl
{
    public interface IOrderInfo
    {
        IList<Entity_GeneralOrder> GeneralOrderList { get; set; }//订单供货商产品信息
        //创建5种订单类型的IList
        IList<Entity_ProductOrderDetail> ProductOrderDetailList{get;set;}//产品
        IList<Entity_FOPassenger> FOPassengerList { get; set; }//机票
        IList<Entity_FOFlighting> FOFlightingList { get; set; }//机票
        IList<Entity_HotelOrderPrice> HotelOrderPriceList { get; set; }//酒店
        IList<Entity_HotelOrderDetail> HotelOrderDetailList { get; set; }//酒店
        IList<Entity_RESTOrder> RESTOrderList { get; set; }//餐饮

        Entity_Order Order { get; set; }//订单信息
        Entity_OrderLinkDetail OrderLinkDetail { get; set; }//订单联系人信息

        /// <summary>
        /// 将取得的订单信息转成订单
        /// </summary>
        /// <param name="infoXml">订单信息</param>
        /// <param name="providerID">供应商ID</param>
        /// <param name="channelID">频道ID</param>
        void GetInfoFromXml(string infoXml, string providerID, string channelID);

    }
}
