﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WebbrowserControl
{
    public partial class WebbrowserControl : UserControl
    {

        public WebbrowserControl()
        {
            InitializeComponent();
            this.SetTopLevel(false);
            this.tabControl1.TabPages.Clear();
            
            this.tabControl1.Appearance = TabAppearance.Buttons;
            this.tabControl1.TabIndexChanged += new EventHandler(tabControl1_TabIndexChanged);
        }

        void tabControl1_TabIndexChanged(object sender, EventArgs e)
        {
            BrowserTabPage currentpage = this.tabControl1.SelectedTab as BrowserTabPage;
            string sname = currentpage.Text;
            foreach (IWebSite website in controlWebSite)
            {
                if (website.WebSiteName.Equals(sname))
                {
                    currentWebSite = website;
                    break;
                }
            }
        }

        private IList<IWebSite> controlWebSite = new List<IWebSite>();

        private IWebSite currentWebSite;

        private string tagName;

        public string TagName
        {
            get { return tagName; }
        }

        public IWebSite CurrentWebSite
        {
            get { return currentWebSite; }
        }

        public void DisplayChanel(string sTagName)
        {
            if (sTagName.Length > 0)
            {
                tagName = sTagName;
                
            }
            else
            {
                tagName = "产品";
            }
            SetBrowser();
        }

        private void SetBrowser()
        {
            ConfigHelper helper = new ConfigHelper();
            IWebSite[] mySites = helper.GetSiteByChannel(tagName).ToArray<IWebSite>();
            if (mySites == null || mySites.Length == 0)
            {
                tagName = "产品";
                mySites = helper.GetSiteByChannel(tagName).ToArray<IWebSite>();
            }
            SetWebSite(mySites);
        }

        public void SetWebSite(params IWebSite[] weblist)
        {
            if (weblist.Length > 0)
            {
                this.tabControl1.TabPages.Clear();
                for (int i = 0; i < weblist.Length; i++)
                {
                    weblist[i].BrowserPage.Text = weblist[i].WebSiteName;
                    weblist[i].BrowserPage.BrowserURL = new Uri(weblist[i].HomePage);
                    this.tabControl1.TabPages.Add(weblist[i].BrowserPage);
                }
                this.controlWebSite =new List<IWebSite>(weblist);
                this.currentWebSite = weblist[0];
            }
        }
    }
}
