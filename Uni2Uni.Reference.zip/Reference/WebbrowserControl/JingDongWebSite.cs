﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WebbrowserControl
{
    public class JingDongWebSite:IWebSite
    {
        #region IWebSite 成员

        private string websiteName = "京东商城";

        private string providerID;

        private string chanelidID;

        private string homePage = "http://www.360buy.com";

        private BrowserTabPage thisPage;

        private IOrderInfo orderInfo;

        private string siteUserName;

        private string siteUserPassword;

        public JingDongWebSite(string channelID,string webname,string pid,string home,string username,string password)
        {
            chanelidID = channelID;
            websiteName = webname;
            providerID = pid;
            homePage = home;
            siteUserName = username;
            siteUserPassword = password;
            thisPage = new BrowserTabPage();
            orderInfo = new JingDongOrderInfo();
        }

        public string ProviderID
        {
            get { return providerID; }
        }
        public string WebSiteName
        {
            get { return websiteName; }
        }

        public string HomePage
        {
            get { return homePage; }
        }

        public string SiteUserName
        {
            get { return siteUserName; }
        }

        public string SiteUserPassword
        {
            get { return siteUserPassword; }
        }


        public BrowserTabPage BrowserPage
        {
            get 
            {
                return thisPage;
            }
        }


        public void SetUsernameAndPassword()
        {
            if (BrowserPage.BrowserURL.OriginalString.StartsWith("https://passport.360buy.com/new/login.aspx"))
            {
                BrowserPage.SetElementText("loginname", SiteUserName);
                BrowserPage.SetElementText("loginpwd", SiteUserPassword);
                BrowserPage.RaiseElementEvent("loginsubmit", "click");
            }
            else if (BrowserPage.BrowserURL.OriginalString.StartsWith("http://jd2008.360buy.com/purchase/shoppingcart"))
            {
                System.Windows.Forms.HtmlDocument doc = BrowserPage.BrowserDocument;
                if (doc != null)
                {
                    System.Windows.Forms.HtmlWindowCollection frames = doc.Window.Frames;
                    frames[1].Document.GetElementById("loginname").InnerText = SiteUserName;
                    frames[1].Document.GetElementById("loginpwd").InnerText = SiteUserPassword;
                    frames[1].Document.GetElementById("loginsubmitframe").InvokeMember("click");
                }
            }
        }

       
        public void Query(System.Collections.Hashtable conditionTable)
        {
            StringBuilder builder = new StringBuilder();
            foreach (string valueString in conditionTable.Values)
            {
                builder.Append(" " + valueString);
            }
            BrowserPage.SetElementText("key", builder.ToString());
            BrowserPage.RaiseElementEvent("btn-search", "click");
        }

        public void SetLinkInfo(System.Collections.Hashtable linkinfoTable)
        {
            if (BrowserPage.BrowserURL.OriginalString.StartsWith("http://jd2008.360buy.com/purchase/orderinfo_pop_main.aspx"))
            {                                      
                string name = linkinfoTable["name"].ToString();
                string address = linkinfoTable["address"].ToString();
                string mobile = linkinfoTable["mobile"].ToString();
                string zip = linkinfoTable["zip"].ToString();
                string tel = linkinfoTable["tel"].ToString();
                string email = linkinfoTable["email"].ToString();
                HtmlElement passDiv = BrowserPage.GetElementByTagID("consignee_addressName");
                passDiv.SetAttribute("value", name);
                HtmlElement addressDiv = BrowserPage.GetElementByTagID("consignee_address");
                addressDiv.SetAttribute("value", address);
                HtmlElement mobileDiv = BrowserPage.GetElementByTagID("consignee_message");
                mobileDiv.SetAttribute("value", mobile);
                HtmlElement telDiv = BrowserPage.GetElementByTagID("consignee_phone");
                telDiv.SetAttribute("value", tel);
                HtmlElement emailDiv = BrowserPage.GetElementByTagID("consignee_email");
                emailDiv.SetAttribute("value", email);
                HtmlElement zipDiv = BrowserPage.GetElementByTagID("consignee_postcode");
                zipDiv.SetAttribute("value", zip);
            }
        }

        public void SetCustomerInfo(System.Collections.Hashtable customerInfoTable)
        {
            throw new NotImplementedException();
        }

        public string GetOrderinfo()
        {
            if (BrowserPage.BrowserURL.OriginalString.StartsWith("http://jd2008.360buy.com/purchase/orderinfo_pop_main.aspx"))
            {
                StringBuilder builder = new StringBuilder();
                builder.Append("<?xml version=\"1.0\" encoding=\"gb2312\"?><Order>");
                //送货人信息
                System.Windows.Forms.HtmlElement sendinfoDiv = BrowserPage.GetElementByTagID("part_consignee");
                GetLinkInfo(builder, sendinfoDiv);
                //支付及配送信息
                System.Windows.Forms.HtmlElement payinfoDiv = BrowserPage.GetElementByTagID("part_payTypeAndShipType");
                GetPayInfo(builder, payinfoDiv);
                //发票信息
                System.Windows.Forms.HtmlElement invoiceDiv = BrowserPage.GetElementByTagID("part_invoice");
                GetInvoiceinfo(builder, invoiceDiv);
                //备注
                System.Windows.Forms.HtmlElement attchDiv = BrowserPage.GetElementByTagID("part_remark");
                GetRemark(builder, attchDiv);
                //商品列表
                System.Windows.Forms.HtmlElement productInfo = BrowserPage.GetElementByTagID("part_cart");
                GetProduct(builder, productInfo);
                //结算信息
                System.Windows.Forms.HtmlElement feeInfo = BrowserPage.GetElementByTagID("ware_info");
                GetWare(builder, feeInfo);
                builder.Append("</Order>");
                return builder.ToString();
            }
            return "";
        }
        private void GetWare(StringBuilder builder, HtmlElement sendinfoDiv)
        {
            builder.Append("<ware>");
            IList<HtmlElement> tds = Utility.GetHtmlElementChildrenByTagname(sendinfoDiv, "DIV");
            if (tds.Count > 0)
            {
                HtmlElement infoDiv = tds[1];
                IList<HtmlElement> LIs = Utility.GetHtmlElementChildrenByTagname(infoDiv, "LI");
                string infos = LIs[0].InnerText;
                string jine = infos.Replace("商品金额：", "").Replace("￥","");
                string goods = jine.Substring(0, jine.IndexOf("元"));
                string yuns = jine.Replace(goods, "").Replace("元 + 运费：", "").Replace("￥", "");
                string yunfee = yuns.Substring(0, yuns.IndexOf("元"));
                IList<HtmlElement> Spans = Utility.GetHtmlElementChildrenByTagname(infoDiv, "SPAN");
                string yhis = Spans[0].InnerText;
                string lipins = Spans[1].InnerText;
                builder.Append("<amount>" + goods + "</amount>");
                builder.Append("<freight>" + yunfee + "</freight>");
                builder.Append("<off>" + yhis + "</off>");
                builder.Append("<goodscard>" + lipins + "</goodscard>");
            }
            builder.Append("</ware>");
        }

        private void GetProduct(StringBuilder builder, HtmlElement sendinfoDiv)
        {
            builder.Append("<products>");
            IList<HtmlElement> tds = Utility.GetHtmlElementChildrenByTagname(sendinfoDiv, "TR");
            if (tds.Count > 0)
            {
                for (int i = 1; i < tds.Count; i++)
                {
                    builder.Append("<product>");
                    IList<HtmlElement> tdproducts = Utility.GetHtmlElementChildrenByTagname(tds[i], "TD");
                    builder.Append("<productid>" + tdproducts[0].InnerText + "</productid>");
                    builder.Append("<productname>" + tdproducts[1].InnerText + "</productname>");
                    builder.Append("<price>" + tdproducts[2].InnerText + "</price>");
                    builder.Append("<returncash>" + tdproducts[3].InnerText + "</returncash>");
                    builder.Append("<jifen>" + tdproducts[4].InnerText + "</jifen>");
                    builder.Append("<stocktype>" + tdproducts[5].InnerText + "</stocktype>");
                    builder.Append("<count>" + tdproducts[6].InnerText + "</count>");
                    builder.Append("</product>");
                }
            }
            builder.Append("</products>");
        }
        private void GetRemark(StringBuilder builder, HtmlElement sendinfoDiv)
        {
            builder.Append("<remark>");
            IList<HtmlElement> tds = Utility.GetHtmlElementChildrenByTagname(sendinfoDiv, "TD");
            builder.Append("<remark>" + tds[0].InnerText + "</remark>");
            builder.Append("</remark>");
        }
        private void GetPayInfo(StringBuilder builder, HtmlElement sendinfoDiv)
        {
            builder.Append("<payinfo>");
            IList<HtmlElement> tds = Utility.GetHtmlElementChildrenByTagname(sendinfoDiv, "TD");
            builder.Append("<paytype>" + tds[1].InnerText + "</paytype>");
            builder.Append("<sendtype>" + tds[3].InnerText + "</sendtype>");
            builder.Append("<freight>" + tds[5].InnerText + "</freight>");
            builder.Append("<sendtime>" + tds[7].InnerText + "</sendtime>");
            builder.Append("</payinfo>");
        }

        

        private void GetInvoiceinfo(StringBuilder builder, HtmlElement sendinfoDiv)
        {
            builder.Append("<invoice>");
            //HtmlDocument doc = sendinfoDiv.Document;
            IList<HtmlElement> tds = Utility.GetHtmlElementChildrenByTagname(sendinfoDiv, "TD");
            builder.Append("<invtype>" + tds[1].InnerText + "</invtype>");
            builder.Append("<invtitle>" + tds[3].InnerText + "</invtitle>");
            builder.Append("<invdetail>" + tds[5].InnerText + "</invdetail>");
            builder.Append("</invoice>");
        }
        private void GetLinkInfo(StringBuilder builder, HtmlElement sendinfoDiv)
        {
            builder.Append("<sendinfo>");
            HtmlDocument doc = sendinfoDiv.Document;
            HtmlElementCollection tds = doc.GetElementsByTagName("TD");
            builder.Append("<linkname>"+tds[1].InnerText+"</linkname>");
            builder.Append("<dirct>" + tds[3].InnerText + "</dirct>");
            builder.Append("<address>" + tds[5].InnerText + "</address>");
            builder.Append("<zip>" + tds[7].InnerText + "</zip>");
            builder.Append("<tel>" + tds[9].InnerText + "</tel>");
            builder.Append("<mobile>" + tds[11].InnerText + "</mobile>");
            builder.Append("<Email>" + tds[13].InnerText + "</Email>");
            builder.Append("</sendinfo>");
        }
        public string GetPayInfo()
        {
            throw new NotImplementedException();
        }

        public IOrderInfo OrderInfo
        {
            get { return orderInfo; }
        }

        


        public string ChannelID
        {
            get { return chanelidID; }
        }

        public void Reload()
        {
            this.thisPage.Reload();
        }

        #endregion
    }
}
