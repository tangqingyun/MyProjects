﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WebbrowserControl
{
    public class Utility
    {
        public static Guid GetCurrentUserID()
        {
            return new Guid("e389bded-32e8-44c4-aad6-4aef40630f89");
        }

        public static IList<HtmlElement> GetHtmlElementChildrenByTagname(HtmlElement sendinfoDiv, string typename)
        {
            HtmlElementCollection tds = sendinfoDiv.All;
            IList<HtmlElement> collection = new List<HtmlElement>();
            foreach (HtmlElement element in tds)
            {
                if (element.TagName.Equals(typename))
                {
                    collection.Add(element);
                }
            }
            return collection;
        }

        public static IList<HtmlElement> GetHtmlElementChildrenIncludeID(HtmlElement sendinfoDiv, string typename,string substr)
        {
            HtmlElementCollection tds = sendinfoDiv.All;
            IList<HtmlElement> collection = new List<HtmlElement>();
            foreach (HtmlElement element in tds)
            {
                if (element.TagName.Equals(typename))
                {
                    if (element.Id!=null&&element.Id.IndexOf(substr) >= 0)
                    {
                        collection.Add(element);
                    }
                }
            }
            return collection;
        }
    }
}
