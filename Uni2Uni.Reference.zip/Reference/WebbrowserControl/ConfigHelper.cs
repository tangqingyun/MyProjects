﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Reflection;

namespace WebbrowserControl
{
    public class ConfigHelper
    {
        private XmlDocument doc;
        
        public ConfigHelper()
        {
            doc = new XmlDocument();
            doc.Load("SiteConfig.xml");
        }

        private XmlNode GetChannelNode(string name)
        {

            return doc.SelectSingleNode("/config/Channel[@name=\"" + name + "\"]");
            
        }

        private XmlNodeList GetChannelSite(string name)
        {
            return doc.SelectNodes("/config/Channel[@name=\"" + name + "\"]/Site");
        }

        public IList<IWebSite> GetSiteByChannel(string channelName)
        {
            XmlNode cNode = GetChannelNode(channelName);
            string cID = cNode.Attributes["ID"].Value;
            IList<IWebSite> siteList = new List<IWebSite>();
            //XmlNode 
            XmlNodeList nodeList = GetChannelSite(channelName);
            for (int i = 0; i < nodeList.Count; i++)
            {
                XmlAttributeCollection attributes = nodeList[i].Attributes;
                string webname = attributes["name"].Value;
                string id = attributes["ID"].Value;
                string homePage = attributes["homepage"].Value;
                string loadDll = attributes["Dll"].Value;
                string classname = attributes["class"].Value;
                string username = attributes["username"].Value;
                string password = attributes["password"].Value;

                IWebSite dalObject = Activator.CreateInstance(System.Type.GetType(classname), new string[] { cID,webname, id, homePage, username, password }) as IWebSite; 
                if (dalObject != null)
                {
                    siteList.Add(dalObject);
                }
            }
            return siteList;
        }
        
    }
}
