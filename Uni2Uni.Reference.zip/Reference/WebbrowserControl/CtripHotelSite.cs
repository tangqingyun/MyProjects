﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WebbrowserControl
{
    public class CtripHotelSite:IWebSite
    {
        #region IWebSite 成员

        private string websiteName = "携程";

        private string chanelidID;

        private string providerID;

        private string homePage = "http://www.ctrip.com";

        private BrowserTabPage thisPage;

        private IOrderInfo orderInfo;

        private string siteUserName;

        private string siteUserPassword;

        public CtripHotelSite(string channelid,string webname, string pid, string home,string username,string password)
        {
            chanelidID = channelid;
            websiteName = webname;
            providerID = pid;
            homePage = home;
            siteUserName = username;
            siteUserPassword = password;
            thisPage = new BrowserTabPage();
            orderInfo = new CtripHotelOrderInfo();
        }

        public string ProviderID
        {
            get { return providerID; }
        }
        public string WebSiteName
        {
            get { return websiteName; }
        }

        public string HomePage
        {
            get { return homePage; }
        }

        public string SiteUserName
        {
            get { return siteUserName; }
        }

        public string SiteUserPassword
        {
            get { return siteUserPassword; }
        }

        public IOrderInfo OrderInfo
        {
            get { return orderInfo; }
        }

        public BrowserTabPage BrowserPage
        {
            get 
            {
                return thisPage;
            }
        }

        public void SetUsernameAndPassword()
        {
            if (BrowserPage.BrowserURL.OriginalString.StartsWith("http://www.ctrip.com/Member/Login.asp"))
            {
                BrowserPage.SetElementText("signin_uid", SiteUserName);
                BrowserPage.SetElementText("signin_pwd", SiteUserPassword);
                BrowserPage.RaiseElementEvent("loginBtn", "click");
            }
            else if (BrowserPage.BrowserURL.OriginalString.StartsWith("http://www.ctrip.com/Member/PostLogin.asp"))
            {
                BrowserPage.SetElementText("signin_uid", SiteUserName);
                BrowserPage.SetElementText("signin_pwd", SiteUserPassword);
                BrowserPage.RaiseElementEvent("loginBtn", "click");
            }
        }

        public void Query(System.Collections.Hashtable conditionTable)
        {
            string sCity = "";
            string bdate = "";
            string edate = "";
            if (conditionTable.ContainsKey("city"))
            {
                sCity = conditionTable["city"].ToString();
            }
            if (conditionTable.ContainsKey("bdate"))
            {
                bdate = conditionTable["bdate"].ToString();
            }
            if (conditionTable.ContainsKey("edate"))
            {
                edate = conditionTable["edate"].ToString();
            }
            //BrowserPage.SetElementAttribute("txtCity","value", sCity);
            //BrowserPage.SetElementAttribute("txtCheckIn", "value", bdate);
            //BrowserPage.SetElementAttribute("txtCheckOut", "value", edate);
            //HtmlElement element = BrowserPage.BrowserDocument.Forms[0];
            //element.InvokeMember("Submit");
            GetScript(sCity, bdate, edate);
            if (conditionTable.ContainsKey("hotelname"))
            {
                HtmlElement ename = BrowserPage.GetElementByTagID("txtHotelName");
                ename.OuterHtml = "<input id=\"txtHotelName\" class=\"input_text\" mod=\"notice\" mod_notice_tip=\"中文/拼音首字母\""+
                    " type=\"text\" value=\"" + conditionTable["hotelname"] + "\" style=\"width: 216px;\" autocomplete=\"off\" />";
            }

            if (conditionTable.ContainsKey("lowprice"))
            {
                HtmlElement elow = BrowserPage.GetElementByTagID("txtPriceLow");
                elow.OuterHtml = "<input id=\"txtPriceLow\" class=\"input_text\" name=\"txtPriceLow\" " +
                    " type=\"text\" value=\"" + conditionTable["lowprice"] + "\" style=\"width: 91px;\" />";
            }
            if (conditionTable.ContainsKey("highprice"))
            {
                HtmlElement ehigh = BrowserPage.GetElementByTagID("txtPriceHigh");
                ehigh.OuterHtml = "<input id=\"txtPriceHigh\" class=\"input_text\" name=\"txtPriceHigh\" " +
                    " type=\"text\" value=\"" + conditionTable["highprice"] + "\" style=\"width: 91px;\" />";
            }
            if (conditionTable.ContainsKey("area"))
            {
                HtmlElement earea = BrowserPage.GetElementByTagID("txtArea");
                earea.OuterHtml = "<input type=\"text\" style=\"width: 216px;\" value=\"" + conditionTable["area"] + "\" readonly=\"readonly\" " +
                    "id=\"txtArea\" class=\"input_text\" />";
            }
            //HtmlElement element = BrowserPage.BrowserDocument.Forms[0];
            //element.InvokeMember("submit");
            //BrowserPage.BrowserDocument.InvokeScript("doTxtCityChange");
            HtmlElement ecity = BrowserPage.GetElementByTagID("selCity");
            ecity.OuterHtml = "<ul class=\"index_area\" id=\"selCity\">" +
                "<li tabindex=\"1000\" id=\"_101\" class=\"on\">Beijing&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;北京</li></ul>";
            
        }
        private void GetScript(string city, string bdate, string edate)
        {
            HtmlDocument doc = BrowserPage.BrowserDocument;
            HtmlElement ecity = doc.GetElementById("txtCity");
            ecity.OuterHtml = "<input id=\"txtCity\" class=\"input_text\" mod=\"notice|address\" mod_address_source=\"hotel\"" +
                " mod_address_auto=\"false\" mod_address_hook=\"onchange:doTxtCityChange\" mod_address_reference=\"hidCity\"" +
                " mod_notice_tip=\"中文/拼音\" autocomplete=\"off\" mod_address_suggest=\"@Beijing|北京|101@Shanghai" +
                "|上海|102@Guangzhou|广州|132@Shenzhen|深圳|130@Hangzhou|杭州|117@Nanjing|南京|112@Chengdu|成都|128@Hong Kong" +
                "|香港|158@Qingdao|青岛|107@Wuhan|武汉|577@Xiamen|厦门|125@Dalian|大连|106@\" style=\"width: 216px;\" value=\"" + city + "\" />";

            HtmlElement ebdate = doc.GetElementById("txtCheckIn");
            ebdate.OuterHtml = "<input id=\"txtCheckIn\" class=\"input_text\" mod=\"notice|calendar\" mod_notice_tip=\"yyyy-mm-dd\"" +
                " mod_calendar_focusnext=\"true\" mod_calendar_rangestart=\"#\" autocomplete=\"off\" type=\"text\" " +
                "value=\"" + bdate + "\" style=\"width: 70px;\" />";

            HtmlElement eedate = doc.GetElementById("txtCheckOut");
            eedate.OuterHtml = "<input id=\"txtCheckOut\" class=\"input_text\" name=\"txtCheckOut\" mod=\"notice|calendar\" " +
                "mod_notice_tip=\"yyyy-mm-dd\" mod_calendar_reference=\"txtCheckIn\" mod_calendar_rangestart=\"#\" " +
                "autocomplete=\"off\" type=\"text\" value=\"" + edate + "\" style=\"width: 70px;\" />";
        }

        public void SetLinkInfo(System.Collections.Hashtable linkinfoTable)
        {
            if (BrowserPage.BrowserURL.OriginalString.StartsWith("http://hotels.ctrip.com/Domestic/InputNewOrder.aspx"))
            {
                string name = linkinfoTable["name"].ToString();
                string address = linkinfoTable["address"].ToString();
                string mobile = linkinfoTable["mobile"].ToString();
                string zip = linkinfoTable["zip"].ToString();
                string tel = linkinfoTable["tel"].ToString();
                string email = linkinfoTable["email"].ToString();
                HtmlElement passDiv = BrowserPage.GetElementByTagID("ctl00_MainContentPlaceHolder_Txtcontactname");
                passDiv.SetAttribute("value", name);
                HtmlElement mobileDiv = BrowserPage.GetElementByTagID("ctl00_MainContentPlaceHolder_TxtMobilePhone");
                mobileDiv.SetAttribute("value", mobile);
                HtmlElement telDiv = BrowserPage.GetElementByTagID("ctl00_MainContentPlaceHolder_Txttel_tel_notice_m");
                telDiv.SetAttribute("value", tel);
                HtmlElement emailDiv = BrowserPage.GetElementByTagID("ctl00_MainContentPlaceHolder_Txtemail");
                emailDiv.SetAttribute("value", email);
            }
        }

        public void SetCustomerInfo(System.Collections.Hashtable customerInfoTable)
        {
            throw new NotImplementedException();
        }

        public string GetOrderinfo()
        {
            if (BrowserPage.BrowserURL.OriginalString.StartsWith("http://hotels.ctrip.com/Domestic/ConfirmOrder.aspx"))
            {
                StringBuilder builder = new StringBuilder();
                builder.Append("<?xml version=\"1.0\" encoding=\"gb2312\"?><Order>");
                
                HtmlElement infoDiv = BrowserPage.GetElementByTagID("base_bd");
                //获取联系人信息
                Getindo(builder,infoDiv);
                builder.Append("</Order>");
                return builder.ToString();
            }
            return "";
        }

        private void Getindo(StringBuilder builder,HtmlElement infoDiv)
        {
            IList<HtmlElement> lists = Utility.GetHtmlElementChildrenByTagname(infoDiv, "DIV");
            IList<HtmlElement> liList = Utility.GetHtmlElementChildrenByTagname(lists[0], "LI");
            string ordercode = Utility.GetHtmlElementChildrenByTagname(liList[0], "STRONG")[0].InnerText;
            builder.Append("<ordercode>" + ordercode + "</ordercode>");
            HtmlElement eeable = Utility.GetHtmlElementChildrenByTagname(liList[1], "TABLE")[0];
            GetRoomInfo(builder, eeable);
        }

        private void GetRoomInfo(StringBuilder builder, HtmlElement infoDiv)
        {
            builder.Append("<roominfo>");
            IList<HtmlElement> roomLists = Utility.GetHtmlElementChildrenByTagname(infoDiv, "TR");
            IList<HtmlElement> tdList = Utility.GetHtmlElementChildrenByTagname(roomLists[1], "TD");
            builder.Append("<hotelname>" + tdList[0].InnerText + "</hotelname>");
            builder.Append("<date>" + tdList[1].InnerText + "</date>");
            builder.Append("<count>" + tdList[2].InnerText.Replace("间","") + "</count>");
            builder.Append("<roomtype>" + tdList[3].InnerText + "</roomtype>");
            builder.Append("<paytype>" + tdList[4].InnerText + "</paytype>");
            builder.Append("<price>" + tdList[5].InnerText + "</price>");
            builder.Append("</roominfo>");

            builder.Append("<linkinfo>");
            IList<HtmlElement> liList = Utility.GetHtmlElementChildrenByTagname(roomLists[2], "LI");
            builder.Append("<name>" + liList[0].InnerText.Replace("入 住 人：", "") + "</name>");
            builder.Append("<linkname>" + liList[1].InnerText.Replace("联 系 人：", "") + "</linkname>");
            builder.Append("<linktype>" + liList[2].InnerText.Replace("确认方式：：", "") + "</linktype>");
            builder.Append("<attch>" + liList[3].InnerText.Replace("补充说明：", "") + "</attch>");
            builder.Append("</linkinfo>");

            builder.Append("<payinfo>");
            IList<HtmlElement> spanList = Utility.GetHtmlElementChildrenByTagname(roomLists[3], "SPAN");
            string sText = spanList[0].InnerText;
            builder.Append("<kind>" + sText.Substring(0,3) + "</kind>");
            builder.Append("<amount>" + sText.Substring(3) + "</amount>");
            builder.Append("</payinfo>");
        }
        public string GetPayInfo()
        {
            throw new NotImplementedException();
        }

        public void Reload()
        {
            this.thisPage.Reload();
        }

        public string ChannelID
        {
            get { return chanelidID; }
        }

        #endregion
    }
}
