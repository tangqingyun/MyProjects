﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace WebbrowserControl
{
    /// <summary>
    /// 网站操作接口
    /// </summary>
    public interface IWebSite
    {
        /// <summary>
        /// 网站名称
        /// </summary>
        string WebSiteName { get; }

        /// <summary>
        /// 网站主页
        /// </summary>
        string HomePage { get; }

        /// <summary>
        /// 网站登录用户名
        /// </summary>
        string SiteUserName { get; }

        /// <summary>
        /// 网站登录密码
        /// </summary>
        string SiteUserPassword { get; }

        string ProviderID { get; }

        string ChannelID { get; }

        /// <summary>
        /// 网站浏览器页面
        /// </summary>
        BrowserTabPage BrowserPage { get; }

        IOrderInfo OrderInfo { get; }

        /// <summary>
        /// 设置页面的用户名和密码
        /// </summary>
        void SetUsernameAndPassword();

        /// <summary>
        /// 根据条件对页面进行查询
        /// </summary>
        /// <param name="conditionTable">查询条件键值对</param>
        void Query(Hashtable conditionTable);

        /// <summary>
        /// 根据传入的联系人信息自动填入页面
        /// </summary>
        /// <param name="linkinfoTable"></param>
        void SetLinkInfo(Hashtable linkinfoTable);

        /// <summary>
        /// 根据传入的顾客信息自动填入页面
        /// </summary>
        void SetCustomerInfo(Hashtable customerInfoTable);
        /// <summary>
        /// 获取网站订单的信息
        /// </summary>
        /// <returns>网站订单的XML</returns>
        string GetOrderinfo();

        /// <summary>
        /// 获取支付信息
        /// </summary>
        /// <returns>支付信息XML</returns>
        string GetPayInfo();

        /// <summary>
        /// 刷新页面
        /// </summary>
        void Reload();

    }
}
