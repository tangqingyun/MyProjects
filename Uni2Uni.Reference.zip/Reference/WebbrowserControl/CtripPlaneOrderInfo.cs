﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using uni2uni.com.Model.Order.Entity;

namespace WebbrowserControl
{
    public class CtripPlaneOrderInfo:IOrderInfo
    {
        #region IOrderInfo 成员

        private IList<uni2uni.com.Model.Order.Entity.Entity_GeneralOrder> generalOrderList = new List<uni2uni.com.Model.Order.Entity.Entity_GeneralOrder>();

        public IList<uni2uni.com.Model.Order.Entity.Entity_GeneralOrder> GeneralOrderList
        {
            get
            {
                return generalOrderList;
            }
            set
            {
                generalOrderList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_ProductOrderDetail> productOrderDetailList = new List<uni2uni.com.Model.Order.Entity.Entity_ProductOrderDetail>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_ProductOrderDetail> ProductOrderDetailList
        {
            get
            {
                return productOrderDetailList;
            }
            set
            {
                productOrderDetailList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_FOPassenger> fOPassengerList = new List<uni2uni.com.Model.Order.Entity.Entity_FOPassenger>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_FOPassenger> FOPassengerList
        {
            get
            {
                return fOPassengerList;
            }
            set
            {
                fOPassengerList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_FOFlighting> fOFlightingList = new List<uni2uni.com.Model.Order.Entity.Entity_FOFlighting>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_FOFlighting> FOFlightingList
        {
            get
            {
                return fOFlightingList;
            }
            set
            {
                fOFlightingList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_HotelOrderPrice> hotelOrderPriceList = new List<uni2uni.com.Model.Order.Entity.Entity_HotelOrderPrice>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_HotelOrderPrice> HotelOrderPriceList
        {
            get
            {
                return hotelOrderPriceList;
            }
            set
            {
                hotelOrderPriceList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_HotelOrderDetail> hotelOrderDetailList = new List<uni2uni.com.Model.Order.Entity.Entity_HotelOrderDetail>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_HotelOrderDetail> HotelOrderDetailList
        {
            get
            {
                return hotelOrderDetailList;
            }
            set
            {
                hotelOrderDetailList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_RESTOrder> restOrderList = new List<uni2uni.com.Model.Order.Entity.Entity_RESTOrder>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_RESTOrder> RESTOrderList
        {
            get
            {
                return restOrderList;
            }
            set
            {
                restOrderList = value;
            }
        }

        private uni2uni.com.Model.Order.Entity.Entity_Order order = null;
        public uni2uni.com.Model.Order.Entity.Entity_Order Order
        {
            get
            {
                return order;
            }
            set
            {
                order = value;
            }
        }

        private uni2uni.com.Model.Order.Entity.Entity_OrderLinkDetail orderLinkDetail = null;
        public uni2uni.com.Model.Order.Entity.Entity_OrderLinkDetail OrderLinkDetail
        {
            get
            {
                return orderLinkDetail;
            }
            set
            {
                orderLinkDetail = value;
            }
        }

        public void GetInfoFromXml(string infoXml, string providerID, string channelID)
        {
            System.Xml.XmlDocument infoDoc = new System.Xml.XmlDocument();
            try
            {
                infoDoc.LoadXml(infoXml);
            }
            catch
            {
                return;
            }

            //订单ID
            string strRelatedID = new uni2uni.com.BLL.Order.Components.OrderSequenceCode().GetOrderSequenceCodeBySequenceName("OR");
            //预定号码
            string strOrderID = new uni2uni.com.BLL.Order.Components.OrderSequenceCode().GetOrderSequenceCodeBySequenceName("PL");

            string arrive = "";
            //获取配送信息节点
            XmlNode linkeNode = infoDoc.SelectSingleNode("/Order/sendinfo");
            if (linkeNode != null)
            {
                setEntity_OrderLinkDetail(strRelatedID, linkeNode);
            }
            //增加航班信息
            XmlNode lineNode = infoDoc.SelectSingleNode("/Order/Freight");
            SetPlaneLine(strRelatedID, strOrderID, lineNode,ref arrive);
            //处理乘客信息
            XmlNode passNode = infoDoc.SelectSingleNode("/Order/passagers");
            SetPassager(strOrderID, passNode);
            //生成订单
            string orderAmount = infoDoc.SelectSingleNode("/Order/totalAmount").InnerText;
            Entity_GeneralOrder gorder = setEntity_GeneralOrder(strRelatedID, strOrderID, providerID, channelID, arrive, orderAmount);
            generalOrderList.Add(gorder);
            //生成预订单
            SetOrder(gorder);
        }

        private void SetOrder(Entity_GeneralOrder gorder)
        {
            order = new Entity_Order();
            order.RelatedID = gorder.RelatedID;
            order.OrderDate = DateTime.Now;
            order.CustID = gorder.CustID;
            order.CardNo = "";
            order.PayKind = gorder.PayKind;
            order.Paystate = gorder.PayState;
            order.OrderState = "1";
            order.TotalAmount = gorder.TotalMoney;
            order.ActualAmount = gorder.TotalMoney;
            order.DeliveryCosts = gorder.DeliveryCosts;
            order.IsTest = "0";
            order.Source = "1";
            order.OrderType = 0;
        }
        private Entity_GeneralOrder setEntity_GeneralOrder(string strRelatedID, string strOrderid, string providerID, string channelID,string arrive,string tAmount)
        {
            Entity_GeneralOrder entity_GeneralOrder = new Entity_GeneralOrder();

            entity_GeneralOrder.RelatedID = strRelatedID;
            entity_GeneralOrder.OrderID = strOrderid;
            entity_GeneralOrder.ChannelID = new Guid(channelID);
            entity_GeneralOrder.ProviderID = providerID;
            entity_GeneralOrder.OrderDecribe = arrive;

            entity_GeneralOrder.SourceOrderID = "";
            entity_GeneralOrder.OrderDate = DateTime.Now;
            entity_GeneralOrder.CustID = Utility.GetCurrentUserID().ToString();

            entity_GeneralOrder.OpState = "0";
            entity_GeneralOrder.OrderState = "3";

            entity_GeneralOrder.SendTime = DateTime.Now;

            entity_GeneralOrder.TicketTitle = "";
            entity_GeneralOrder.TicketState = "0";//开发票
            entity_GeneralOrder.PayState = "0";
            entity_GeneralOrder.PayKind = "1";
            entity_GeneralOrder.Remark = "";
            entity_GeneralOrder.UpdateTime = DateTime.Now;
            entity_GeneralOrder.UpdateID = "";
            entity_GeneralOrder.InsertTime = DateTime.Now;
            entity_GeneralOrder.InsertID = "";
            entity_GeneralOrder.CustID = Utility.GetCurrentUserID().ToString();

            entity_GeneralOrder.Productname = arrive;
            entity_GeneralOrder.TotalMoney = decimal.Parse(tAmount);
            entity_GeneralOrder.DeliveryCosts = 0m;
            return entity_GeneralOrder;
        }
        private void SetPassager( string orderid, XmlNode PassageNode)
        {
            XmlNodeList nodeList = PassageNode.SelectNodes("//passager");
            if (nodeList != null && nodeList.Count > 0)
            {
                for (int i = 0; i < nodeList.Count; i++)
                {
                    uni2uni.com.Model.Order.Entity.Entity_FOPassenger passager = new uni2uni.com.Model.Order.Entity.Entity_FOPassenger();
                    string name = nodeList[i].SelectSingleNode("//name").InnerText;
                    string cardtype = nodeList[i].SelectSingleNode("//cardType").InnerText.Replace(" ","").Trim();
                    string cardno = nodeList[i].SelectSingleNode("//cardno").InnerText;
                    string insurance = nodeList[i].SelectSingleNode("//insurance").InnerText.Replace("保险费", "").Replace("¥", "").Trim();

                    passager.CardCode = cardno;
                    if (cardtype.Equals("身份证"))
                    {
                        passager.CardType = "0";
                    }
                    else if (cardtype.Equals("护照"))
                    {
                        passager.CardType = "1";
                    }
                    else
                    {
                        passager.CardType = "2";
                    }
                    passager.CustName = name;
                    passager.CustType = "0";
                    passager.Gender = "0";
                    passager.Insuranceprice = 20;
                    passager.Insurance = int.Parse(insurance) / 20;
                    passager.OrderID = orderid;
                    fOPassengerList.Add(passager);
                }
            }
        }
        private void SetPlaneLine(string strRelatedID, string orderid, XmlNode freightNode,ref string arrive)
        {
            XmlNodeList nodeList = freightNode.SelectNodes("//line");
            if (nodeList != null && nodeList.Count > 0)
            {
                for (int i = 0; i < nodeList.Count; i++)
                {
                    uni2uni.com.Model.Order.Entity.Entity_FOFlighting flighting = new uni2uni.com.Model.Order.Entity.Entity_FOFlighting();
                    arrive += nodeList[i].SelectSingleNode("//company").InnerText+",";
                    string lineno = nodeList[i].SelectSingleNode("//lineno").InnerText;
                    arrive += lineno + ",";
                    string from = nodeList[i].SelectSingleNode("//from").InnerText;
                    string to = nodeList[i].SelectSingleNode("//to").InnerText;
                    string planetype = nodeList[i].SelectSingleNode("//planetype").InnerText;
                    string cabin = nodeList[i].SelectSingleNode("//cabin").InnerText;
                    string price = nodeList[i].SelectSingleNode("//price").InnerText;
                    flighting.Airline = lineno.Substring(0, 2);
                    flighting.Schedule = lineno.Substring(2);
                    
                    string[] froms = from.Split(char.Parse(" "));
                    arrive += froms[0] + " " + froms[1] + " " + froms[2];

                    string aircodes = PlanCodeChange.GetAirportCode(froms[2]);
                    if (aircodes.Length > 0)
                    {
                        string[] codes = aircodes.Split(char.Parse(","));
                        flighting.BeginAirport = codes[1];
                        flighting.BeginCity = codes[0];
                    }
                    else
                    {
                        flighting.BeginAirport = froms[2];
                        flighting.BeginCity = froms[2];
                    }
                    flighting.Cabin = cabin.Substring(0, 1);
                    flighting.Flydate = froms[0].Replace("年","-").Replace("月","-").Replace("日","");

                    flighting.UpTime = froms[1];
                    if(nodeList.Count>1)
                    {
                        flighting.IsReturn = "1";
                    }
                    
                    flighting.OrderID = orderid;

                    string[] tos = to.Split(char.Parse(" "));
                    arrive += "到" + tos[0] + " " + tos[1] + " " + tos[2] + ";";
                    string toaircodes = PlanCodeChange.GetAirportCode(tos[2]);
                    if (toaircodes.Length > 0)
                    {
                        string[] tocodes = toaircodes.Split(char.Parse(","));
                        flighting.EndAirport = tocodes[1];
                        flighting.EndCity = tocodes[0];
                    }
                    else
                    {
                        flighting.EndAirport = tos[2];
                        flighting.EndAirport = tos[2];
                    }
                    flighting.DownTime = tos[1];
                    flighting.ReturnDate = tos[0].Replace("年", "-").Replace("月", "-").Replace("日", "");

                    flighting.AirportTax = 0m;
                    flighting.OilFee = 0m;
                    flighting.Discount = decimal.Parse(price.Replace("/成人", "").Replace("（含税费）", "").Replace("¥", "").Trim().Replace("/r/n",""));
                    
                    fOFlightingList.Add(flighting);
                }
            }
        }
        /// <summary>
        /// 联系信息
        /// </summary>
        /// <returns></returns>
        private void setEntity_OrderLinkDetail(string strRelatedID, XmlNode linkeNode)
        {
            orderLinkDetail = new uni2uni.com.Model.Order.Entity.Entity_OrderLinkDetail();
            orderLinkDetail.RelatedID = strRelatedID;
            orderLinkDetail.MemberID = Utility.GetCurrentUserID();
            orderLinkDetail.CustName = linkeNode.SelectSingleNode("//linkname").InnerText;

            orderLinkDetail.Mobile = linkeNode.SelectSingleNode("//mobile").InnerText;
            orderLinkDetail.Telephone = linkeNode.SelectSingleNode("//tel").InnerText;
            orderLinkDetail.Fax = "";
            orderLinkDetail.Email = linkeNode.SelectSingleNode("//email").InnerText;
            orderLinkDetail.Address = linkeNode.SelectSingleNode("//address").InnerText;
            orderLinkDetail.Zip = "";

            orderLinkDetail.Attachment = "配送方式：" + linkeNode.SelectSingleNode("//sendtype").InnerText + "，支付方式：" + linkeNode.SelectSingleNode("//paytype").InnerText;
        }

        #endregion
    }

    public class PlanCodeChange
    {
        private static IList<string[]> airportTable = new List<string[]>();

        public PlanCodeChange()
        {
            if (airportTable == null)
            {
                airportTable = new List<string[]>();
                intTable();
            }
        }

        /// <summary>
        /// 初始化机场信息
        /// </summary>
        private  static void intTable()
        {
            string[] array1 = new string[] { "TSN", "滨海国际机场" }; airportTable.Add(array1);
            string[] array2 = new string[] { "CAN", "广州白云国际机场" }; airportTable.Add(array2);
            string[] array3 = new string[] { "SZX", "深圳黄田机场" }; airportTable.Add(array3);
            string[] array4 = new string[] { "BHY", "北海福城机场" }; airportTable.Add(array4);
            string[] array5 = new string[] { "CSX", "长沙黄花机场" }; airportTable.Add(array5);
            string[] array6 = new string[] { "CKG", "重庆江北机场" }; airportTable.Add(array6);
            string[] array7 = new string[] { "CTU", "成都双流国际机场" }; airportTable.Add(array7);
            string[] array8 = new string[] { "DLC", "大连国际机场" }; airportTable.Add(array8);
            string[] array9 = new string[] { "FOC", "长乐国际机场" }; airportTable.Add(array9);
            string[] array10 = new string[] { "KWL", "桂林两江国际机场" }; airportTable.Add(array10);
            string[] array11 = new string[] { "HGH", "杭州萧山机场" }; airportTable.Add(array11);
            string[] array12 = new string[] { "TNA", "济南遥墙国际机场" }; airportTable.Add(array12);
            string[] array13 = new string[] { "LXA", "拉萨贡嘎机场" }; airportTable.Add(array13);
            string[] array14 = new string[] { "NKG", "南京禄口国际机场" }; airportTable.Add(array14);
            string[] array15 = new string[] { "NGB", "宁波栎社机场" }; airportTable.Add(array15);
            string[] array16 = new string[] { "SHE", "沈阳桃仙国际机场" }; airportTable.Add(array16);
            string[] array17 = new string[] { "URC", "乌鲁木齐地窝铺机场" }; airportTable.Add(array17);
            string[] array18 = new string[] { "XMN", "厦门高崎国际机场" }; airportTable.Add(array18);
            string[] array19 = new string[] { "BAV", "包头机场" }; airportTable.Add(array19);
            string[] array20 = new string[] { "DNH", "敦煌机场" }; airportTable.Add(array20);
            string[] array21 = new string[] { "CZX", "常州奔牛机场" }; airportTable.Add(array21);
            string[] array22 = new string[] { "HAK", "海口美兰机场" }; airportTable.Add(array22);
            string[] array23 = new string[] { "HRB", "哈尔滨太平国际机场" }; airportTable.Add(array23);
            string[] array24 = new string[] { "TXN", "黄山屯溪机场" }; airportTable.Add(array24);
            string[] array25 = new string[] { "KWE", "贵阳龙洞堡机场" }; airportTable.Add(array25);
            string[] array26 = new string[] { "LHW", "兰州中川机场" }; airportTable.Add(array26);
            string[] array27 = new string[] { "KMG", "昆明巫家坝机场" }; airportTable.Add(array27);
            string[] array28 = new string[] { "YNT", "烟台莱山机场" }; airportTable.Add(array28);
            string[] array29 = new string[] { "KHN", "南昌昌北机场" }; airportTable.Add(array29);
            string[] array30 = new string[] { "TAO", "青岛流亭国际机场" }; airportTable.Add(array30);
            string[] array31 = new string[] { "TYN", "太原武宿机场" }; airportTable.Add(array31);
            string[] array32 = new string[] { "XNN", "西宁曹家堡机场" }; airportTable.Add(array32);
            string[] array33 = new string[] { "INC", "银川河东机场" }; airportTable.Add(array33);
            string[] array34 = new string[] { "UYN", "榆林西沙机场" }; airportTable.Add(array34);
            string[] array35 = new string[] { "XIY", "咸阳国际机场" }; airportTable.Add(array35);
            string[] array36 = new string[] { "CGO", "新郑机场" }; airportTable.Add(array36);
            string[] array37 = new string[] { "JMU", "东郊机场" }; airportTable.Add(array37);
            string[] array38 = new string[] { "JNZ", "锦州小岭子机场" }; airportTable.Add(array38);
            string[] array39 = new string[] { "SJW", "正定机场" }; airportTable.Add(array39);
            string[] array40 = new string[] { "LYA", "洛阳北郊机场" }; airportTable.Add(array40);
            string[] array41 = new string[] { "NNY", "南阳姜营机场" }; airportTable.Add(array41);
            string[] array42 = new string[] { "CIH", "长治王村机场" }; airportTable.Add(array42);
            string[] array43 = new string[] { "WEH", "威海大水泊机场" }; airportTable.Add(array43);
            string[] array44 = new string[] { "WEF", "潍坊文登机场" }; airportTable.Add(array44);
            string[] array45 = new string[] { "LYI", "临沂机场" }; airportTable.Add(array45);
            string[] array46 = new string[] { "XFN", "襄樊刘集机场" }; airportTable.Add(array46);
            string[] array47 = new string[] { "CGD", "桃花机场" }; airportTable.Add(array47);
            string[] array48 = new string[] { "JIU", "九江马回岭机场" }; airportTable.Add(array48);
            string[] array49 = new string[] { "JDZ", "景德镇罗家机场" }; airportTable.Add(array49);
            string[] array50 = new string[] { "KOW", "赣州黄金机场" }; airportTable.Add(array50);
            string[] array51 = new string[] { "HSN", "舟山普陀山机场" }; airportTable.Add(array51);
            string[] array52 = new string[] { "WNZ", "永强机场" }; airportTable.Add(array52);
            string[] array53 = new string[] { "WUX", "无锡机场" }; airportTable.Add(array53);
            string[] array54 = new string[] { "XUZ", "徐州观音机场" }; airportTable.Add(array54);
            string[] array55 = new string[] { "LYG", "白塔埠机场" }; airportTable.Add(array55);
            string[] array56 = new string[] { "SWA", "外砂机场" }; airportTable.Add(array56);
            string[] array57 = new string[] { "WUS", "武夷山机场" }; airportTable.Add(array57);
            string[] array58 = new string[] { "SYX", "三亚凤凰国际机场" }; airportTable.Add(array58);
            string[] array59 = new string[] { "MIG", "南郊机场" }; airportTable.Add(array59);
            string[] array60 = new string[] { "YBP", "菜坝机场" }; airportTable.Add(array60);
            string[] array61 = new string[] { "LZO", "泸州萱田机场" }; airportTable.Add(array61);
            string[] array62 = new string[] { "DLU", "大理机场" }; airportTable.Add(array62);
            string[] array63 = new string[] { "KRL", "库尔勒机场" }; airportTable.Add(array63);
            string[] array64 = new string[] { "HET", "白塔机场" }; airportTable.Add(array64);
            string[] array65 = new string[] { "CIF", "土城子机场" }; airportTable.Add(array65);
            string[] array66 = new string[] { "CGQ", "大房身机场" }; airportTable.Add(array66);
            string[] array67 = new string[] { "ZUH", "三灶机场" }; airportTable.Add(array67);
            string[] array68 = new string[] { "WUH", "武汉天河国际机场" }; airportTable.Add(array68);
            string[] array69 = new string[] { "NNG", "南宁吴圩国际机场" }; airportTable.Add(array69);
            string[] array70 = new string[] { "YIW", "义乌机场" }; airportTable.Add(array70);
            string[] array71 = new string[] { "TGO", "通辽机场" }; airportTable.Add(array71);
            string[] array72 = new string[] { "NAO", "南充都尉坝机场" }; airportTable.Add(array72);
            string[] array73 = new string[] { "YNZ", "盐城机场" }; airportTable.Add(array73);
            string[] array74 = new string[] { "JZH", "九寨沟黄龙机场" }; airportTable.Add(array74);
            string[] array75 = new string[] { "ZHA", "湛江机场" }; airportTable.Add(array75);
            string[] array76 = new string[] { "DYG", "张家界荷花机场" }; airportTable.Add(array76);
            string[] array77 = new string[] { "ZYI", "遵义机场" }; airportTable.Add(array77);
            string[] array78 = new string[] { "ENY", "二十里铺机场" }; airportTable.Add(array78);
            string[] array79 = new string[] { "YNJ", "延吉朝阳川机场" }; airportTable.Add(array79);
            string[] array80 = new string[] { "YIN", "伊宁机场" }; airportTable.Add(array80);
            string[] array81 = new string[] { "HEK", "黑河机场" }; airportTable.Add(array81);
            string[] array82 = new string[] { "JIL", "吉林二台子机场" }; airportTable.Add(array82);
            string[] array83 = new string[] { "CHG", "朝阳机场" }; airportTable.Add(array83);
            string[] array84 = new string[] { "DDG", "丹东浪头机场" }; airportTable.Add(array84);
            string[] array85 = new string[] { "IOB", "鞍山机场" }; airportTable.Add(array85);
            string[] array86 = new string[] { "XEN", "兴城机场" }; airportTable.Add(array86);
            string[] array87 = new string[] { "SHP", "秦皇岛机场" }; airportTable.Add(array87);
            string[] array88 = new string[] { "SHF", "山海关机场" }; airportTable.Add(array88);
            string[] array89 = new string[] { "AYN", "安阳机场" }; airportTable.Add(array89);
            string[] array90 = new string[] { "DAT", "怀仁机场" }; airportTable.Add(array90);
            string[] array91 = new string[] { "SUB", "朱安达机场" }; airportTable.Add(array91);
            string[] array92 = new string[] { "TNB", "济宁机场" }; airportTable.Add(array92);
            string[] array93 = new string[] { "SHS", "荆州沙市机场" }; airportTable.Add(array93);
            string[] array94 = new string[] { "ENH", "恩施许家坪机场" }; airportTable.Add(array94);
            string[] array95 = new string[] { "HNY", "衡阳机场" }; airportTable.Add(array95);
            string[] array96 = new string[] { "HFE", "骆岗机场" }; airportTable.Add(array96);
            string[] array97 = new string[] { "AGG", "安庆大龙山机场" }; airportTable.Add(array97);
            string[] array98 = new string[] { "FUG", "阜阳西关机场" }; airportTable.Add(array98);
            string[] array99 = new string[] { "JUZ", "衢州机场" }; airportTable.Add(array99);
            string[] array100 = new string[] { "NTG", "南通兴东机场" }; airportTable.Add(array100);
            string[] array101 = new string[] { "MXZ", "梅县机场" }; airportTable.Add(array101);
            string[] array102 = new string[] { "SHG", "韶关机场" }; airportTable.Add(array102);
            string[] array103 = new string[] { "XIN", "兴宁机场" }; airportTable.Add(array103);
            string[] array104 = new string[] { "WXN", "万县机场" }; airportTable.Add(array104);
            string[] array105 = new string[] { "DAX", "河市霸机场" }; airportTable.Add(array105);
            string[] array106 = new string[] { "XTC", "青山机场" }; airportTable.Add(array106);
            string[] array107 = new string[] { "BPX", "梁平机场" }; airportTable.Add(array107);
            string[] array108 = new string[] { "GHN", "广汉机场" }; airportTable.Add(array108);
            string[] array109 = new string[] { "TEN", "大兴机场" }; airportTable.Add(array109);
            string[] array110 = new string[] { "AKA", "五里铺机场" }; airportTable.Add(array110);
            string[] array111 = new string[] { "HTN", "和田机场" }; airportTable.Add(array111);
            string[] array112 = new string[] { "KRY", "克拉玛依机场" }; airportTable.Add(array112);
            string[] array113 = new string[] { "TCG", "塔城机场" }; airportTable.Add(array113);
            string[] array114 = new string[] { "KHG", "喀什机场" }; airportTable.Add(array114);
            string[] array115 = new string[] { "AAT", "阿勒泰机场" }; airportTable.Add(array115);
            string[] array116 = new string[] { "AKU", "温宿机场" }; airportTable.Add(array116);
            string[] array117 = new string[] { "KCA", "库车机场" }; airportTable.Add(array117);
            string[] array118 = new string[] { "HMI", "哈密机场" }; airportTable.Add(array118);
            string[] array119 = new string[] { "HLH", "乌兰浩特机场" }; airportTable.Add(array119);
            string[] array120 = new string[] { "YUZ", "长州岛机场" }; airportTable.Add(array120);
            string[] array121 = new string[] { "BSD", "保山机场" }; airportTable.Add(array121);
            string[] array122 = new string[] { "BFU", "蚌埠机场" }; airportTable.Add(array122);
            string[] array123 = new string[] { "LJG", "丽江机场" }; airportTable.Add(array123);
            string[] array124 = new string[] { "JJN", "泉州晋江机场" }; airportTable.Add(array24);
            string[] array125 = new string[] { "MDG", "牡丹江机场" }; airportTable.Add(array125);
            string[] array126 = new string[] { "NDG", "齐齐哈尔机场" }; airportTable.Add(array126);
            string[] array127 = new string[] { "YCU", "运城机场" }; airportTable.Add(array127);
            string[] array128 = new string[] { "HLD", "东山机场" }; airportTable.Add(array128);
            string[] array129 = new string[] { "NZH", "满州里机场" }; airportTable.Add(array129);
            string[] array130 = new string[] { "JGN", "嘉峪关机场" }; airportTable.Add(array130);
            string[] array131 = new string[] { "WUA", "乌海机场" }; airportTable.Add(array131);
            string[] array132 = new string[] { "DOY", "东营机场" }; airportTable.Add(array132);
            string[] array133 = new string[] { "YIH", "宜昌三峡机场" }; airportTable.Add(array133);
            string[] array134 = new string[] { "HYN", "黄岩机场" }; airportTable.Add(array134);
            string[] array135 = new string[] { "AQG", "安庆机场" }; airportTable.Add(array135);
            string[] array136 = new string[] { "FUO", "佛山机场" }; airportTable.Add(array136);
            string[] array137 = new string[] { "LZH", "柳州机场" }; airportTable.Add(array137);
            string[] array138 = new string[] { "SZV", "苏州机场" }; airportTable.Add(array138);
            string[] array139 = new string[] { "NBG", "宁波机场" }; airportTable.Add(array138);
            string[] array140 = new string[] { "LLF", "永州机场" }; airportTable.Add(array139);
            string[] array141 = new string[] { "KNC", "吉安机场" }; airportTable.Add(array141);
            string[] array142 = new string[] { "AOG", "鞍山机场" }; airportTable.Add(array142);
            string[] array143 = new string[] { "LNJ", "临沧机场" }; airportTable.Add(array143);
            string[] array145 = new string[] { "SYM", "思茅机场" }; airportTable.Add(array145);
            string[] array146 = new string[] { "ZAT", "昭通机场" }; airportTable.Add(array146);
            string[] array147 = new string[] { "AVA", "安顺机场" }; airportTable.Add(array147);
            string[] array148 = new string[] { "XIC", "西昌机场" }; airportTable.Add(array148);
            string[] array149 = new string[] { "GYS", "广元机场" }; airportTable.Add(array149);
            string[] array150 = new string[] { "GOQ", "格尔木机场" }; airportTable.Add(array150);
            string[] array151 = new string[] { "JNG", "济宁机场" }; airportTable.Add(array151);
            string[] array152 = new string[] { "WUZ", "梧州机场" }; airportTable.Add(array152);
            string[] array153 = new string[] { "PZI", "攀枝花机场" }; airportTable.Add(array153);
            string[] array154 = new string[] { "CHW", "酒泉机场" }; airportTable.Add(array154);
            string[] array155 = new string[] { "HZG", "汉中机场" }; airportTable.Add(array155);
            string[] array156 = new string[] { "IQZ", "庆阳机场" }; airportTable.Add(array156);
            string[] array157 = new string[] { "XIL", "锡林浩特机场" }; airportTable.Add(array157);
            string[] array158 = new string[] { "JHG", "西双版纳机场" }; airportTable.Add(array158);
            string[] array159 = new string[] { "HKG", "香港机场" }; airportTable.Add(array159);
            string[] array160 = new string[] { "MFM", "澳门机场" }; airportTable.Add(array160);
            string[] array161 = new string[] { "BUE", "布宜诺斯艾利斯机场" }; airportTable.Add(array161);
        }

        public static string GetAirportCode( string airportName)
        {
            if (airportTable == null || airportTable.Count==0)
            {
                intTable();
            }
            if (airportName.StartsWith("北京"))
            {
                if (airportName.Equals("北京首都"))
                {
                    return "PEK,PEK";
                }
                else
                {
                    return "PEK,NAY";
                }
            }
            else if (airportName.StartsWith("上海"))
            {
                if (airportName.Equals("上海虹桥"))
                {
                    return "SHA,SHA";
                }
                else
                {
                    return "SHA,PVG";
                }
            }
            else
            {
                foreach (string[] port in airportTable)
                {
                    string portName = port[1].Replace("机场", "").Replace("国际", "");
                    if (portName.IndexOf(airportName) >= 0 || airportName.IndexOf(portName)>=0)
                    {
                        return port[0] + "," + port[0];
                    }
                }
            }
            return "";
        }
    }
}
