﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using uni2uni.com.Model.Order.Entity;

namespace WebbrowserControl
{
    public class CtripHotelOrderInfo:IOrderInfo
    {
        #region IOrderInfo 成员

        private IList<uni2uni.com.Model.Order.Entity.Entity_GeneralOrder> generalOrderList = new List<uni2uni.com.Model.Order.Entity.Entity_GeneralOrder>();

        public IList<uni2uni.com.Model.Order.Entity.Entity_GeneralOrder> GeneralOrderList
        {
            get
            {
                return generalOrderList;
            }
            set
            {
                generalOrderList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_ProductOrderDetail> productOrderDetailList = new List<uni2uni.com.Model.Order.Entity.Entity_ProductOrderDetail>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_ProductOrderDetail> ProductOrderDetailList
        {
            get
            {
                return productOrderDetailList;
            }
            set
            {
                productOrderDetailList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_FOPassenger> fOPassengerList = new List<uni2uni.com.Model.Order.Entity.Entity_FOPassenger>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_FOPassenger> FOPassengerList
        {
            get
            {
                return fOPassengerList;
            }
            set
            {
                fOPassengerList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_FOFlighting> fOFlightingList = new List<uni2uni.com.Model.Order.Entity.Entity_FOFlighting>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_FOFlighting> FOFlightingList
        {
            get
            {
                return fOFlightingList;
            }
            set
            {
                fOFlightingList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_HotelOrderPrice> hotelOrderPriceList = new List<uni2uni.com.Model.Order.Entity.Entity_HotelOrderPrice>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_HotelOrderPrice> HotelOrderPriceList
        {
            get
            {
                return hotelOrderPriceList;
            }
            set
            {
                hotelOrderPriceList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_HotelOrderDetail> hotelOrderDetailList = new List<uni2uni.com.Model.Order.Entity.Entity_HotelOrderDetail>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_HotelOrderDetail> HotelOrderDetailList
        {
            get
            {
                return hotelOrderDetailList;
            }
            set
            {
                hotelOrderDetailList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_RESTOrder> restOrderList = new List<uni2uni.com.Model.Order.Entity.Entity_RESTOrder>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_RESTOrder> RESTOrderList
        {
            get
            {
                return restOrderList;
            }
            set
            {
                restOrderList = value;
            }
        }

        private uni2uni.com.Model.Order.Entity.Entity_Order order = null;
        public uni2uni.com.Model.Order.Entity.Entity_Order Order
        {
            get
            {
                return order;
            }
            set
            {
                order = value;
            }
        }

        private uni2uni.com.Model.Order.Entity.Entity_OrderLinkDetail orderLinkDetail = null;
        public uni2uni.com.Model.Order.Entity.Entity_OrderLinkDetail OrderLinkDetail
        {
            get
            {
                return orderLinkDetail;
            }
            set
            {
                orderLinkDetail = value;
            }
        }

        public void GetInfoFromXml(string infoXml, string providerID, string channelID)
        {
            System.Xml.XmlDocument infoDoc = new System.Xml.XmlDocument();
            try
            {
                infoDoc.LoadXml(infoXml);
            }
            catch
            {
                return;
            }
            //订单ID
            string strRelatedID = new uni2uni.com.BLL.Order.Components.OrderSequenceCode().GetOrderSequenceCodeBySequenceName("OR");//预定号码

            string strOrderID = new uni2uni.com.BLL.Order.Components.OrderSequenceCode().GetOrderSequenceCodeBySequenceName("HO");
            //获取联系人节点
            XmlNode linkeNode = infoDoc.SelectSingleNode("/Order/linkinfo");
            if (linkeNode != null)
            {
                setEntity_OrderLinkDetail(strRelatedID, linkeNode);
            }
            //产生酒店订单明细
            setEntity_HotelOrderPriceList(strOrderID, providerID, infoDoc);

            //产生订单头
            string sourceCode = infoDoc.SelectSingleNode("/Order/ordercode").InnerText;
            this.GeneralOrderList.Add(setEntity_GeneralOrder(strRelatedID, strOrderID, providerID, channelID, sourceCode));
            
            //产生订单明细
            SetOrder(GeneralOrderList[0]);
        }

        private void SetOrder(Entity_GeneralOrder gorder)
        {
            order = new Entity_Order();
            order.RelatedID = gorder.RelatedID;
            order.OrderDate = DateTime.Now;
            order.CustID = gorder.CustID;
            order.CardNo = "";
            order.PayKind = gorder.PayKind;
            order.Paystate = gorder.PayState;
            order.OrderState = "1";
            order.TotalAmount = gorder.TotalMoney;
            order.ActualAmount = gorder.TotalMoney;
            order.DeliveryCosts = gorder.DeliveryCosts;
            order.IsTest = "0";
            order.Source = "1";
            order.OrderType = 0;
        }

        private Entity_GeneralOrder setEntity_GeneralOrder(string strRelatedID, string strOrderid, string providerID, string channelID, string sourceCode)
        {
            Entity_GeneralOrder entity_GeneralOrder = new Entity_GeneralOrder();

            entity_GeneralOrder.RelatedID = strRelatedID;
            entity_GeneralOrder.OrderID = strOrderid;
            entity_GeneralOrder.ChannelID = new Guid(channelID);
            entity_GeneralOrder.ProviderID = providerID;
            entity_GeneralOrder.OrderDecribe = HotelOrderDetailList[0].Attachment;

            entity_GeneralOrder.SourceOrderID = "";
            entity_GeneralOrder.OrderDate = DateTime.Now;
            entity_GeneralOrder.CustID = Utility.GetCurrentUserID().ToString();

            entity_GeneralOrder.OpState = "0";
            entity_GeneralOrder.OrderState = "3";

            entity_GeneralOrder.SendTime = DateTime.Now;


            // sumSendFee += entity_GeneralOrder.DeliveryCosts;//累加总配送费

            entity_GeneralOrder.TicketTitle = sourceCode;
            entity_GeneralOrder.TicketState = "0";//开发票
            entity_GeneralOrder.PayState = "0";
            entity_GeneralOrder.PayKind = "0";
            entity_GeneralOrder.Remark = "";
            entity_GeneralOrder.UpdateTime = DateTime.Now;
            entity_GeneralOrder.UpdateID = "";
            entity_GeneralOrder.InsertTime = DateTime.Now;
            entity_GeneralOrder.InsertID = "";
            entity_GeneralOrder.CustID = Utility.GetCurrentUserID().ToString();

            entity_GeneralOrder.Productname = HotelOrderDetailList[0].HotelName+"("+HotelOrderDetailList[0].RoomType+")";
            entity_GeneralOrder.TotalMoney =new decimal(HotelOrderDetailList[0].SumPrice);
            entity_GeneralOrder.DeliveryCosts = 0m;
            return entity_GeneralOrder;
        }
        /// <summary>
        /// 联系信息
        /// </summary>
        /// <returns></returns>
        private void setEntity_OrderLinkDetail(string strRelatedID, XmlNode linkeNode)
        {
            orderLinkDetail = new uni2uni.com.Model.Order.Entity.Entity_OrderLinkDetail();
            orderLinkDetail.RelatedID = strRelatedID;
            orderLinkDetail.MemberID = Utility.GetCurrentUserID();
            orderLinkDetail.CustName = linkeNode.SelectSingleNode("//linkname").InnerText;
            string sLinkType = linkeNode.SelectSingleNode("//linktype").InnerText;
            orderLinkDetail.Mobile = "";
            orderLinkDetail.Telephone = "";
            orderLinkDetail.Fax = "";
            orderLinkDetail.Email = "";
            orderLinkDetail.Address = "";
            orderLinkDetail.Zip = "";
            if (sLinkType.StartsWith("电话"))
            {
                orderLinkDetail.ConfirmType = "1";
                string[] Linktypes = sLinkType.Split(char.Parse("（"));
                orderLinkDetail.Mobile = Linktypes[1].Replace("）", "");
                orderLinkDetail.Telephone = orderLinkDetail.Mobile;
            }
            else if (sLinkType.StartsWith("E-mail"))
            {
                orderLinkDetail.ConfirmType = "2";
                string[] Linktypes = sLinkType.Split(char.Parse("("));
                orderLinkDetail.Email = Linktypes[1].Replace(")", "");
            }
            else if (sLinkType.StartsWith("传真"))
            {
                orderLinkDetail.ConfirmType = "1";
                string[] Linktypes = sLinkType.Split(char.Parse("（"));
                orderLinkDetail.Fax = Linktypes[1].Replace("）", "");
            }
            else if (sLinkType.StartsWith("短消息"))
            {
                orderLinkDetail.ConfirmType = "0";
                string[] Linktypes = sLinkType.Split(char.Parse("（"));
                orderLinkDetail.Mobile = Linktypes[1].Replace("）", "");
                orderLinkDetail.Telephone = orderLinkDetail.Mobile;
            }
            orderLinkDetail.Attachment = linkeNode.SelectSingleNode("//attch").InnerText;
        }

        /// <summary>
        /// HotelOrderPriceList HotelOrderDetailList 赋值
        /// </summary>
        /// <param name="shoppingDetail"></param>
        /// <param name="strOrderID"></param>
        private bool setEntity_HotelOrderPriceList(string strOrderID,string providerID,XmlDocument doc)
        {
            

            Entity_HotelOrderDetail entity_HotelOrderDetail = new Entity_HotelOrderDetail();

            XmlNode roomnode = doc.SelectSingleNode("/Order/roominfo");

            string sdate = roomnode.SelectSingleNode("//date").InnerText;
            string[] dates = sdate.Split(char.Parse("至"));
            DateTime beginDate = DateTime.Parse(dates[0].Trim());
            DateTime endDate = DateTime.Parse(dates[1].Trim());
            string Price = roomnode.SelectSingleNode("//date").InnerText.Replace("RMB", "").Replace("/间","").Trim();
            int i = 0;
            while (beginDate.CompareTo(endDate)<0)
            {
                Entity_HotelOrderPrice entity_HotelOrderPrice = new Entity_HotelOrderPrice();
                entity_HotelOrderPrice.OrderID = strOrderID;
                entity_HotelOrderPrice.Nowday = beginDate;
                entity_HotelOrderPrice.Price = double.Parse(Price);

                beginDate.AddDays(1);
                i++;
                HotelOrderPriceList.Add(entity_HotelOrderPrice);
            }

            entity_HotelOrderDetail.HotelID = new Guid();
            entity_HotelOrderDetail.OrderID = strOrderID;

            entity_HotelOrderDetail.HotelName = roomnode.SelectSingleNode("//hotelname").InnerText;
            entity_HotelOrderDetail.RoomType = roomnode.SelectSingleNode("//roomtype").InnerText;
            entity_HotelOrderDetail.ProviderID = new Guid(providerID);
            entity_HotelOrderDetail.SingleRoomPrice = double.Parse(Price)*i;
            entity_HotelOrderDetail.RoomNumber = int.Parse(roomnode.SelectSingleNode("//count").InnerText.Replace("间","").Trim()); 
            entity_HotelOrderDetail.AddBedPrice = 0;
            entity_HotelOrderDetail.AddBedNumber = 0;

            XmlNode paynode = doc.SelectSingleNode("/Order/payinfo");
            entity_HotelOrderDetail.SumPrice = double.Parse(paynode.SelectSingleNode("//amount").InnerText.Replace(",", "").Trim());

            entity_HotelOrderDetail.BeginDate = beginDate;
            entity_HotelOrderDetail.EndDate = endDate;
            //entity_HotelOrderDetail.CustID = "";
            XmlNode linkNode = doc.SelectSingleNode("/Order/linkinfo");

            entity_HotelOrderDetail.Attachment = linkNode.SelectSingleNode("//attch").InnerText;
            entity_HotelOrderDetail.ArriveTime = "14:00";
            entity_HotelOrderDetail.CheckInPersons = linkNode.SelectSingleNode("//name").InnerText;
            entity_HotelOrderDetail.CreditCardHolder = "";
            entity_HotelOrderDetail.DocumentType = "";
            entity_HotelOrderDetail.DocumentNo = "";
            entity_HotelOrderDetail.CreditCardNo = "";
            entity_HotelOrderDetail.CreditCardType = "";
            entity_HotelOrderDetail.CreditCardPeriod = "";
            entity_HotelOrderDetail.CrediCardtValidecode = "";
            entity_HotelOrderDetail.PayInfo = "";
            entity_HotelOrderDetail.ConfirmWay = "";
            entity_HotelOrderDetail.OtherSpecialRequirements = linkNode.SelectSingleNode("//attch").InnerText;

            HotelOrderDetailList.Add(entity_HotelOrderDetail);

            return true;
        }
        #endregion
    }
}
