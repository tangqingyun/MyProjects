﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace WebbrowserControl
{
    public class CtripPlaneSite:IWebSite
    {

        private string websiteName = "携程";

        private string chanelidID;

        private string providerID;

        private string homePage = "http://www.ctrip.com";

        private BrowserTabPage thisPage;

        private IOrderInfo orderInfo;

        private string siteUserName;

        private string siteUserPassword;

        public CtripPlaneSite(string channelid,string webname, string pid, string home, string username, string password)
        {
            chanelidID = channelid;
            websiteName = webname;
            providerID = pid;
            homePage = home;
            siteUserName = username;
            siteUserPassword = password;
            thisPage = new BrowserTabPage();
            orderInfo = new CtripPlaneOrderInfo();
        }

        #region IWebSite 成员

        public string ProviderID
        {
            get { return providerID; }
        }
        public string WebSiteName
        {
            get { return websiteName; }
        }

        public string HomePage
        {
            get { return homePage; }
        }

        public string SiteUserName
        {
            get { return siteUserName; }
        }

        public string SiteUserPassword
        {
            get { return siteUserPassword; }
        }

        public IOrderInfo OrderInfo
        {
            get { return orderInfo; }
        }

        public BrowserTabPage BrowserPage
        {
            get
            {
                return thisPage;
            }
        }

        public void SetUsernameAndPassword()
        {
            if (BrowserPage.BrowserURL.OriginalString.StartsWith("http://www.ctrip.com/Member/Login.asp"))
            {
                BrowserPage.SetElementText("signin_uid", SiteUserName);
                BrowserPage.SetElementText("signin_pwd", SiteUserPassword);
                BrowserPage.RaiseElementEvent("loginBtn", "click");
            }
            else if (BrowserPage.BrowserURL.OriginalString.StartsWith("http://www.ctrip.com/Member/PostLogin.asp"))
            {
                BrowserPage.SetElementText("signin_uid", SiteUserName);
                BrowserPage.SetElementText("signin_pwd", SiteUserPassword);
                BrowserPage.RaiseElementEvent("loginBtn", "click");
            }
        }

        public void Query(System.Collections.Hashtable conditionTable)
        {
            throw new NotImplementedException();
        }

        public void SetLinkInfo(System.Collections.Hashtable linkinfoTable)
        {
            if (BrowserPage.BrowserURL.OriginalString.StartsWith("http://flights.ctrip.com/Domestic/InputPassengers.aspx"))
            {
                string name = linkinfoTable["name"].ToString();
                string address = linkinfoTable["address"].ToString();
                string mobile = linkinfoTable["mobile"].ToString();
                string zip = linkinfoTable["zip"].ToString();
                string tel = linkinfoTable["tel"].ToString();
                string email = linkinfoTable["email"].ToString();
                HtmlElement passDiv = BrowserPage.GetElementByTagID("ctl00_MainContentPlaceHolder_ContacterInfoControl1_txtContactName");
                passDiv.SetAttribute("value", name);
                HtmlElement mobileDiv = BrowserPage.GetElementByTagID("ctl00_MainContentPlaceHolder_ContacterInfoControl1_txtContactMobile");
                mobileDiv.SetAttribute("value", mobile);
                HtmlElement telDiv = BrowserPage.GetElementByTagID("ctl00_MainContentPlaceHolder_ContacterInfoControl1_txtContactTelephone_notice_m");
                telDiv.SetAttribute("value", tel);
                HtmlElement emailDiv = BrowserPage.GetElementByTagID("ctl00_MainContentPlaceHolder_ContacterInfoControl1_txtEmail");
                emailDiv.SetAttribute("value", email);
            }
        }

        public void SetCustomerInfo(System.Collections.Hashtable customerInfoTable)
        {
            if (BrowserPage.BrowserURL.OriginalString.StartsWith("http://flights.ctrip.com/Domestic/InputPassengers.aspx"))
            {
                string name = customerInfoTable["name"].ToString();
                string cardtype = customerInfoTable["cardtype"].ToString();
                string cardcode = customerInfoTable["cardcode"].ToString();
                string custtype = customerInfoTable["custtype"].ToString();
                string Birthday = customerInfoTable["Birthday"].ToString();
                string Gender = customerInfoTable["Gender"].ToString();
                HtmlElement passDiv = BrowserPage.GetElementByTagID("boarderList");
                IList<HtmlElement> custList = Utility.GetHtmlElementChildrenIncludeID(passDiv, "DIV", "customer");
                HtmlElement lastPassage = custList[custList.Count - 1];
                IList<HtmlElement> typeList = Utility.GetHtmlElementChildrenByTagname(lastPassage, "SELECT");
                if (custtype.Trim().Equals("0"))
                {
                    typeList[0].SetAttribute("value", "adult");
                }
                else if (custtype.Trim().Equals("1"))
                {
                    typeList[0].SetAttribute("value", "child");
                }
                else
                {
                    typeList[0].SetAttribute("value", "baby");
                }
                IList<HtmlElement> inputList = Utility.GetHtmlElementChildrenByTagname(lastPassage, "INPUT");
                if (cardtype == "0")
                {
                    inputList[3].SetAttribute("value", "身份证");
                }
                else if (cardtype == "1")
                {
                    inputList[3].SetAttribute("value", "护照");
                }

                inputList[1].SetAttribute("value", name);
                inputList[4].SetAttribute("value", cardcode);
            }
        }

        public string GetOrderinfo()
        {
            if (BrowserPage.BrowserURL.OriginalString.StartsWith("http://flights.ctrip.com/Domestic/InputDeliver.aspx"))
            {
                StringBuilder builder = new StringBuilder();
                builder.Append("<?xml version=\"1.0\" encoding=\"gb2312\"?><Order>");

                HtmlElement infoDiv = BrowserPage.GetElementByTagID("base_main");
                HtmlElement firstDiv = Utility.GetHtmlElementChildrenByTagname(infoDiv, "DIV")[0];

                //获得航班及乘客信息节点
                HtmlElement lineInfo = Utility.GetHtmlElementChildrenByTagname(firstDiv, "DIV")[0];

                HtmlElement childLine = Utility.GetHtmlElementChildrenByTagname(lineInfo, "SPAN")[1];
                string sTotalAmount = childLine.Document.GetElementById("totalAmount").InnerText;
                builder.Append("<totalAmount>"+sTotalAmount+"</totalAmount>");
                    //获取航班信息
                HtmlElement hanbanList = Utility.GetHtmlElementChildrenByTagname(childLine, "DIV")[2];
                HtmlElementCollection tableList = hanbanList.GetElementsByTagName("TABLE");
                HandleFreight(builder, tableList);
                  //获取乘客信息
                HtmlElementCollection myTableList = childLine.GetElementsByTagName("TABLE");

                HtmlElement passageTable = myTableList[myTableList.Count - 1];
                HandlePassage(builder, passageTable);
                //获得配送及联系信息
                HtmlElement linkInfo = Utility.GetHtmlElementChildrenByTagname(firstDiv, "UL")[1];
                HandleSendInfo(builder, linkInfo);
                builder.Append("</Order>");
                return builder.ToString();
            }
            return "";
        }
        private void HandleSendInfo(StringBuilder builder, HtmlElement info)
        {
            IList<HtmlElement> tableList = Utility.GetHtmlElementChildrenByTagname(info, "TABLE");
            builder.Append("<sendinfo>");
            HtmlElementCollection firstTRs = tableList[0].GetElementsByTagName("TR");
            HtmlElementCollection firstTDs = firstTRs[1].GetElementsByTagName("TD");
            builder.Append("<sendtype>" + firstTDs[0].InnerText + "</sendtype>");
            builder.Append("<address>" + firstTDs[1].InnerText + "</address>");
            builder.Append("<paytype>" + firstTDs[2].InnerText + "</paytype>");
            HtmlElementCollection secondTDs = tableList[1].GetElementsByTagName("TD");
            HtmlElementCollection spanList = secondTDs[0].GetElementsByTagName("SPAN");
            builder.Append("<linkname>" + spanList[0].InnerText + "</linkname>");
            builder.Append("<mobile>" + spanList[1].InnerText + "</mobile>");
            builder.Append("<tel>" + spanList[2].InnerText + "</tel>");
            builder.Append("<email>" + spanList[3].InnerText + "</email>");
            builder.Append("</sendinfo>");
        }

        private void HandlePassage(StringBuilder builder, HtmlElement passages)
        {
            HtmlElementCollection trList = passages.GetElementsByTagName("TR");
            builder.Append("<passagers>");
            for (int i = 0; i < trList.Count - 1;i++ )
            {
                builder.Append("<passager>");
                HtmlElementCollection tdList = trList[i].GetElementsByTagName("TD");
                builder.Append("<name>" + tdList[0].InnerText.Replace("乘客：", "") + "</name>");
                builder.Append("<cardType>" + tdList[1].InnerText + "</cardType>");
                builder.Append("<cardno>" + tdList[2].InnerText + "</cardno>");
                builder.Append("<insurance>" + tdList[3].InnerText + "</insurance>");
                builder.Append("</passager>");
            }
            builder.Append("</passagers>");
        }

        private void HandleFreight(StringBuilder builder, HtmlElementCollection tableList)
        {
            builder.Append("<Freight>");
            for (int i = 0; i < tableList.Count; i++)
            {
                builder.Append("<line>");
                HtmlElementCollection tdList = tableList[i].GetElementsByTagName("TD");
                //航空公司
                string companyText = tdList[0].GetElementsByTagName("DIV")[0].InnerText;
                string[] companys = companyText.Split(char.Parse(" "));
                builder.Append("<company>"+companys[0]+"</company>");
                builder.Append("<lineno>" + companys[1] + "</lineno>");
                //机型
                string typeText = tdList[1].GetElementsByTagName("SPAN")[0].InnerText;
                builder.Append("<planetype>" + typeText + "</planetype>");
                //舱位
                builder.Append("<cabin>" + tdList[2].InnerText + "</cabin>");
                //航班时刻
                string ftime = tdList[4].InnerHtml;
                string[] timeArray = ftime.Split("<BR>".ToArray());
                builder.Append("<from>" + timeArray[0] + "</from>");
                builder.Append("<to>" + timeArray[4] + "</to>");
                //价格
                builder.Append("<price>" + tdList[5].InnerText + "</price>");
                builder.Append("</line>");
            }
            builder.Append("</Freight>");
        }

        public string GetPayInfo()
        {
            throw new NotImplementedException();
        }

        public void Reload()
        {
            this.thisPage.Reload();
        }


        public string ChannelID
        {
            get { return chanelidID; }
        }

        #endregion
    }


    
}

