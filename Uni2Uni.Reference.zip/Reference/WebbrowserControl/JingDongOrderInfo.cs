﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using uni2uni.com.Model.Order.Entity;

namespace WebbrowserControl
{
    public class JingDongOrderInfo:IOrderInfo
    {

        private IList<uni2uni.com.Model.Order.Entity.Entity_GeneralOrder> generalOrderList = new List<uni2uni.com.Model.Order.Entity.Entity_GeneralOrder>();

        public IList<uni2uni.com.Model.Order.Entity.Entity_GeneralOrder> GeneralOrderList
        {
            get
            {
                return generalOrderList;
            }
            set
            {
                generalOrderList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_ProductOrderDetail> productOrderDetailList = new List<uni2uni.com.Model.Order.Entity.Entity_ProductOrderDetail>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_ProductOrderDetail> ProductOrderDetailList
        {
            get
            {
                return productOrderDetailList;
            }
            set
            {
                productOrderDetailList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_FOPassenger> fOPassengerList = new List<uni2uni.com.Model.Order.Entity.Entity_FOPassenger>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_FOPassenger> FOPassengerList
        {
            get
            {
                return fOPassengerList;
            }
            set
            {
                fOPassengerList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_FOFlighting> fOFlightingList = new List<uni2uni.com.Model.Order.Entity.Entity_FOFlighting>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_FOFlighting> FOFlightingList
        {
            get
            {
                return fOFlightingList;
            }
            set
            {
                fOFlightingList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_HotelOrderPrice> hotelOrderPriceList = new List<uni2uni.com.Model.Order.Entity.Entity_HotelOrderPrice>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_HotelOrderPrice> HotelOrderPriceList
        {
            get
            {
                return hotelOrderPriceList;
            }
            set
            {
                hotelOrderPriceList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_HotelOrderDetail> hotelOrderDetailList = new List<uni2uni.com.Model.Order.Entity.Entity_HotelOrderDetail>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_HotelOrderDetail> HotelOrderDetailList
        {
            get
            {
                return hotelOrderDetailList;
            }
            set
            {
                hotelOrderDetailList = value;
            }
        }

        private IList<uni2uni.com.Model.Order.Entity.Entity_RESTOrder> restOrderList = new List<uni2uni.com.Model.Order.Entity.Entity_RESTOrder>();
        public IList<uni2uni.com.Model.Order.Entity.Entity_RESTOrder> RESTOrderList
        {
            get
            {
                return restOrderList;
            }
            set
            {
                restOrderList = value;
            }
        }

        private uni2uni.com.Model.Order.Entity.Entity_Order order = null;
        public uni2uni.com.Model.Order.Entity.Entity_Order Order
        {
            get
            {
                return order;
            }
            set
            {
                order = value;
            }
        }

        private uni2uni.com.Model.Order.Entity.Entity_OrderLinkDetail orderLinkDetail = null;
        public uni2uni.com.Model.Order.Entity.Entity_OrderLinkDetail OrderLinkDetail
        {
            get
            {
                return orderLinkDetail;
            }
            set
            {
                orderLinkDetail = value;
            }
        }

        public void GetInfoFromXml(string infoXml,string providerID,string channelID)
        {
            System.Xml.XmlDocument infoDoc = new System.Xml.XmlDocument();
            try
            {
                infoDoc.LoadXml(infoXml);
            }
            catch
            {
                return;
            }
            //订单ID
            string strRelatedID = new uni2uni.com.BLL.Order.Components.OrderSequenceCode().GetOrderSequenceCodeBySequenceName("OR");//预定号码
 
            //获取联系人节点
            XmlNode linkeNode = infoDoc.SelectSingleNode("/Order/sendinfo");
            if (linkeNode != null)
            {
                setEntity_OrderLinkDetail(strRelatedID, linkeNode);
            }
            //获取商品列表
            XmlNode prodoctNode = infoDoc.SelectSingleNode("/Order/products");
            //获取发票节点
            XmlNode invoicenode = infoDoc.SelectSingleNode("/Order/invoice");
            //获取备注
            XmlNode remarknode = infoDoc.SelectSingleNode("/Order/remark");
            //获取支付信息
            XmlNode paynode = infoDoc.SelectSingleNode("/Order/payinfo");
            //获取结算信息
            XmlNode warenode = infoDoc.SelectSingleNode("/Order/ware");

            Entity_GeneralOrder gorder = setEntity_GeneralOrder(strRelatedID, providerID, channelID, remarknode, invoicenode, paynode);

            string goosname = "";

            setEntity_ProductOrderDetail(gorder, prodoctNode, ref goosname);
            gorder.Productname = goosname;
            SetOrderPayInfo(gorder, warenode);

            SetOrder(gorder);
            generalOrderList.Add(gorder);
        }

        private void SetOrder(Entity_GeneralOrder gorder)
        {
            order = new Entity_Order();
            order.RelatedID = gorder.RelatedID;
            order.OrderDate = DateTime.Now;
            order.CustID = gorder.CustID;
            order.CardNo = "";
            order.PayKind = gorder.PayKind;
            order.Paystate = gorder.PayState;
            order.OrderState = "1";
            order.TotalAmount = gorder.TotalMoney;
            order.ActualAmount = gorder.TotalMoney;
            order.DeliveryCosts = gorder.DeliveryCosts;
            order.IsTest = "0";
            order.Source = "1";
            order.OrderType = 0;
        }
        private void SetOrderPayInfo(Entity_GeneralOrder gorder,XmlNode warenode)
        {
            if (warenode != null)
            {
                string goods = warenode.SelectSingleNode("amount").InnerText;
                string freight = warenode.SelectSingleNode("freight").InnerText;
                string off = warenode.SelectSingleNode("off").InnerText;
                string lipins = warenode.SelectSingleNode("goodscard").InnerText;
                decimal amount = decimal.Parse(goods) + decimal.Parse(freight) - decimal.Parse(off) - decimal.Parse(lipins);
                gorder.TotalMoney = amount;
                gorder.DeliveryCosts = decimal.Parse(freight);
            }
        }
        private void setEntity_ProductOrderDetail(Entity_GeneralOrder gorder, XmlNode prodoctNode,ref string pname)
        {
            XmlNodeList nodeList = prodoctNode.SelectNodes("//product");
            if (nodeList != null && nodeList.Count > 0)
            {
                for (int i = 0; i < nodeList.Count; i++)
                {
                    Entity_ProductOrderDetail entity_ProductOrderDetail = new Entity_ProductOrderDetail();
                    entity_ProductOrderDetail.OrderID = gorder.OrderID;
                    entity_ProductOrderDetail.ProductID = nodeList[i].SelectSingleNode("productid").InnerText;
                    entity_ProductOrderDetail.ProductCode = 0;
                    entity_ProductOrderDetail.ProviderID = nodeList[i].SelectSingleNode("productid").InnerText;
                    entity_ProductOrderDetail.ChannelID = gorder.ChannelID;
                    entity_ProductOrderDetail.ProductName = nodeList[i].SelectSingleNode("productname").InnerText;
                    pname += entity_ProductOrderDetail.ProductName+"，";
                    entity_ProductOrderDetail.Unit = "件";
                    entity_ProductOrderDetail.OrderNumber =int.Parse(nodeList[i].SelectSingleNode("count").InnerText);
                    entity_ProductOrderDetail.Price = decimal.Parse(nodeList[i].SelectSingleNode("price").InnerText);
                    entity_ProductOrderDetail.RebateRate = 0m;
                    entity_ProductOrderDetail.CustRebateRate = 0m;
                    entity_ProductOrderDetail.LineState = "0";
                    ProductOrderDetailList.Add(entity_ProductOrderDetail);
                }
            }
        }
        /// <summary>
        /// 联系信息
        /// </summary>
        /// <returns></returns>
        private void setEntity_OrderLinkDetail(string strRelatedID, XmlNode linkeNode)
        {
            orderLinkDetail = new uni2uni.com.Model.Order.Entity.Entity_OrderLinkDetail();
            orderLinkDetail.RelatedID = strRelatedID;
            orderLinkDetail.MemberID = Utility.GetCurrentUserID();
            orderLinkDetail.CustName = linkeNode.SelectSingleNode("//linkname").InnerText;
            orderLinkDetail.Mobile = linkeNode.SelectSingleNode("//mobile").InnerText;
            orderLinkDetail.Telephone = linkeNode.SelectSingleNode("//tel").InnerText;
            orderLinkDetail.Fax = "";
            orderLinkDetail.Email = linkeNode.SelectSingleNode("//Email").InnerText;
            orderLinkDetail.Address = linkeNode.SelectSingleNode("//address").InnerText;
            orderLinkDetail.Zip = linkeNode.SelectSingleNode("//zip").InnerText;
            orderLinkDetail.Attachment ="";
        }

        private Entity_GeneralOrder setEntity_GeneralOrder(string strRelatedID, string providerID, string channelID, XmlNode remarknode, XmlNode invoicenode, XmlNode paynode)
        {
            Entity_GeneralOrder entity_GeneralOrder = new Entity_GeneralOrder();

            entity_GeneralOrder.RelatedID = strRelatedID;
            entity_GeneralOrder.OrderID = new uni2uni.com.BLL.Order.Components.OrderSequenceCode().GetOrderSequenceCodeBySequenceName("JD");
            entity_GeneralOrder.ChannelID = new Guid(channelID);
            entity_GeneralOrder.ProviderID = providerID;
            entity_GeneralOrder.OrderDecribe = remarknode.SelectSingleNode("/remark").InnerText;

            entity_GeneralOrder.SourceOrderID = "";
            entity_GeneralOrder.OrderDate = DateTime.Now;
            entity_GeneralOrder.CustID = Utility.GetCurrentUserID().ToString();

            entity_GeneralOrder.OpState = "0";
            entity_GeneralOrder.OrderState = "3";

            entity_GeneralOrder.SendTime = DateTime.Now;


            // sumSendFee += entity_GeneralOrder.DeliveryCosts;//累加总配送费

            entity_GeneralOrder.TicketTitle = invoicenode.SelectSingleNode("//invtitle").InnerText;
            entity_GeneralOrder.TicketState = "0";//开发票
            entity_GeneralOrder.PayState = "0";
            entity_GeneralOrder.PayKind = "0";
            entity_GeneralOrder.Remark = paynode.SelectSingleNode("/paytype").InnerText + "," +
                paynode.SelectSingleNode("/sendtype").InnerText + "," + paynode.SelectSingleNode("/sendtime").InnerText + ","
                + paynode.SelectSingleNode("/freight").InnerText + ",";
            entity_GeneralOrder.UpdateTime = DateTime.Now;
            entity_GeneralOrder.UpdateID = "";
            entity_GeneralOrder.InsertTime = DateTime.Now;
            entity_GeneralOrder.InsertID = "";
            string coat = paynode.SelectSingleNode("/freight").InnerText;
            entity_GeneralOrder.DeliveryCosts = decimal.Parse(coat.Substring(0, coat.IndexOf("元")));
            return entity_GeneralOrder;
        }



       
       
    }
}
