﻿/*----------------------------------------------------------------
// Copyright (C) 2008 北京时空信联网络技术有限公司版权所有。 
//
//  文 件 名：GetProvider.cs
//  功能描述：提供供货商数据来源
//
//	 
//  创建时间：2008-09-24
//  创 建 人：张海旭 
//  部    门：技术部
//  职    务：
//
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Text;

namespace uni2uni.com.WebCached
{
    /// <summary>
    /// 定义网站Session操作的通用接口，方便对session改变管理方式时程序不用修改
    /// </summary>
    public interface ISession
    {
        /// <summary>
        /// Gets or sets 会话有效期
        /// </summary>
        /// <returns>有效期（秒）</returns>
        int ExpireSecond
        {
            get;
            set;
        }

        /// <summary>
        ///  Gets or sets键值的索引器
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>对象</returns>
        object this[string key] 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// 获得当前Session的ID
        /// </summary>
        /// <returns>SessionID</returns>
        string GetSessionID();

        /// <summary>
        /// 启动Session操作
        /// </summary>
        void start();

        /// <summary>
        /// 该键值在Session中是否存在
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>键值在Session中是否存在 true 存在 false 不存在</returns>
        bool IsRegistered(string key);

        /// <summary>
        /// 该键值在Session中是否存在
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="sessionID">sessionID</param>
        /// <returns>键值在Session中是否存在 true 存在 false 不存在</returns>
        bool IsRegistered(string key, string sessionID);

        /// <summary>
        /// 将键值存入当前Session中
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要存入的值</param>
        /// <returns> true 成功 false 失败</returns>
        bool Add(string key, object value);

        /// <summary>
        /// 将键值存入当前Session中
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要存入的值</param>
        /// <param name="sessionID">会话ID</param>
        /// <returns> true 成功 false 失败</returns>
        bool Add(string key, object value, string sessionID);
        
        /// <summary>
        /// 移出当前Session中的键值项
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns> true 成功 false 失败</returns>
        bool Remove(string key);

        /// <summary>
        /// 移出当前Session中的键值项
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="sessionID">会话ID</param>
        /// <returns>true 成功 false 失败</returns>
        bool Revome(string key, string sessionID);

        /// <summary>
        /// 清除当前Session中的所有键值
        /// </summary>
        /// <returns>true 成功 false 失败</returns>
        bool Clear();

        /// <summary>
        /// 清除当前Session中的所有键值
        /// </summary>
        /// <param name="sessionID">会话ID</param>
        /// <returns>true 成功 false 失败</returns>
        bool Clear(string sessionID);
        
        /// <summary>
        /// 获得当前Session中的键值
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>对象</returns>
        object Get(string key);

        /// <summary>
        /// 获得当前Session中的键值
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="sessionID">会话ID</param>
        /// <returns>true 成功 false 失败</returns>
        object Get(string key, string sessionID);

        /// <summary>
        /// 清除当前Session
        /// </summary>
        /// <returns>true 成功 false 失败</returns>
        bool Abandon();

        /// <summary>
        /// 清除当前Session
        /// </summary>
        /// <param name="sessionID">会话ID</param>
        /// <returns>true 成功 false 失败</returns>
        bool Abandon(string sessionID);
    }
}