﻿/*----------------------------------------------------------------
// Copyright (C) 2008 北京时空信联网络技术有限公司版权所有。 
//
//  文 件 名：MemcachedCache.cs
//  功能描述：cache处理类，实现ICache接口
//
//	 
//  创建时间：2008-09-27
//  创 建 人：张海旭
//  部    门：技术部
//  职    务：
//
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Text;

namespace uni2uni.com.WebCached
{
    /// <summary>
    /// cache处理类，实现ICache接口
    /// </summary>
    public class MemcachedCache : ICache
    {
        /// <summary>
        /// cached实际处理类
        /// </summary>
        private MemCachedHandler memHandler = new MemCachedHandler();

        #region ICache 成员

        /// <summary>
        /// 键值的索引器
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns> 对象</returns>
        public object this[string key]
        {
            get
            {
                return this.memHandler.Get(key);
            }

            set
            {
                this.memHandler.Set(key, value);
            }
        }

        /// <summary>
        /// 该键值在cached中是否存在
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>键值在cached中是否存在 true 存在 false 不存在</returns>
        public bool IsRegistered(string key)
        {
            return this.memHandler.KeyIsExist(key);
        }

        /// <summary>
        /// 将键值存入当前cached中
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要存入的值</param>
        /// <returns> true 成功 false 失败</returns>
        public bool Add(string key, object value)
        {
            return this.memHandler.Add(key, value);
        }

        /// <summary>
        /// 将键值存入当前cached中
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要存入的值</param>
        /// <param name="secound">失效时间(秒)</param>
        /// <returns> true 成功 false 失败</returns>
        public bool Add(string key, object value, int secound)
        {
            return this.memHandler.Add(key, value, secound);
        }

        /// <summary>
        /// 移出当前cached中的键值项
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns> true 成功 false 失败</returns>
        public bool Remove(string key)
        {
            return this.memHandler.Remove(key);
        }

        /// <summary>
        /// 清除当前cached中的所有键值
        /// </summary>
        /// <returns> true 成功 false 失败</returns>
        public bool Clear()
        {
            return false;
        }

        /// <summary>
        /// 获取当前cache的键值
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>对象</returns>
        public object Get(string key)
        {
            return this.memHandler.Get(key);
        }
        #endregion
    }
}