﻿/*----------------------------------------------------------------
// Copyright (C) 2008 北京时空信联网络技术有限公司版权所有。 
//
//  文 件 名：GetProvider.cs
//  功能描述：提供供货商数据来源
//	 
//  创建时间：2008-09-26
//  创 建 人：张海旭 
//  部    门：技术部
//  职    务：
//
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace uni2uni.com.WebCached
{
    /// <summary>
    /// 网站cache的通用接口，对应于catch的不同实现
    /// </summary>
    public interface ICache
    {
        /// <summary>
        /// Gets or sets 键值的索引器.
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>对象</returns>
        object this[string key] 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// 该键值在cached中是否存在
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>键值在cached中是否存在 true 存在 false 不存在</returns>
        bool IsRegistered(string key);

        /// <summary>
        /// 将键值存入当前cached中
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要存入的值</param>
        /// <returns> true 存入成功 false 失败</returns>
        bool Add(string key, object value);

        /// <summary>
        /// 将键值存入当前cached中
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要存入的值</param>
        /// <param name="secound">过期期限</param>
        /// <returns> true 存入成功 false 失败</returns>
        bool Add(string key, object value ,int secound);

        /// <summary>
        /// 移出当前cached中的键值项
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns> true成功 false 失败</returns>
        bool Remove(string key);

        /// <summary>
        /// 清除当前cached中的所有键值
        /// </summary>
        /// <returns> true 成功 false 失败</returns>
        bool Clear();

        /// <summary>
        /// 获取当前cache中的对象
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>对象</returns>
        object Get(string key);
    }
}