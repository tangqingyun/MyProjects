﻿/*----------------------------------------------------------------
// Copyright (C) 2008 北京时空信联网络技术有限公司版权所有。 
//
//  文 件 名：MemcachedSession.cs
//  功能描述：session处理类，实现Isession接口
//	 
//  创建时间：2008-09-27
//  创 建 人：张海旭
//  部    门：技术部
//  职    务：
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace uni2uni.com.WebCached
{
    /// <summary>
    /// memcached的Session包装类
    /// </summary>
    public class MemcachedSession : ISession
    {
        /// <summary>
        /// memccahed的实际处理类
        /// </summary>
        private MemCachedHandler memHandler = new MemCachedHandler();

        /// <summary>
        /// 过期期限
        /// </summary>
        private int expireSecond;

        /// <summary>
        /// 域名
        /// </summary>
        private string domainName;

        /// <summary>
        /// 服务器列表
        /// </summary>
        private string[] serverList;

        #region ISession 成员

        /// <summary>
        /// Gets or sets会话有效期
        /// </summary>
        public int ExpireSecond
        {
            get
            {
                return this.expireSecond;
            }

            set
            {
                this.expireSecond = value;
            }
        }

        /// <summary>
        /// Gets or sets cookie域名称
        /// </summary>
        public string DomainName
        {
            get
            {
                return this.domainName;
            }

            set
            {
                this.domainName = value;
            }
        }

        /// <summary>
        /// Gets or sets cookie域名称
        /// </summary>
        public string[] ServerList
        {
            get 
            {
                return this.serverList; 
            }

            set 
            {
                this.serverList = value; 
            }
        }

        /// <summary>
        /// Gets or sets 索引器
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>对象</returns>
        public object this[string key]
        {
            get
            {
                return this.Get(key);
            }

            set
            {
                this.Add(key, value);
            }
        }

        /// <summary>
        /// 获取新会话ID
        /// </summary>
        /// <returns>会话ID</returns>
        public string GetSessionID()
        {
            System.TimeSpan mySpan = DateTime.Now.Subtract(DateTime.Parse("2000-01-01"));

            return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(mySpan.TotalMilliseconds.ToString(), "MD5").ToLower();
        }
        
        /// <summary>
        /// 初始化客户端
        /// </summary>
        public void start()
        {
            this.memHandler.ServerList = this.ServerList;
            this.memHandler.MinConnectionNumber = 3;
            this.memHandler.MaxConnectionNumber = 10;
            this.memHandler.init();
        }
        
        /// <summary>
        /// 键值是否在会话中存在
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>true 成功 false 失败</returns>
        public bool IsRegistered(string key)
        {
            HttpCookie myCookie = System.Web.HttpContext.Current.Request.Cookies["currentSessionID"];
            if (myCookie != null)
            {
                MemcachedSessionContainer container = (MemcachedSessionContainer)this.memHandler.Get(myCookie.Value);
                if (container != null)
                {
                    bool isOK = container.KeyIsExist(key);
                    this.memHandler.Replace(myCookie.Value, container, this.expireSecond);
                    return isOK;
                }
                else
                {
                    container = this.InitContainer(string.Empty, string.Empty, myCookie);
                    this.memHandler.Add(myCookie.Value, container, this.expireSecond);
                }
            }
            else
            {
                myCookie = this.InitCookie(myCookie);
                MemcachedSessionContainer container = this.InitContainer(string.Empty, string.Empty, myCookie);
                this.memHandler.Add(myCookie.Value, container, this.expireSecond);
            }

            return false;
        }
        
        /// <summary>
        /// 在Session中增加项
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">对象</param>
        /// <returns>true 成功 false 失败</returns>
        public bool Add(string key, object value)
        {
             HttpCookie myCookie = System.Web.HttpContext.Current.Request.Cookies["currentSessionID"];
             if (myCookie != null)
             {
                 object containerObj = this.memHandler.Get(myCookie.Value);
                 if (containerObj != null)
                 {
                     MemcachedSessionContainer container = (MemcachedSessionContainer)containerObj;
                     this.RefreshSession(container);
                     string memchedKey = this.GetMemcchachedKey(key, myCookie.Value);
                     container.Add(key, memchedKey);
                     this.memHandler.Set(myCookie.Value, container, this.expireSecond);
                     return this.memHandler.Set(memchedKey, value);
                 }
                 else
                 {
                     string memchedKey = this.GetMemcchachedKey(key, myCookie.Value);
                     MemcachedSessionContainer container = this.InitContainer(key, memchedKey, myCookie);
                     this.memHandler.Set(myCookie.Value, container, this.expireSecond);
                     return this.memHandler.Set(memchedKey, value);
                 }
             }
             else
             {
                 myCookie = this.InitCookie(myCookie);
                 string memchedKey = this.GetMemcchachedKey(key, myCookie.Value);
                 MemcachedSessionContainer container = this.InitContainer(key, memchedKey, myCookie);
                 this.memHandler.Set(myCookie.Value, container, this.expireSecond);
                 return this.memHandler.Set(memchedKey, value);
             }
        }

        /// <summary>
        /// 移除键值
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>true 成功 false 失败</returns>
        public bool Remove(string key)
        {
            HttpCookie myCookie = System.Web.HttpContext.Current.Request.Cookies["currentSessionID"];
            if (myCookie != null)
            {
                object containerObj = this.memHandler.Get(myCookie.Value);
                if (containerObj != null)
                {
                    MemcachedSessionContainer container = (MemcachedSessionContainer)containerObj;
                    object memchedKey = container.Get(key);
                    if (memchedKey != null)
                    {
                        this.memHandler.Remove(memchedKey.ToString());
                        container.Remove(key);
                        this.RefreshSession(container);
                        return this.memHandler.Set(myCookie.Value, container, this.expireSecond);
                    }

                    return true;
                }
                else
                {
                    MemcachedSessionContainer container = this.InitContainer(string.Empty, string.Empty, myCookie);
                    return this.memHandler.Add(myCookie.Value, container, this.expireSecond);
                }
            }
            else
            {
                myCookie = this.InitCookie(myCookie);
                MemcachedSessionContainer container = this.InitContainer(string.Empty, string.Empty, myCookie);
                return this.memHandler.Add(myCookie.Value, container, this.expireSecond);
            }
        }

        /// <summary>
        /// 清除所有信息项
        /// </summary>
        /// <returns>true 成功 false 失败</returns>
        public bool Clear()
        {
            HttpCookie myCookie = System.Web.HttpContext.Current.Request.Cookies["currentSessionID"];
            if (myCookie != null)
            {
                object containerObj = this.memHandler.Get(myCookie.Value);
                if (containerObj != null)
                {
                    MemcachedSessionContainer container = (MemcachedSessionContainer)containerObj;

                    foreach (string memkey in container.SessionObject.Keys)
                    {
                        this.memHandler.Remove(container.Get(memkey).ToString());
                    }

                    container.Clear();
                    return this.memHandler.Replace(myCookie.Value, container, this.expireSecond);
                }
                else
                {
                    MemcachedSessionContainer container = this.InitContainer(string.Empty, string.Empty, myCookie);
                    return this.memHandler.Add(myCookie.Value, container, this.expireSecond);
                }
            }
            else
            {
                myCookie = this.InitCookie(myCookie);
                MemcachedSessionContainer container = this.InitContainer(string.Empty, string.Empty, myCookie);
                return this.memHandler.Add(myCookie.Value, container, this.expireSecond);
            }
        }

        /// <summary>
        /// 失效本次会话
        /// </summary>
        /// <returns>true 成功 false 失败</returns>
        public bool Abandon()
        {
            HttpCookie myCookie = System.Web.HttpContext.Current.Request.Cookies["currentSessionID"];
            if (myCookie != null)
            {
                if (this.memHandler.KeyIsExist(myCookie.Value))
                {
                    object containerObj = this.memHandler.Get(myCookie.Value);

                    if (containerObj != null)
                    {
                        MemcachedSessionContainer container = (MemcachedSessionContainer)containerObj;
                        foreach (string memkey in container.SessionObject.Keys)
                        {
                            this.memHandler.Remove(container.Get(memkey).ToString());
                        }
                    }

                    this.memHandler.Remove(myCookie.Value);
                    System.Web.HttpContext.Current.Response.Cookies.Remove("currentSessionID");
                }
            }

            return true;
        }

        /// <summary>
        /// 获得信息项
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>对象</returns>
        public object Get(string key)
        {
            HttpCookie myCookie = System.Web.HttpContext.Current.Request.Cookies["currentSessionID"];
            if (myCookie != null)
            {
                object containerObj = this.memHandler.Get(myCookie.Value);

                if (containerObj != null)
                {
                    MemcachedSessionContainer container = (MemcachedSessionContainer)containerObj;
                    object obj = container.Get(key);
                    object returnObj = null;

                    if (obj != null)
                    {
                        returnObj = this.memHandler.Get(obj.ToString());
                    }

                    this.RefreshSession(container);
                    this.memHandler.Replace(myCookie.Value, container, this.expireSecond);
                    return returnObj;
                }
                else
                {
                    MemcachedSessionContainer container = this.InitContainer(string.Empty, string.Empty, myCookie);
                    this.memHandler.Add(myCookie.Value, container, this.expireSecond);
                    return null;
                }
            }
            else
            {
                myCookie = this.InitCookie(myCookie);
                MemcachedSessionContainer container = this.InitContainer(string.Empty, string.Empty, myCookie);
                this.memHandler.Add(myCookie.Value, container, this.expireSecond);
                return null;
            }
        }

        /// <summary>
        /// 键值是否在会话中存在
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="sessionID">会话ID</param>
        /// <returns>true 成功 false 失败</returns>
        public bool IsRegistered(string key, string sessionID)
        {
            MemcachedSessionContainer container = (MemcachedSessionContainer)this.memHandler.Get(sessionID);

            if (container != null)
            {
                bool isOK = container.KeyIsExist(key);
                this.memHandler.Replace(sessionID, container, this.expireSecond);
                return isOK;
            }
            else
            {
                container = this.InitContainer(string.Empty, string.Empty, sessionID);
                this.memHandler.Add(sessionID, container, this.expireSecond);
                return false;
            }
        }

        /// <summary>
        /// 在Session中增加项
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">对象</param>
        /// <param name="sessionID">会话ID</param>
        /// <returns>true 成功 false 失败</returns>
        public bool Add(string key, object value, string sessionID)
        {
            object containerObj = this.memHandler.Get(sessionID);

            if (containerObj != null)
            {
                MemcachedSessionContainer container = (MemcachedSessionContainer)containerObj;
                this.RefreshSession(container);
                string memchedKey = this.GetMemcchachedKey(key, sessionID);
                container.Add(key, memchedKey);
                this.memHandler.Set(sessionID, container, this.expireSecond);
                return this.memHandler.Set(memchedKey, value);
            }
            else
            {
                string memchedKey = this.GetMemcchachedKey(key, sessionID);
                MemcachedSessionContainer container = this.InitContainer(key, memchedKey, sessionID);
                this.memHandler.Set(sessionID, container, this.expireSecond);
                return this.memHandler.Set(memchedKey, value);
            }
        }

        /// <summary>
        /// 在Session中移除项
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="sessionID">会话ID</param>
        /// <returns>true 成功 false 失败</returns>
        public bool Revome(string key, string sessionID)
        {
            object containerObj = this.memHandler.Get(sessionID);

            if (containerObj != null)
            {
                MemcachedSessionContainer container = (MemcachedSessionContainer)containerObj;
                object memchedKey = container.Get(key);

                if (memchedKey != null)
                {
                    this.memHandler.Remove(memchedKey.ToString());
                    container.Remove(key);
                    this.RefreshSession(container);
                    return this.memHandler.Set(sessionID, container, this.expireSecond);
                }

                return true;
            }
            else
            {
                MemcachedSessionContainer container = this.InitContainer(string.Empty, string.Empty, sessionID);
                return this.memHandler.Add(sessionID, container, this.expireSecond);
            }
        }

        /// <summary>
        /// 清除session中的所有项
        /// </summary>
        /// <param name="sessionID">会话ID</param>
        /// <returns>true 成功 false 失败</returns>
        public bool Clear(string sessionID)
        {
            object containerObj = this.memHandler.Get(sessionID);

            if (containerObj != null)
            {
                MemcachedSessionContainer container = (MemcachedSessionContainer)containerObj;

                foreach (string memkey in container.SessionObject.Keys)
                {
                    this.memHandler.Remove(container.Get(memkey).ToString());
                }

                container.Clear();
                return this.memHandler.Replace(sessionID, container, this.expireSecond);
            }
            else
            {
                MemcachedSessionContainer container = this.InitContainer(string.Empty, string.Empty, sessionID);
                return this.memHandler.Add(sessionID, container, this.expireSecond);
            }
        }

        /// <summary>
        /// 获得信息项
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="sessionID">会话ID</param>
        /// <returns>对象</returns>
        public object Get(string key, string sessionID)
        {
            object containerObj = this.memHandler.Get(sessionID);

            if (containerObj != null)
            {
                MemcachedSessionContainer container = (MemcachedSessionContainer)containerObj;
                object obj = container.Get(key);
                object returnObj = null;

                if (obj != null)
                {
                    returnObj = this.memHandler.Get(obj.ToString());
                }

                this.RefreshSession(container);
                this.memHandler.Replace(sessionID, container, this.expireSecond);
                return returnObj;
            }
            else
            {
                MemcachedSessionContainer container = this.InitContainer(string.Empty, string.Empty, sessionID);
                this.memHandler.Add(sessionID, container, this.expireSecond);
                return null;
            }
        }

        /// <summary>
        /// 清除Session
        /// </summary>
        /// <param name="sessionID">会话ID</param>
        /// <returns>true 成功 false 失败</returns>
        public bool Abandon(string sessionID)
        {
            if (this.memHandler.KeyIsExist(sessionID))
            {
                object containerObj = this.memHandler.Get(sessionID);

                if (containerObj != null)
                {
                    MemcachedSessionContainer container = (MemcachedSessionContainer)containerObj;
                    foreach (string memkey in container.SessionObject.Keys)
                    {
                        this.memHandler.Remove(container.Get(memkey).ToString());
                    }
                }

                return this.memHandler.Remove(sessionID);
            }

            return false;
        }

        /// <summary>
        /// 初始化一个会话容器
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">存储对象</param>
        /// <param name="myCookie">标识cookie</param>
        /// <returns>会话容器</returns>
        private MemcachedSessionContainer InitContainer(string key, object value, HttpCookie myCookie)
        {
            MemcachedSessionContainer container = new MemcachedSessionContainer();
            container.SessionID = myCookie.Value;
            container.ExpireSecond = this.expireSecond;
            container.ExpireTime = DateTime.Now.AddSeconds(this.expireSecond);
            if (key.Length > 0)
            {
                container.Add(key, value);
            }

            return container;
        }

        /// <summary>
        /// 初始化一个会话容器
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">存储对象</param>
        /// <param name="sessionID">会话ID</param>
        /// <returns>会话容器</returns>
        private MemcachedSessionContainer InitContainer(string key, object value, string sessionID)
        {
            MemcachedSessionContainer container = new MemcachedSessionContainer();
            container.SessionID = sessionID;
            container.ExpireSecond = this.expireSecond;
            container.ExpireTime = DateTime.Now.AddSeconds(this.expireSecond);
            if (key.Length > 0)
            {
                container.Add(key, value);
            }

            return container;
        }

        /// <summary>
        /// 初始化Cookie
        /// </summary>
        /// <param name="myCookie">cookie变量</param>
        /// <returns>更新后的cookie</returns>
        private HttpCookie InitCookie(HttpCookie myCookie)
        {
            myCookie = new HttpCookie("currentSessionID");
            myCookie.Name = "currentSessionID";
            myCookie.Value = this.GetSessionID();
            myCookie.Domain = this.domainName;

            System.Web.HttpContext.Current.Response.AppendCookie(myCookie);
            return myCookie;
        }

        /// <summary>
        /// 将session值存入memcached的键
        /// </summary>
        /// <param name="key">原始键值</param>
        /// <param name="sesionID">会话ID</param>
        /// <returns>转换后的键值</returns>
        private string GetMemcchachedKey(string key, string sesionID)
        {
            return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(sesionID + " " + key, "MD5").ToLower();
        }

        /// <summary>
        /// 更新会话键值存放时间
        /// </summary>
        /// <param name="container">会话容器</param>
        private void RefreshSession(MemcachedSessionContainer container)
        {
            if (container.SessionObject.Keys.Count > 0)
            {
                TimeSpan mySpan = container.ExpireTime.Subtract(DateTime.Now);

                if (mySpan.TotalSeconds <= 600)
                {
                    string[] keys = new string[container.SessionObject.Keys.Count];
                    int i = 0;
                    
                    foreach (string memkey in container.SessionObject.Keys)
                    {
                        keys[i] = container.SessionObject[memkey].ToString();
                        i++;
                    }

                    System.Collections.Hashtable keysTable = this.memHandler.GetKeys(keys);
                    keysTable = null;
                }
            }
        }

        #endregion
    }
}
