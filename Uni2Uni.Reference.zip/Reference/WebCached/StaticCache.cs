﻿/*----------------------------------------------------------------
//	 
//  创建时间：2014-03-31
//  创 建 人：任海波
//  部    门：技术部
//  职    务：
//
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace uni2uni.com.WebCached
{
    public class StaticCache:ICache
    {
        /// <summary>
        /// cached实际处理类
        /// </summary>
        static Hashtable _cache = new Hashtable();//缓存队列
        static Hashtable _cachetimepoint = new Hashtable();//缓存过期时间点队列
        int _ExpireMinutes;//过期时间（分钟。默认480分钟，即8小时）

        public StaticCache(int expireminutes)
        {
            _ExpireMinutes = expireminutes;
        }

        public StaticCache():this(480)
        {
        }

        #region ICache 成员

        /// <summary>
        /// 键值的索引器
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns> 对象</returns>
        public object this[string key]
        {
            get
            {
                _cachetimepoint[key] = DateTime.Now;
                return _cache[key];
            }

            set
            {
                if (_cache.ContainsKey(key))
                {
                    _cache.Remove(key);
                }

                _cache.Add(key, value);
                _cachetimepoint[key] = DateTime.Now;
            }
        }

        /// <summary>
        /// 该键值在cached中是否存在
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>键值在cached中是否存在 true 存在 false 不存在</returns>
        public bool IsRegistered(string key)
        {
            return _cache.ContainsKey(key);
        }

        /// <summary>
        /// 将键值存入当前cached中
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要存入的值</param>
        /// <returns> true 成功 false 失败</returns>
        public bool Add(string key, object value)
        {
            try
            {
                if (_cache.ContainsKey(key))
                {
                    _cache.Remove(key);
                    _cachetimepoint.Remove(key);
                }

                _cache.Add(key, value);
                _cachetimepoint.Add(key, DateTime.Now);
                return true;
            }
            catch { return false; }
        }

        public bool Add(string key, object value, int secound) { return false;}

        /// <summary>
        /// 移出当前cached中的键值项
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns> true 成功 false 失败</returns>
        public bool Remove(string key)
        {
            try
            {
                if (_cache.ContainsKey(key))
                {
                    _cache.Remove(key);

                }
                if (_cachetimepoint.ContainsKey(key))
                {
                    _cachetimepoint.Remove(key);

                } 
                return true;

            }
            catch { return false; }
        }

        /// <summary>
        /// 清除当前cached中的所有键值
        /// </summary>
        /// <returns> true 成功 false 失败</returns>
        public bool Clear(string key)
        {
            try
            {
                ICollection keys = _cache.Keys;
                foreach (string s in keys)
                {
                    if (s.Contains(key))//与要删除的键值符合，直接删除
                    {
                        _cache.Remove(s);
                        _cachetimepoint.Remove(s);
                    }
                    else//与要删除的键值不符合，判断是否过期，过期则删除
                    {
                        TimeSpan span = DateTime.Now - Convert.ToDateTime(_cachetimepoint[key]);
                        if (span.Minutes > _ExpireMinutes)
                        {
                            _cache.Remove(s);
                            _cachetimepoint.Remove(s);

                        }
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool Clear()
        { return false; }

        /// <summary>
        /// 获取当前cache的键值
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>对象</returns>
        public object Get(string key)
        {
            _cachetimepoint[key] = DateTime.Now;
            return _cache[key];
        }
        #endregion
    }
}