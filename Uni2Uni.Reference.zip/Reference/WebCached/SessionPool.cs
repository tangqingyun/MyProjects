﻿/*----------------------------------------------------------------
// Copyright (C) 2008 北京时空信联网络技术有限公司版权所有。 
//
//  文 件 名：SessionPool.cs
//  功能描述：memcached访问接口
//
//	 
//  创建时间：2008-09-27
//  创 建 人：张海旭 
//  部    门：技术部
//  职    务：
//
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Text;

namespace uni2uni.com.WebCached
{
    /// <summary>
    /// memcached访问接口
    /// </summary>
    public class SessionPool
    {
        /// <summary>
        /// 服务器接口
        /// </summary>
        private static string[] serverList;

        /// <summary>
        /// 有效时间
        /// </summary>
        private static int expireSecond;

        /// <summary>
        /// 域名
        /// </summary>
        private static string domainName;

        /// <summary>
        /// Session访问类
        /// </summary>
        private static MemcachedSession memSession = null;

        /// <summary>
        /// cache访问类
        /// </summary>
        private static MemcachedCache memcache = null;

        /// <summary>
        /// Gets or sets 服务器列表
        /// </summary>
        public static string[] ServerList
        {
            set 
            { 
                serverList = value; 
            }

            get 
            { 
                return serverList; 
            }
        }

        /// <summary>
        /// Gets or sets  session超时时间
        /// </summary>
        public static int ExpireSecond
        {
            set 
            { 
                expireSecond = value; 
            }

            get 
            { 
                return expireSecond; 
            }
        }

        /// <summary>
        /// Gets or sets 域名
        /// </summary>
        public static string DomainName
        {
            set 
            { 
                domainName = value; 
            }

            get 
            { 
                return domainName; 
            }
        }

        /// <summary>
        /// 启动memcached连接
        /// </summary>
        public static void start()
        {
            if (memSession == null)
            {
                memSession = new MemcachedSession();
                memSession.ServerList = serverList;
                memSession.ExpireSecond = expireSecond;
                memSession.DomainName = domainName;
                memSession.start();
            }
        }

        /// <summary>
        /// 获得session操作的实例
        /// </summary>
        /// <returns>sesioon操作对象</returns>
        public static ISession GetSessionInstance()
        {
            return memSession;
        }

        /// <summary>
        /// 获得cache的实例
        /// </summary>
        /// <returns>cache操作对象</returns>
        public static ICache GetCacheInstance()
        {
            if (memcache == null)
            {
                memcache = new MemcachedCache();
            }

            return memcache;
        }
    }
}
