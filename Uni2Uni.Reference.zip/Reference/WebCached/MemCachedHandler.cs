﻿/*----------------------------------------------------------------
// Copyright (C) 2008 北京时空信联网络技术有限公司版权所有。 
//
//  文 件 名：MemCachedHandler.cs
//  功能描述：memcached的客户端辅助处理类
//
//	 
//  创建时间：2008-09-28
//  创 建 人：张海旭 
//  部    门：技术部
//  职    务：
//
//----------------------------------------------------------------*/
using System;
using System.Collections;
using System.Text;
using Memcached.ClientLibrary;

namespace uni2uni.com.WebCached
{
    /// <summary>
    /// memcached客户端操作的封装类
    /// </summary>
    public class MemCachedHandler
    {
        /// <summary>
        /// memcached服务器列表
        /// </summary>
        private string[] serverList;

        /// <summary>
        /// 最大连接数
        /// </summary>
        private int maxConnectionNumber;

        /// <summary>
        /// 最小连接数
        /// </summary>
        private int minConnectionNumber;
        
        /// <summary>
        /// Gets or sets memcached服务器列表，字符串格式为“服务器IP:端口号”，如{"192.168.1.1:11211","192.168.1.210:9988"}
        /// </summary>
        public string[] ServerList
        {
            set 
            { 
                this.serverList = value; 
            }

            get 
            { 
                return this.serverList; 
            }
        }

        /// <summary>
        /// Gets or sets 连接池的最大连接数
        /// </summary>
        public int MaxConnectionNumber
        {
            set 
            { 
                this.maxConnectionNumber = value; 
            }

            get 
            { 
                return this.maxConnectionNumber; 
            }
        }

        /// <summary>
        /// Gets or sets 连接池的最小连接数
        /// </summary>
        public int MinConnectionNumber
        {
            set 
            { 
                this.minConnectionNumber = value; 
            }

            get 
            { 
                return this.minConnectionNumber; 
            }
        }

        /// <summary>
        /// 初始化连接池
        /// </summary>
        public void init()
        {
            SockIOPool pool = SockIOPool.GetInstance();
            if (this.ServerList != null && this.ServerList.Length > 0)
            {
                pool.SetServers(this.ServerList);

                if (this.MinConnectionNumber == 0)
                {
                    pool.InitConnections = 3;
                    pool.MinConnections = 3;
                }
                else
                {
                    pool.InitConnections = this.MinConnectionNumber;
                    pool.MinConnections = this.MinConnectionNumber;
                }

                if (this.MaxConnectionNumber == 0)
                {
                    pool.MaxConnections = 5;
                }
                else
                {
                    pool.MaxConnections = this.MaxConnectionNumber;
                }

                pool.SocketConnectTimeout = 10000;
                pool.SocketTimeout = 30000;

                pool.MaintenanceSleep = 30;
                pool.Failover = true;

                pool.Nagle = false;
                pool.Initialize();
            }
            else
            {
                throw new Exception("请输入正确的服务器列表");
            }
        }
        
        /// <summary>
        /// 缓存中插入值
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要保存的对象</param>
        /// <returns>true：插入成功 false：失败</returns>
        public bool Set(string key,object value)
        {
             // 获得客户端实例
                MemcachedClient memclient = new MemcachedClient();
                memclient.EnableCompression = false;
                return memclient.Set(key, value);
        }
       
        /// <summary>
        /// 缓存中插入值
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要保存的对象</param>
        /// <param name="second">设置过期的秒数</param>
        /// <returns>true：插入成功 false：失败</returns>
        public bool Set(string key, object value, int second)
        {
            // 获得客户端实例
                MemcachedClient memclient = new MemcachedClient();
                memclient.EnableCompression = false;
                return memclient.Set(key, value,DateTime.Now.AddSeconds(second));
        }
        
        /// <summary>
        /// 缓存中插入值
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要保存的对象</param>
        /// <param name="date">设置过期的时间</param>
        /// <returns>true：插入成功 false：失败</returns>
        public bool Set(string key, object value, DateTime date)
        {
            // 获得客户端实例
                MemcachedClient memclient = new MemcachedClient();
                memclient.EnableCompression = false;
                return memclient.Set(key, value, date); 
        }
        
        /// <summary>
        /// 缓存中新增值
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要保存的对象</param>
        /// <param name="second">设置过期的秒数</param>
        /// <returns>true：插入成功 false：失败</returns>
        public bool Add(string key, object value, int second)
        {
            // 获得客户端实例
                MemcachedClient memclient = new MemcachedClient();
                memclient.EnableCompression = false;
                return memclient.Set(key, value, DateTime.Now.AddSeconds(second));
        }
        
        /// <summary>
        /// 缓存中新增值
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要保存的对象</param>
        /// <param name="date">设置过期的时间</param>
        /// <returns>true：插入成功 false：失败</returns>
        public bool Add(string key, object value, DateTime date)
        {
            // 获得客户端实例
                MemcachedClient memclient = new MemcachedClient();
                memclient.EnableCompression = false;
                return memclient.Set(key, value, date);
        }
        
        /// <summary>
        /// 缓存中新增值
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要保存的对象</param>
        /// <returns>true：插入成功 false：失败</returns>
        public bool Add(string key, object value)
        {
            // 获得客户端实例
                MemcachedClient memclient = new MemcachedClient();
                memclient.EnableCompression = false;
                return memclient.Set(key, value);
        }

        /// <summary>
        /// 键值是否存在
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>true：存在 false：不存在</returns>
        public bool KeyIsExist(string key)
        {
            // 获得客户端实例
                MemcachedClient memclient = new MemcachedClient();
                memclient.EnableCompression = false;
                return memclient.KeyExists(key);
        }
        
        /// <summary>
        /// 替换键值
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要更新的对象</param>
        /// <returns>true：替换成功 false：失败</returns>
        public bool Replace(string key, object value)
        {
            // 获得客户端实例
                MemcachedClient memclient = new MemcachedClient();
                memclient.EnableCompression = false;
                return memclient.Set(key, value);
        }

        /// <summary>
        /// 替换键值
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要更新的对象</param>
        /// <param name="second">设置过期的秒数</param>
        /// <returns>true：替换成功 false：失败</returns>
        public bool Replace(string key, object value, int second)
        {
            // 获得客户端实例
            MemcachedClient memclient = new MemcachedClient();
            memclient.EnableCompression = false;
            return memclient.Set(key, value, DateTime.Now.AddSeconds(second));
        }

        /// <summary>
        /// 替换键值
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">要更新的对象</param>
        /// <param name="date">设置过期的时间</param>
        /// <returns>true：替换成功 false：失败</returns>
        public bool Replace(string key, object value, DateTime date)
        {
            // 获得客户端实例
            MemcachedClient memclient = new MemcachedClient();
            memclient.EnableCompression = false;
            return memclient.Set(key, value, date);
        }
        
        /// <summary>
        /// 移出键值
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>true：成功 false：失败</returns>
        public bool Remove(string key)
        {
            // 获得客户端实例
            MemcachedClient memclient = new MemcachedClient();
            memclient.EnableCompression = false;
            return memclient.Delete(key);
        }
        
        /// <summary>
        /// 移出所有项
        /// </summary>
        /// <returns>true：成功 false：失败</returns>
        public bool RemoveAll()
        {
            // 获得客户端实例
            MemcachedClient memclient = new MemcachedClient();
            memclient.EnableCompression = false;
            return memclient.FlushAll();
        }
        
        /// <summary>
        /// 获取键值项
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>存储的对象</returns>
        public object Get(string key)
        {
            // 获得客户端实例
            MemcachedClient memclient = new MemcachedClient();
            memclient.EnableCompression = false;
            return memclient.Get(key);
        }
        
        /// <summary>
        /// 获得一组键值的返回值
        /// </summary>
        /// <param name="keys">键值组</param>
        /// <returns>一组键值对应表</returns>
        public Hashtable GetKeys(string[] keys)
        {
            // 获得客户端实例
            MemcachedClient memclient = new MemcachedClient();
            memclient.EnableCompression = false;
            return memclient.GetMultiple(keys);
        }
        
        /// <summary>
        /// 关闭memclient客户端连接
        /// </summary>
        public void Close()
        {
            SockIOPool.GetInstance().Shutdown();
        }
    }
}
