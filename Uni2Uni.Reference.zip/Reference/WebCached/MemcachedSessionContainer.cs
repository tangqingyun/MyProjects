﻿/*----------------------------------------------------------------
// Copyright (C) 2008 北京时空信联网络技术有限公司版权所有。 
//
//  文 件 名：MemcachedSession.cs
//  功能描述：session处理类，实现Isession接口
//
//	 
//  创建时间：2008-09-27
//  创 建 人：张海旭 
//  部    门：技术部
//  职    务：
//
//----------------------------------------------------------------*/
using System;
using System.Collections;
using System.Text;

namespace uni2uni.com.WebCached
{
    /// <summary>
    /// 会话的信息保存类
    /// </summary>
    [Serializable]
    public class MemcachedSessionContainer
    {
        /// <summary>
        /// Session的客户键值与存储键值对集合
        /// </summary>
        public System.Collections.Hashtable SessionObject = new Hashtable();
        
        /// <summary>
        /// sessionID
        /// </summary>
        private string sessionid;

        /// <summary>
        /// 过时期限
        /// </summary>
        private DateTime expireTime;

        /// <summary>
        /// 过期时间
        /// </summary>
        private int expireSecond;

        /// <summary>
        /// Gets or sets 会话ID
        /// </summary>
        public string SessionID
        {
            set 
            { 
                this.sessionid = value; 
            }

            get 
            {
                return this.sessionid; 
            }
        }

        /// <summary>
        /// Gets or sets 会话过期时间
        /// </summary>
        public DateTime ExpireTime
        {
            set 
            {
                this.expireTime = value; 
            }

            get 
            {
                return this.expireTime; 
            }
        }

        /// <summary>
        /// Gets or sets 会话有效时长(秒)
        /// </summary>
        public int ExpireSecond
        {
            set 
            {
                this.expireSecond = value; 
            }

            get 
            {
                return this.expireSecond; 
            }
        }

        /// <summary>
        /// 键值是否存在
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>true:存在 false 不存在</returns>
        public bool KeyIsExist(string key)
        {
            return this.SessionObject.ContainsKey(key);
        }

        /// <summary>
        /// 加入信息项
        /// </summary>
        /// <param name="key">键值</param>
        /// <param name="value">信息项</param>
        public void Add(string key, object value)
        {
            if (this.SessionObject.ContainsKey(key))
            {
                this.SessionObject[key] = value;
            }
            else
            {
                this.SessionObject.Add(key, value);
            }

            this.expireTime = DateTime.Now.AddSeconds(this.expireSecond);
        }

        /// <summary>
        /// 清楚信息项
        /// </summary>
        /// <param name="key">键值</param>
        public void Remove(string key)
        {
            if (this.SessionObject.ContainsKey(key))
            {
                this.SessionObject.Remove(key);
            }

            this.expireTime = DateTime.Now.AddSeconds(this.expireSecond);
        }

        /// <summary>
        /// 清除所有信息项
        /// </summary>
        public void Clear()
        {
            this.SessionObject.Clear();
            this.expireTime = DateTime.Now.AddSeconds(this.expireSecond);
        }

        /// <summary>
        /// 获得信息项
        /// </summary>
        /// <param name="key">键值</param>
        /// <returns>object 对象 null 无值</returns>
        public object Get(string key)
        {
            object returnObj;
            if (this.SessionObject.ContainsKey(key))
            {
                returnObj = this.SessionObject[key];
            }
            else
            {
                returnObj = null;
            }

            this.expireTime = DateTime.Now.AddSeconds(this.expireSecond);

            return returnObj;
        }
    }
}