﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Query.cs
//
//  功能描述：  查询类
//
//  作者(Author):		段玉超
//
//  日期(Create Date):		2013.11.22
//
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace uni2uni.com.Framework.Data
{

   
    public abstract class Query
    {
        private QueryName _name;
        private IList<Criterion> _criteria;

        private IList<Query> _subQueries;
        private List<OrderByClause> _orderByClauses;

        public Query()
            : this(QueryName.Dynamic, new List<Criterion>())
        { }

        public Query(QueryName name, IList<Criterion> criteria)
        {
            _name = name;
            _criteria = criteria;
            _subQueries = new List<Query>();
           // QueryOperator = Data.QueryOperator.And;
        }

        public QueryName Name
        {
            get { return _name; }
        }

        /// <summary>
        /// 判断该查询是否已经动态生成或与Repository中某个预先建立的查询相关
        /// </summary>
        /// <returns></returns>
        public bool IsNamedQuery()
        {
            return Name != QueryName.Dynamic;
        }

        public void AddSubQuery(Query subQuery)
        {
            if (subQuery != null)
                this._subQueries.Add(subQuery);
        }

        public IEnumerable<Criterion> Criteria
        {
            get { return _criteria; }
        }

        public QueryOperator QueryOperator { get; set; }

        public IEnumerable<OrderByClause> OrderByClauses
        {
            get
            {
                return _orderByClauses ?? new List<OrderByClause>();
            }
        }

        public IEnumerable<Query> SubQueries
        {
            get { return _subQueries; }
        }



        public void Add(Criterion criterion)
        {
            if (!IsNamedQuery())//　动态查询
                _criteria.Add(criterion);
            else
                throw new ApplicationException("You cannot add additional criteria to named queries");
        }

        public void Add<T>(Expression<Func<T, object>> expression, Object value, CriteriaOperator criteriaOperator)
        {
            Add(Criterion.Create<T>(expression, value, criteriaOperator));
            }

        public void AddOrderBy(OrderByClause orderBy)
        {
            if (_orderByClauses == null)
                _orderByClauses = new List<OrderByClause>();
            _orderByClauses.Add(orderBy);
        }
       
    }

    public class Query<T> : Query
    {
        IList<Query> SubQuerys { get; set; }
    }

    
    /// <summary>
    /// 确定如何各个Criterion进行评估
    /// </summary>
    public enum QueryOperator
    {
        And,
        Or
    }

    public enum QueryName
    {
        Dynamic = 0,//动态创建
        RetrieveOrdersUsingAComplexQuery = 1//使用已经创建好了的存储过程、视图、特别是查询比较复杂时使用存储过程
    }
   
    
}


