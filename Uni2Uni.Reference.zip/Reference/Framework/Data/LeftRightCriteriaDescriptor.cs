﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Test.cs
//
//  功能描述：  订单领域模型
//
//  作者(Author):		测试
//
//  日期(Create Date):		2013.5.29
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace uni2uni.com.Framework.Data
{
    public class LeftRightCriteriaDescriptor : ICriteriaDescriptor
    {
        private string _op;

        public LeftRightCriteriaDescriptor(string op)
        {
            _op = op;
        }

        public string GetCriteriaStr()
        {
            return _op;
        }

        public IEnumerable<System.Data.Common.DbParameter> GetParameters()
        {
            return new List<System.Data.Common.DbParameter>();
        }


        public bool CanclePreOperator
        {
            get { return true; }
        }
    }
}
