﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Test.cs
//
//  功能描述：  排序条件
//
//  作者(Author):		段玉超
//
//  日期(Create Date):		2013.11.22
//
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace uni2uni.com.Framework.Data
{
    /// <summary>
    /// 表示查询的排序属性
    /// </summary>
    public class OrderByClause
    {
        public string PropertyName { get; set; }
        public bool Desc { get; set; }
    }
}
