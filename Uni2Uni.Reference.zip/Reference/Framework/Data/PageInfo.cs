﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace uni2uni.com.Framework.Data
{
    /// <summary>
    /// 分页信息帮助构造Sql语句
    /// </summary>
    public class PageInfo
    {
        
        private int pageSize;

        private int currentPageIndex;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="pageSize">每一个的数量</param>
        /// <param name="currentPageIndex">当前页码</param>
        public PageInfo(int pageSize, int currentPageIndex)
        {
            if (pageSize <= 0)
            {
                throw new ArgumentException("参数无效，必须为大于0的正整数", "pageSize");
            }
            if (currentPageIndex < 0)
            {
                throw new ArgumentException("参数无效，必须为大于0的正整数", "currentPageIndex");
            }
            this.pageSize = pageSize;
            this.currentPageIndex = currentPageIndex;
        }

        /// <summary>
        /// 根据页数据容量 和当前页计算的开始偏移量
        /// </summary>
        public int OffsetStart
        {
            get
            {
                return currentPageIndex == 1 ? 0 : (currentPageIndex -1)* (pageSize) + 1;
            }
        }
        /// <summary>
        /// 根据页数据容量 和当前页计算的结束偏移量
        /// </summary>
        public int OffsetEnd
        {
            get
            {
                return OffsetStart + pageSize;
            }
        }

    }

}
