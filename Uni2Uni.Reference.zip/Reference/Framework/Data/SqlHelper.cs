using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Reflection;
using uni2uni.com.Framework.Common;

namespace uni2uni.com.Framework.Data
{
    /// <summary>
    /// sql ƴ�Ӵ�������DbHelper���ʹ��
    /// </summary>
    public class SqlHelper
    {
        #region Sql process
        /// <summary>
        /// sql����ƴ��
        /// </summary>
        /// <param name="TableName">database table name</param>
        /// <param name="listDataParameter">Parameters</param>
        /// <returns>sql string</returns>
        public static string GetInsert(string TableName, IList<DbParameter> listDataParameter)
        {
            string paramList = string.Empty;
            if (listDataParameter != null)
            {
                IEnumerator<DbParameter> it = listDataParameter.GetEnumerator();
                while (it.MoveNext())
                {
                    GetParams(ref paramList, (DbParameter)it.Current);
                }
            }
            return string.Format(SqlExecute.Insert, TableName, paramList.Replace("@", ""), paramList);
        }

        /// <summary>
        /// sql����ƴ��(ע��,ǰ����ParamInfo�е�Condition������=,��������������ֵ)
        /// </summary>
        /// <param name="TableName">database table name</param>
        /// <param name="listDataParameter">Parameters</param>
        /// <param name="ListParamInfo">ParamInfos</param>
        /// <returns>sql string</returns>
        public static string GetUpdate(string TableName, IList<DbParameter> listDataParameter, IList<ParamInfo> ListParamInfo)
        {
            return GetSqlStr(SqlEventType.Update, TableName, listDataParameter, ListParamInfo);
        }

        /// <summary>
        /// sqlɾ��ƴ��
        /// </summary>
        /// <param name="TableName">database table name</param>
        /// <param name="listDataParameter">Parameters</param>
        /// <param name="ListParamInfo">ParamInfos</param>
        /// <returns>sql string</returns>
        public static string GetDelete(string TableName, IList<DbParameter> listDataParameter, IList<ParamInfo> ListParamInfo)
        {
            return GetSqlStr(SqlEventType.Delete, TableName, listDataParameter, ListParamInfo);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sqlEventType">sql event type</param>
        /// <param name="TableName">database table name</param>
        /// <param name="listDataParameter">Parameters</param>
        /// <param name="ListParamInfo">ParamInfos</param>
        /// <returns>sql string</returns>
        /// <returns></returns>
        private static string GetSqlStr(SqlEventType sqlEventType, string TableName, IList<DbParameter> listDataParameter, IList<ParamInfo> ListParamInfo)
        {
            string paramList = string.Empty;
            string BackParamList = string.Empty;
            if (listDataParameter != null)
            {
                for (int i = 0; i < listDataParameter.Count; i++)
                {
                    for (int y = 0; y < ListParamInfo.Count; y++)
                    {
                        if (("@" + ListParamInfo[y].ParamName) == listDataParameter[i].ParameterName)
                        {
                            GetParams(ref paramList, ref BackParamList, SqlEventType.Delete, listDataParameter[i], ListParamInfo[y]);
                            break;
                        }
                    }
                }
            }
            CleanOutStr(ref paramList);

            string SqlStr = string.Empty;
            if (sqlEventType == SqlEventType.Update)
            {
                SqlStr = string.Format(SqlExecute.Update, TableName, paramList, BackParamList);

            }
            else if (sqlEventType == SqlEventType.Delete)
            {
                SqlStr = string.Format(SqlExecute.Delete, TableName, BackParamList);
            }
            return SqlStr;
        }
        #endregion

        #region GetParams
        private static void GetParams(ref string paramList, DbParameter dbparameter)
        {
            string BackParamList = string.Empty;
            GetParams(ref paramList, ref BackParamList, SqlEventType.Insert, dbparameter, null);
        }

        private static void GetParams(ref string paramList, DbParameter dbparameter, ParamInfo paramInfo)
        {
            string BackParamList = string.Empty;
            GetParams(ref paramList, ref BackParamList, SqlEventType.Delete, dbparameter, paramInfo);
        }

        private static void GetParams(ref string paramList, ref string BackParamList, SqlEventType sqlEventType, DbParameter dbparameter, ParamInfo paramInfo)
        {
            if (dbparameter == null) throw new NullReferenceException();
            if (!string.IsNullOrEmpty(paramList)) paramList += ",";
            if (!string.IsNullOrEmpty(BackParamList)) BackParamList += ",";
            switch (sqlEventType)
            {
                case SqlEventType.Insert:
                    paramList += dbparameter.ParameterName;
                    break;
                case SqlEventType.Update:
                    if (paramInfo.Location == LocationType.Front)
                    {
                        paramList += paramInfo.ParamName + " " + paramInfo.Condition + " " + dbparameter.ParameterName;
                    }
                    else if (paramInfo.Location == LocationType.Back)
                    {
                        BackParamList += paramInfo.ParamName + " " + paramInfo.Condition + " " + dbparameter.ParameterName;
                    }
                    break;
                case SqlEventType.Delete:
                    if (paramInfo.Location == LocationType.Front)
                    {
                        paramList += paramInfo.ParamName + " " + paramInfo.Condition + " " + dbparameter.ParameterName;
                    }
                    else if (paramInfo.Location == LocationType.Back)
                    {
                        BackParamList += paramInfo.ParamName + " " + paramInfo.Condition + " " + dbparameter.ParameterName;
                    }
                    break;
                default:
                    break;
            }
        }
        #endregion

        #region other method
        private static void CleanOutStr(ref string paramList)
        {
            if (!string.IsNullOrEmpty(paramList))
            {
                if (paramList.LastIndexOf(',') != -1) paramList = paramList.TrimEnd(',');
            }
        }
        #endregion

        #region ����ʵ��õ�SQL���
        /// <summary>
        /// ����ʵ��õ�SQL���
        /// </summary>
        /// <param name="tableName">����</param>
        /// <param name="entity">ʵ��</param>
        /// <returns>�����ַ�����Ϊ�ձ�ʾʧ��</returns>
        public static string GetInsertSqlByEntity(string tableName, object entity, DbHelper dbHelper, out  IList<DbParameter> listDataParameter)
        {
            //listDataParameter = null;
            string sqlString = string.Empty;
            listDataParameter = new List<DbParameter>();
            if (entity != null)
            {
                Type t = entity.GetType();
                PropertyInfo[] ps = ReflectHelper.GetPropertys(t);
                if (ps != null && ps.Length > 0)
                {
                    
                    foreach (PropertyInfo property in ps)
                    {
                        System.Data.DbType dbtype = Common.TypeParse.SystemTypeToDbType(property.PropertyType);
                        object obj = property.GetValue(entity, null);
                        dbHelper.AddParameter(listDataParameter, "@" + property.Name, dbtype,Convert.ChangeType(obj, property.PropertyType));            
                    }
                    sqlString = GetInsert(tableName, listDataParameter);
                }
                
            }
            return sqlString;
        }
        #endregion


        public static string GetUpdateSqlByEntity(string tableName,object entity,DbHelper dbHelper,out  IList<DbParameter> listDataParameter)
        {
            string sqlString = string.Empty;
            listDataParameter = new List<DbParameter>();
            if (entity != null)
            {
                Type t = entity.GetType();
                PropertyInfo[] ps = ReflectHelper.GetPropertys(t);
                if (ps != null && ps.Length > 0)
                {
                    sqlString="update "+tableName+" set ";
                    foreach (PropertyInfo property in ps)
                    {
                        sqlString += property.Name+"=@"+property.Name+",";
                        System.Data.DbType dbtype = Common.TypeParse.SystemTypeToDbType(property.PropertyType);
                        object obj = property.GetValue(entity, null);
                        dbHelper.AddParameter(listDataParameter, "@" + property.Name, dbtype,Convert.ChangeType(obj, property.PropertyType));            
                    }
                    sqlString = sqlString.Substring(0, sqlString.Length - 1);
                }
                
            }
            return sqlString;
        }
        /// <summary>
        /// ���ݴ���Ĳ������SQL���
        /// </summary>
        /// <param name="sqlString"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public static string GetSqlByParameter(string sqlString,IList<DbParameter> parameters)
        {
            string retString=sqlString;
            if (parameters == null || parameters.Count == 0) return sqlString;
            foreach (DbParameter parameter in parameters)
            {
                retString = retString.Replace(parameter.ParameterName, ParameterValueToString(parameter));
            }
            return retString;
        }

        /// <summary>
        /// ������ֵת��STRING
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        public static string ParameterValueToString(DbParameter parameter)
        {
            string value = "";
            switch (parameter.DbType)
            {
                case System.Data.DbType.AnsiString:
                case System.Data.DbType.AnsiStringFixedLength:
                case System.Data.DbType.String:
                case System.Data.DbType.StringFixedLength:
                    value = "'" + FilterSqlValue(parameter.Value.ToString()) + "'";
                    break;
                case System.Data.DbType.Guid:
                    value = "'" + parameter.Value.ToString() + "'";
                    break;
                case System.Data.DbType.Date:
                    value = "'" + Convert.ToDateTime(parameter.Value).ToString("yyyy-MM-dd") +"'";
                    break;
                case System.Data.DbType.DateTime:
                case System.Data.DbType.DateTime2:
                    value = "'" + Convert.ToDateTime(parameter.Value).ToString("yyyy-MM-dd HH:mm:ss") +"'";
                    break;
                case System.Data.DbType.Time:
                    value = "'" + Convert.ToDateTime(parameter.Value).ToString("HH:mm:ss") +"'";
                    break;
                case System.Data.DbType.UInt16:
                case System.Data.DbType.UInt32:
                case System.Data.DbType.UInt64:
                case System.Data.DbType.VarNumeric:
                case System.Data.DbType.Int16:
                case System.Data.DbType.Int32:
                case System.Data.DbType.Int64:
                case System.Data.DbType.Decimal:
                case System.Data.DbType.Double:
                case System.Data.DbType.Currency:
                case System.Data.DbType.Byte:
                case System.Data.DbType.Single:
                case System.Data.DbType.SByte:
                    value = parameter.Value.ToString();
                    break;
                default:
                    value = "'" + parameter.Value.ToString() + "'";
                    break;
            }
            return value;
        }

        /// <summary>
        /// ����SQLֵ�е������ַ�
        /// </summary>
        /// <param name="orgValue"></param>
        /// <returns></returns>
        public static string FilterSqlValue(string orgValue)
        {
            string retString = orgValue.Replace("'", "''");
            return retString;
        }


        //��ҳ���Format
        public const string SQL_PAGE_FORMAT = @"WITH t AS (SELECT ROW_NUMBER() OVER(ORDER BY {0} --@FdOrder
        ) AS row_number, * FROM ({1}--@QueryStr 
        ) as a  {2}--@strwhere 
        ) SELECT * from t WHERE row_number BETWEEN {3}--@begin 
         and {4}--@end";

        public static string BuildPageSqlStatement(string selSqlStatement, string whereCondition, string strOrderby, int pageSize, int pageIndex)
        {
            PageInfo pInfo = new PageInfo(pageSize, pageIndex);
            string sqlStatement = string.Format(SqlHelper.SQL_PAGE_FORMAT,
                                       strOrderby,
                                       selSqlStatement,
                                       "",
                                       pInfo.OffsetStart.ToString(),
                                       pInfo.OffsetEnd.ToString()
                                       );
            return sqlStatement;
        }
    }
}
