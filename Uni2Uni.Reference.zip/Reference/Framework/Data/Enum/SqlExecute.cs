using System;
using System.Collections.Generic;
using System.Text;

namespace uni2uni.com.Framework.Data
{
    #region SqlExecute
    /// <summary>
    /// sql execute sentence
    /// </summary>
    public class SqlExecute
    {
        /// <summary>
        /// INSERT {0} ({1}) VALUES ({2})
        /// </summary>
        public static string Insert = " INSERT {0} ({1}) VALUES ({2}) ";
        /// <summary>
        /// UPDATE {0} SET {1} WHERE {2}
        /// </summary>
        public static string Update = " UPDATE {0} SET {1} WHERE {2} ";
        /// <summary>
        /// DELETE {0} WHERE {1}
        /// </summary>
        public static string Delete = " DELETE FROM {0} WHERE {1} ";
    }
    #endregion 
}
