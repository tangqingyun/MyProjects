using System;
using System.Collections.Generic;
using System.Text;

namespace uni2uni.com.Framework.Data
{
    #region SqlEventType
    /// <summary>
    /// sql event type
    /// </summary>
    public enum SqlEventType
    {
        /// <summary>
        /// insert
        /// </summary>
        Insert = 0,
        /// <summary>
        /// update
        /// </summary>
        Update,
        /// <summary>
        /// delete
        /// </summary>
        Delete
    }
    #endregion 
}
