using System;
using System.Collections.Generic;
using System.Text;

namespace uni2uni.com.Framework.Data
{
    #region LocationType
    /// <summary>
    /// Location type sql sentence
    /// </summary>
    public enum LocationType
    {
        /// <summary>
        ///  null
        /// </summary>
        Null = 0,
        /// <summary>
        /// front
        /// </summary>
        Front,
        /// <summary>
        /// back
        /// </summary>
        Back
    }
    #endregion
}
