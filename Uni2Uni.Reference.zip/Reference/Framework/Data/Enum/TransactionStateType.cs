using System;
using System.Collections.Generic;
using System.Text;

namespace uni2uni.com.Framework.Data
{
    #region TransactionStateType
    /// <summary>
    /// TransactionStateType
    /// </summary>
    public enum TransactionStateType
    {
        /// <summary>
        /// Open Transaction
        /// </summary>
        Open = 0,
        /// <summary>
        /// Close Transaction
        /// </summary>
        Close
    }
    #endregion
}
