using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Configuration;
using System.Data.Common;
using System.Reflection;
using uni2uni.com.Framework.Common;
using System.Collections.Specialized;

namespace uni2uni.com.Framework.Data
{
    #region DbHelper
    public class DbHelper
    {
        #region Member variables

        private DbTransaction trans;
        DataSet dataSet = new DataSet();
        private DbProviderFactory dbProviderFactory;

        private string connectionString;
        /// <summary>
        /// sql connection str
        /// </summary>
        public string ConnectionString
        {
            get { return connectionString; }
            set { connectionString = value; }
        }

        private string sqlUpdateMethod;

        public string SqlUpdateMethod
        {
            get
            {
                if (string.IsNullOrEmpty(sqlUpdateMethod)) sqlUpdateMethod = "GetRealSqlString";
                return sqlUpdateMethod;
            }
            set { sqlUpdateMethod = value; }
        }

        #endregion

        #region Constructor
        public DbHelper(string connectionName)
            : this(connectionName, System.Data.SqlClient.SqlClientFactory.Instance)
        {

        }

        public DbHelper(string connectionName, DbProviderFactory dbProviderFactory)
        {
            string ReturnErrorMsg = string.Empty;
            //ѭ���ڵ����Ƿ���ڸ��������ƣ���� �����ڣ�ȡĬ��ֵ
            if (ConfigurationManager.ConnectionStrings.Count > 0)
            {
                if (string.IsNullOrEmpty(connectionName)) connectionName = "Default";
                //���ݴ���������
                ConnectionStringSettings connStrSettings = ConfigurationManager.ConnectionStrings[connectionName];
                if (connStrSettings != null)
                {
                    this.dbProviderFactory = dbProviderFactory;

                    this.connectionString = connStrSettings.ConnectionString.ToString();

                    this.GetRealSqlStringer = ReflectHelper.GetDelegateMethod(SqlUpdateMethod, typeof(GetRealSqlString)) as GetRealSqlString;
                }
                else
                {
                    ReturnErrorMsg = "����web.config�ļ���������Ϊ��" + connectionName + "�������ݿ����Ӵ�";
                }
            }
            else
            {
                ReturnErrorMsg = "����web.config�ļ����������ݿ�����";
            }
            if (ReturnErrorMsg == null) throw new Exception(ReturnErrorMsg);
            /*this.dbProviderFactory = dbProviderFactory;
            this.connectionString = "server=192.168.1.201;database=Uni2uni_Manage;uid=sa;pwd=1234";*/
        }

        #endregion

        #region Public Method

        /// <summary>
        /// �ж����ݿ������Ƿ�ɹ�
        /// </summary>
        /// <returns></returns>
        public bool IsConnectionDB()
        {
            bool connState = true;

            DbConnection dc = dbProviderFactory.CreateConnection();
            dc.ConnectionString = connectionString;

            for (int i = 0; i < 5; i++)
            {
                try
                {
                    dc.Open();
                    if (dc.State.ToString() == "Open")
                    {
                        connState = true;
                        dc.Close();

                        break;
                    }
                }
                catch
                {
                    connState = false;

                    System.Threading.Thread.Sleep(2);
                }
            }

            return connState;
        }

        /// <summary>
        /// GetResult
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dbCommand"></param>
        /// <returns></returns>
        public delegate T GetResult<T>(DbCommand dbCommand);

        /// <summary>
        /// GetResultList
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dbCommand"></param>
        /// <returns></returns>
        public delegate IList<T> GetResultList<T>(DbCommand dbCommand);

        public delegate string GetRealSqlString(string initialSql);
        public GetRealSqlString GetRealSqlStringer;

        #region Execute Result
        /// <summary>
        /// get dataReader data
        /// </summary>
        /// <typeparam name="T">T t</typeparam>
        /// <param name="dbCommand">DbCommand</param>
        /// <returns>IList</returns>
        public IList<T> GetDataReader<T>(DbCommand dbCommand) where T : new()
        {
            IList<T> iList = new List<T>();
            if (dbCommand != null)
            {
                using (IDataReader dr = dbCommand.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        iList.Add(ReflectHelper.PopulateChangeFromIDataReader<T>(dr));
                    }
                }
            }
            return iList;
        }

        /// <summary>
        /// get single dataReader data
        /// </summary>
        /// <typeparam name="T">T t</typeparam>
        /// <param name="dbCommand">DbCommand</param>
        /// <returns>T t</returns>
        public T GetSingleDataReader<T>(DbCommand dbCommand) where T : new()
        {
            T t = new T();
            if (dbCommand != null)
            {
                using (IDataReader dr = dbCommand.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        t = ReflectHelper.PopulateChangeFromIDataReader<T>(dr);
                    }
                }
            }
            return t;
        }

        /// <summary>
        /// GetScalar
        /// </summary>
        /// <param name="dbCommand"></param>
        /// <returns></returns>
        public object GetScalar(DbCommand dbCommand)
        {
            return (dbCommand != null) ? dbCommand.ExecuteScalar() : null;
        }

        /// <summary>
        /// GetNonQuery
        /// </summary>
        /// <param name="dbCommand"></param>
        /// <returns></returns>
        public int GetNonQuery(DbCommand dbCommand)
        {
            return (dbCommand != null) ? dbCommand.ExecuteNonQuery() : 0;

        }

        public void ExecuteNonQuery(string sqlStatement, CommandType comType, params DbParameter[] parameters)
        {
            using (DbConnection dbConnection = this.CreateConnection())
            {
                dbConnection.Open();
                using (DbCommand dbCommand = GetDbCommand(dbConnection, sqlStatement, comType))
                {
                    dbCommand.Parameters.AddRange(parameters);
                    dbCommand.ExecuteNonQuery();
                }
                dbConnection.Close();
            }
        }

        /// <summary>
        /// GetBool
        /// </summary>
        /// <param name="dbCommand"></param>
        /// <returns></returns>
        public bool GetExecuteBool(DbCommand dbCommand)
        {
            return (GetNonQuery(dbCommand) > 0) ? true : false;
        }

        /// <summary>
        /// GetValueConvertBool
        /// </summary>
        /// <param name="dbCommand"></param>
        /// <returns></returns>
        public bool GetValueConvertBool(DbCommand dbCommand)
        {
            int ReturnIntValue = 0;
            Int32.TryParse(GetScalar(dbCommand).ToString(), out ReturnIntValue);
            return (ReturnIntValue != 0) ? true : false;
        }

        /// <summary>
        /// GetDataSet
        /// </summary>
        /// <param name="dbCommand"></param>
        /// <returns></returns>
        public DataSet GetDataSet(DbCommand dbCommand)
        {
            dataSet = new DataSet();
            if (dbCommand != null)
            {
                using (DbDataAdapter adapter = this.dbProviderFactory.CreateDataAdapter())
                {
                    ((IDbDataAdapter)adapter).SelectCommand = dbCommand;
                    adapter.Fill(dataSet);
                }
            }
            return dataSet;
        }
        #endregion

        #region Common Execute Method

        #endregion

        #region Public Execute Method

        public T GetData<T>(string SqlStr, CommandType commandType, GetResult<T> getResult) where T : new()
        {
            IList<DbParameter> ListDataParameter = null;
            return GetData<T>(SqlStr, commandType, getResult, ListDataParameter);
        }

        public T GetData<T>(string SqlStr, CommandType commandType, GetResult<T> getResult, TransactionStateType transactionStateType) where T : new()
        {
            IList<DbParameter> ListDataParameter = null;
            return GetData<T>(SqlStr, commandType, getResult, ListDataParameter, transactionStateType);
        }

        public T GetData<T>(string SqlStr, CommandType commandType, GetResult<T> getResult, IList<DbParameter> ListDataParameter) where T : new()
        {
            return GetData<T>(SqlStr, commandType, getResult, ListDataParameter, TransactionStateType.Close);
        }

        public T GetData<T>(string SqlStr, CommandType commandType, GetResult<T> getResult, IList<DbParameter> ListDataParameter, TransactionStateType transactionStateType) where T : new()
        {
            trans = null;
            T t = new T();
            using (DbConnection dbConnection = this.CreateConnection())
            {
                dbConnection.Open();
                DbCommand dbCommand = GetDbCommand(dbConnection, SqlStr, commandType);

                DbExecute<T>(getResult, ListDataParameter, transactionStateType, ref trans, ref t, dbConnection, dbCommand);

                dbConnection.Close();
            }
            return t;
        }

        public T GetData<T>(string SqlStr, CommandType commandType, GetResult<T> getResult, IList<IList<DbParameter>> ListDataParameter) where T : new()
        {
            return GetData<T>(SqlStr, commandType, getResult, ListDataParameter, TransactionStateType.Close);
        }

        public T GetData<T>(string SqlStr, CommandType commandType, GetResult<T> getResult, IList<IList<DbParameter>> ListDataParameter, TransactionStateType transactionStateType) where T : new()
        {
            trans = null;
            T t = new T();
            using (DbConnection dbConnection = this.CreateConnection())
            {
                dbConnection.Open();
                DbCommand dbCommand = GetDbCommand(dbConnection, SqlStr, commandType);

                DbExecute<T>(getResult, ListDataParameter, transactionStateType, ref trans, ref t, dbConnection, dbCommand);

                dbConnection.Close();
            }
            return t;
        }


        public T GetData<T>(IList<string> SqlStrList, CommandType commandType, GetResult<T> getResult, IList<IList<DbParameter>> ListDataParameter, TransactionStateType transactionStateType) where T : new()
        {
            trans = null;
            T t = new T();
            using (DbConnection dbConnection = this.CreateConnection())
            {
                dbConnection.Open();
                DbCommand dbCommand = null;
                dbCommand = GetDbCommand(dbConnection, null, commandType);

                DbExecute<T>(getResult, ListDataParameter, transactionStateType, ref trans, ref t, dbConnection, dbCommand, SqlStrList);

                dbConnection.Close();
            }
            return t;
        }

        public IList<T> GetDataList<T>(string SqlStr, CommandType commandType, GetResultList<T> getResultList)
        {
            return GetDataList<T>(SqlStr, commandType, getResultList, null);
        }

        public IList<T> GetDataList<T>(string SqlStr, CommandType commandType, GetResultList<T> getResultList, TransactionStateType transactionStateType)
        {
            return GetDataList<T>(SqlStr, commandType, getResultList, null, transactionStateType);
        }

        public IList<T> GetDataList<T>(string SqlStr, CommandType commandType, GetResultList<T> getResultList, IList<DbParameter> ListDataParameter)
        {
            return GetDataList<T>(SqlStr, commandType, getResultList, ListDataParameter, TransactionStateType.Close);
        }

        public IList<T> GetDataList<T>(string SqlStr, CommandType commandType, GetResultList<T> getResultList, IList<DbParameter> ListDataParameter, TransactionStateType transactionStateType)
        {
            trans = null;
            IList<T> iList = new List<T>();
            using (DbConnection dbConnection = this.CreateConnection())
            {
                dbConnection.Open();

                DbCommand dbCommand = GetDbCommand(dbConnection, SqlStr, commandType);

                SetParameter(ListDataParameter, dbCommand);

                DbExecute<T>(getResultList, transactionStateType, ref trans, ref iList, dbConnection, dbCommand);

                dbConnection.Close();
            }
            return iList;
        }

        #endregion

        private static void DbExecute<T>(GetResult<T> getResult, IList<DbParameter> ListDataParameter, TransactionStateType transactionStateType, ref DbTransaction trans, ref T t, DbConnection dbConnection, DbCommand dbCommand)
        {
            IList<IList<DbParameter>> TempListDbParm = new List<IList<DbParameter>>();
            TempListDbParm.Add(ListDataParameter);
            DbExecute<T>(getResult, TempListDbParm, transactionStateType, ref trans, ref t, dbConnection, dbCommand);
        }

        private static void DbExecute<T>(GetResult<T> getResult, IList<IList<DbParameter>> ListDataParameter, TransactionStateType transactionStateType, ref DbTransaction trans, ref T t, DbConnection dbConnection, DbCommand dbCommand, IList<string> SqlStrList)
        {
            bool tranBoolValue = false;
            try
            {
                if (transactionStateType == TransactionStateType.Open) tranBoolValue = true;
                if (tranBoolValue) trans = dbConnection.BeginTransaction();
                if (tranBoolValue) dbCommand.Transaction = trans;

                if (SqlStrList != null && ListDataParameter != null && SqlStrList.Count == ListDataParameter.Count)
                {
                    DbCommand SingleDbCommand = null;
                    for (int i = 0; i < SqlStrList.Count; i++)
                    {
                        SingleDbCommand = dbCommand;
                        SingleDbCommand.CommandText = SqlStrList[i];
                        SingleDbCommand.Parameters.Clear();

                        if (ListDataParameter[i] != null)
                        {
                            for (int j = 0; j < ListDataParameter[i].Count; j++)
                            {
                                SingleDbCommand.Parameters.Add(ListDataParameter[i][j]);
                            }
                        }
                        if (getResult != null) t = getResult(SingleDbCommand);

                    }
                }

                if (tranBoolValue) trans.Commit();
            }
            catch (Exception ex)
            {
                //throw ex;
                if (tranBoolValue) trans.Rollback();
                t = default(T);
            }
        }

        private static void DbExecute<T>(GetResult<T> getResult, IList<IList<DbParameter>> ListDataParameter, TransactionStateType transactionStateType, ref DbTransaction trans, ref T t, DbConnection dbConnection, DbCommand dbCommand)
        {
            bool tranBoolValue = false;
            try
            {
                if (transactionStateType == TransactionStateType.Open) tranBoolValue = true;
                if (tranBoolValue) trans = dbConnection.BeginTransaction();
                if (tranBoolValue) dbCommand.Transaction = trans;

                if (ListDataParameter != null)
                {
                    DbCommand SingleDbCommand = null;
                    for (int i = 0; i < ListDataParameter.Count; i++)
                    {
                        SingleDbCommand = dbCommand;
                        SingleDbCommand.Parameters.Clear();
                        if (ListDataParameter[i] != null)
                        {
                            for (int j = 0; j < ListDataParameter[i].Count; j++)
                            {
                                DbParameter p = (DbParameter)((ICloneable)ListDataParameter[i][j]).Clone();
                                SingleDbCommand.Parameters.Add(p);
                                //SingleDbCommand.Parameters.Add(ListDataParameter[i][j]);
                            }
                        }
                        if (getResult != null) t = getResult(SingleDbCommand);
                    }
                }

                if (tranBoolValue) trans.Commit();
            }
            catch (Exception ex)
            {
                //throw ex;
                if (tranBoolValue) trans.Rollback();
                t = default(T);
            }
        }

        #region DbExecute<T>
        private static void DbExecute<T>(GetResultList<T> getResultList, TransactionStateType transactionStateType, ref DbTransaction trans, ref IList<T> iList, DbConnection dbConnection, DbCommand dbCommand)
        {
            bool tranBoolValue = false;
            try
            {
                if (transactionStateType == TransactionStateType.Open) tranBoolValue = true;
                if (tranBoolValue) trans = dbConnection.BeginTransaction();
                if (tranBoolValue) dbCommand.Transaction = trans;

                if (getResultList != null) iList = getResultList(dbCommand);
                if (tranBoolValue) trans.Commit();
            }
            catch (Exception ex)
            {
                //throw ex;
                if (tranBoolValue) trans.Rollback();
            }
        }

        private void SetParameter(IList<DbParameter> ListDataParameter, DbCommand dbCommand)
        {
            if (ListDataParameter != null)
            {
                foreach (DbParameter dbParameter in ListDataParameter)
                {
                    //Rocky for DataPermission
                    if (this.GetRealSqlStringer != null && dbCommand.CommandType == CommandType.StoredProcedure && dbCommand.CommandText.ToLower().Equals("pagination") && dbParameter.ParameterName.ToLower().Equals("@querystr"))
                    {
                        dbParameter.Value = GetRealSqlStringer(dbParameter.Value.ToString());
                    }
                    dbCommand.Parameters.Add(dbParameter);
                }
            }

        }

        private DbCommand GetDbCommand(DbConnection dbConnection, string commandText, CommandType commandType)
        {
            DbCommand dbCommand = this.dbProviderFactory.CreateCommand();
            dbCommand.CommandType = commandType;
            if (this.GetRealSqlStringer != null) commandText = GetRealSqlStringer(commandText);
            dbCommand.CommandText = commandText;
            dbCommand.Connection = dbConnection;
            dbCommand.CommandTimeout = 0;
            return dbCommand;
        }
        #endregion

        #region Parameter

        #region AddParameter

        public void AddParameter(IList<DbParameter> ListDataParameter, string ParameterName, DbType dbType, object value)
        {
            AddParameter(ListDataParameter, null, ParameterName, null, LocationType.Null, dbType, value);
        }

        public void AddParameter(IList<DbParameter> ListDataParameter, IList<ParamInfo> ListParamInfo, string ParameterName, string condition, DbType dbType, object value)
        {
            AddParameter(ListDataParameter, null, ParameterName, condition, LocationType.Null, dbType, value);
        }

        public void AddParameter(IList<DbParameter> ListDataParameter, IList<ParamInfo> ListParamInfo, string ParameterName, string condition, LocationType location, DbType dbType, object value)
        {
            ListDataParameter.Add(CreateParameter(ParameterName, dbType, 0, ParameterDirection.Input, true, 0, 0, string.Empty, DataRowVersion.Default, value));
            if (ListParamInfo != null) ListParamInfo.Add(new ParamInfo(ParameterName.TrimStart('@'), condition, location));
        }
        #endregion

        protected DbParameter CreateParameter(string ParameterName, DbType dbType, int size, ParameterDirection direction, bool nullable, byte precision, byte scale, string sourceColumn, DataRowVersion sourceVersion, object value)
        {
            DbParameter param = this.dbProviderFactory.CreateParameter();
            ConfigureParameter(param, ParameterName, dbType, size, direction, nullable, precision, scale, sourceColumn, sourceVersion, value);
            return param;
        }

        public void ConfigureParameter(DbParameter param, string ParameterName, DbType dbType, int size, ParameterDirection direction, bool nullable, byte precision, byte scale, string sourceColumn, DataRowVersion sourceVersion, object value)
        {
            param.ParameterName = ParameterName;
            param.DbType = dbType;
            param.Size = size;
            param.Value = (value == null) ? DBNull.Value : value;
            param.Direction = direction;
            param.IsNullable = nullable;
            param.SourceColumn = sourceColumn;
            param.SourceVersion = sourceVersion;
        }
        #endregion

        #endregion

        #region
        /// <summary>
        /// <para>Creates a connection for this database.</para>
        /// </summary>
        /// <param name="connectionName"></param>
        /// <returns>
        /// <para>The <see cref="DbConnection"/> for this database.</para>
        /// </returns>
        /// <seealso cref="DbConnection"/>  
        public virtual DbConnection CreateConnection()
        {
            DbConnection newConnection = this.dbProviderFactory.CreateConnection();
            newConnection.ConnectionString = this.connectionString;

            return newConnection;
        }
        #endregion

        public virtual DbConnection CreateConnection(string strSql)
        {
            DbConnection newConnection = this.dbProviderFactory.CreateConnection();
            newConnection.ConnectionString = AutoConnectionString(strSql);

            return newConnection;
        }

        private string AutoConnectionString(string strSql)
        {
            string strConnection = string.Empty;
            char[] sp = new char[] { ' ', '(' };
            string[] elements = strSql.Split(sp, StringSplitOptions.RemoveEmptyEntries);
            switch (elements[0].ToLower())
            {
                case "select":
                    strConnection = ((NameValueCollection)ConfigurationManager.GetSection("DBConnection/Read"))[elements[2]];
                    break;
                case "update":
                case "delete":
                    strConnection = ((NameValueCollection)ConfigurationManager.GetSection("DBConnection/Write"))[elements[1]];
                    break;
                case "insert":
                    strConnection = ((NameValueCollection)ConfigurationManager.GetSection("DBConnection/Write"))[elements[2]];
                    break;
                default:
                    strConnection = this.connectionString;
                    break;
            }
            if (string.IsNullOrEmpty(strConnection))
                strConnection = this.connectionString;
            return strConnection;
        }

    }
    #endregion
}
