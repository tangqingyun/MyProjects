﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Test.cs
//
//  功能描述：  订单领域模型
//
//  作者(Author):		测试
//
//  日期(Create Date):		2013.11.25
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Text;

namespace uni2uni.com.Framework.Data
{
    public class BetweenAndCriteriaDescriptor:BinaryCriteriaDescriptor
    {
        public BetweenAndCriteriaDescriptor(Criterion criteria, string op, Func<string, string> mapPropertyName)
            : base(criteria, op, mapPropertyName)
        {
        }

        public override string GetCriteriaStr()
        {
            var ps = GetParameters();

            return string.Format(_operator, GetColmunName(), ps.First().ParameterName, ps.Last().ParameterName);
        }

        public override IEnumerable<System.Data.Common.DbParameter> GetParameters()
        {
            string paramName = GetParameterName();

             var vals = _criteria.Value as IEnumerable<Object>;
             if (null != vals)
             {
                 return new List<SqlParameter>()
                        {
                            new SqlParameter(paramName+"Start",vals.First()),
                             new SqlParameter(paramName+"End",vals.Last())
                        };
             }
             else
             {
                 throw new ApplicationException("Between... And.... 需要两个值");
             }
            
        }
    }
}
