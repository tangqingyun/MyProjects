﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Test.cs
//
//  功能描述：   快速创建Parameter
//
//  作者(Author):		测试
//
//  日期(Create Date):		2013.11.27

// ******************************************************************

using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace uni2uni.com.Framework.Data
{
    public class DbParameters<T> where T:class
    {
        IList<DbParameter> innerParameters;
        T entity;

        public DbParameters(T entity)
            : this(entity,new List<DbParameter>())
        {
           
        }

        public DbParameters(T entity,IList<DbParameter> parameters)
        {
            innerParameters = parameters ?? new List<DbParameter>();
            this.entity = entity;
        }

        public DbParameters<T> Add(DbParameter parameter)
        {
            innerParameters.Add(parameter);
            return this;
        }

        public DbParameters<T> Add(Expression<Func<T, Object>> lamada,bool isOutput=false)
        {
            string parameterName = PropertyNameHelper.ResolvePropertyName<T>(lamada);
            object value  = lamada.Compile()(entity);
            if (null == value)
                value = DBNull.Value;
            SqlParameter parameter = new SqlParameter("@" + parameterName, value);
            if (isOutput)
            {
                parameter.Direction = System.Data.ParameterDirection.Output;
            }
            innerParameters.Add(parameter);
            return this;
        }

        public DbParameters<T> AddRange(IEnumerable<DbParameter> parameters)
        {
            foreach (var p in parameters)
            {
                innerParameters.Add(p);
            }
            return this;
        }

        public IList<DbParameter> GetParameters()
        {
            return innerParameters;
        }
    }
}
