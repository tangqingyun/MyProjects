﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Test.cs
//
//  功能描述：  查询条件描述
//
//  作者(Author):		段玉超
//
//  日期(Create Date):		2013.11.25
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using System.Data.SqlClient;

namespace uni2uni.com.Framework.Data
{
    public interface ICriteriaDescriptor
    {
        string GetCriteriaStr();
        IEnumerable<DbParameter> GetParameters();

        bool CanclePreOperator { get; }
    }
}
