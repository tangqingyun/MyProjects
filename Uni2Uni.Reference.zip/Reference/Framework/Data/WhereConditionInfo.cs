﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Test.cs
//
//  功能描述：  订单领域模型
//
//  作者(Author):		测试
//
//  日期(Create Date):		2013.5.29
//
//  修改记录(Revision History):
//	R1:
//		修改作者:	张三
//		修改日期:	2013.5.29
//		修改理由:	由于某些原因对其中的一些功能进行相关
//				    修改。
//	R2:
//		修改作者:	张三
//		修改日期:	2013.5.29
//		修改理由:	由于某些原因对其中的一些功能进行相关
//				    修改。
//
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace uni2uni.com.Framework.Data
{
    public class WhereConditionInfo
    {
        private string _whereCondition;

        private string _orderbyClauses;

        private IList<DbParameter> _parameters;

        public WhereConditionInfo(string whereCondition, string oderbyClauses, IList<DbParameter> parameters)
        {
            _whereCondition = whereCondition;
            _parameters = parameters;
            _orderbyClauses = oderbyClauses;
        }

        public string WhereCondition
        {
            get
            {
                return _whereCondition;
            }
        }

        public IList<DbParameter> Parameters
        {
            get
            {
                return _parameters;
            }
        }

        public string Orderby
        {
            get
            {
                return _orderbyClauses;
            }
        }

    }
}
