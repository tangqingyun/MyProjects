﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Test.cs
//
//  功能描述：  订单领域模型
//
//  作者(Author):		适用于生成多个参数
//
//  日期(Create Date):		2013.11.29
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace uni2uni.com.Framework.Data
{
    public  class MultParamCriteriaDescriptor:BinaryCriteriaDescriptor
    {
        public MultParamCriteriaDescriptor(Criterion criteria, string op, Func<string, string> mapPropertyName)
            : base(criteria, op, mapPropertyName)
        {
        }

        public override string GetCriteriaStr()
        {
            var ps = GetParameters();
            StringBuilder sb = new StringBuilder();
            foreach (var p in ps)
            {
                sb.Append(p.ParameterName);
                sb.Append(",");
            }
            
            return string.Format(_operator, GetColmunName(), sb.ToString().Trim(','));
        }

        public override IEnumerable<System.Data.Common.DbParameter> GetParameters()
        {
          
            var vals = _criteria.Value as IEnumerable<Object>;
            if (vals == null || vals.Count() <= 0)
            {
                throw new ApplicationException("需要一个或多个参数值");
            }

            string paramName = GetParameterName();
            var paramsList = new List<SqlParameter>();
            var enumerator = vals.GetEnumerator();

            int index=0;
            while(enumerator.MoveNext()){
                paramsList.Add(new SqlParameter(string.Format("{0}_{1}", paramName, index++), enumerator.Current));
            }
            return paramsList;
        }
    }
}
