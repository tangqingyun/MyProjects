﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Test.cs
//
//  功能描述：  查询对象扩展类
//
//  作者(Author):		段玉超
//
//  日期(Create Date):		2013.11.25

// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace uni2uni.com.Framework.Data
{
    public static class QueryExt
    {
        /// <summary>
        /// =
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="query"></param>
        /// <param name="property"></param>
        /// <param name="value"></param>
        /// <param name="prefix"></param>
        /// <returns></returns>
        public static Query<T> SqlEqual<T>(this Query<T> query, Expression<Func<T, object>> property,Object value,string prefix="")
        {
            query.Add( Criterion.Create<T>(property,value, CriteriaOperator.Equal,prefix));
            return query;
        }

        /// <summary>
        /// <>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="query"></param>
        /// <param name="property"></param>
        /// <param name="value"></param>
        /// <param name="prefix"></param>
        /// <returns></returns>
        public static Query<T> NotApplicable<T>(this Query<T> query, Expression<Func<T, object>> property, Object value, string prefix = "")
        {
            query.Add(Criterion.Create<T>(property, value, CriteriaOperator.NotApplicable, prefix));
            return query;
        }

        public static Query<T> LessThan<T>(this Query<T> query, Expression<Func<T, object>> property, Object value, string prefix = "")
        {
            query.Add(Criterion.Create<T>(property, value, CriteriaOperator.LessThan, prefix));
            return query;
        }

        public static Query<T> LessThanOrEqual<T>(this Query<T> query, Expression<Func<T, object>> property, Object value, string prefix = "")
        {
            query.Add(Criterion.Create<T>(property, value, CriteriaOperator.LessThanOrEqual, prefix));
            return query;
        }


        public static Query<T> GreaterThan<T>(this Query<T> query, Expression<Func<T, object>> property, Object value, string prefix = "")
        {
            query.Add(Criterion.Create<T>(property, value, CriteriaOperator.GreaterThan, prefix));
            return query;
        }

        public static Query<T> GreaterThanEqual<T>(this Query<T> query, Expression<Func<T, object>> property, Object value, string prefix = "")
        {
            query.Add(Criterion.Create<T>(property, value, CriteriaOperator.GreaterThanEqual, prefix));
            return query;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="query"></param>
        /// <param name="property"></param>
        /// <param name="value">Like字符串 例如 "%abc%"</param>
        /// <param name="prefix"></param>
        /// <returns></returns>
        public static Query<T> Like<T>(this Query<T> query, Expression<Func<T, object>> property, string value, string prefix = "")
        {
            query.Add(Criterion.Create<T>(property, value, CriteriaOperator.Like, prefix));
            return query;
        }

        public static Query<T> BetweenAnd<T>(this Query<T> query, Expression<Func<T, object>> property, object value1, object value2, string prefix = "")
        {
            query.Add(Criterion.Create<T>(property, new object[]{value1,value2}, CriteriaOperator.BetweenAnd, prefix));
            return query;
        }

        public static Query<T> In<T>(this Query<T> query, Expression<Func<T, object>> property, object v1, object v2, string prefix = "")
        {
            return query.In(property, new object[] { v1, v2 }, prefix);
        }
        public static Query<T> In<T>(this Query<T> query, Expression<Func<T, object>> property, object v1, object v2, object v3, string prefix = "")
        {
            return query.In(property, new object[] { v1, v2, v3}, prefix);
           
        }
        public static Query<T> In<T>(this Query<T> query, Expression<Func<T, object>> property, object v1, object v2, object v3, object v4, string prefix = "")
        {
               return  query.In(property, new object[] { v1, v2, v3,v4 }, prefix);

        }

        public static Query<T> In<T>(this Query<T> query, Expression<Func<T, object>> property, object v1, object v2, object v3, object v4, object v5, string prefix = "")
        {
            return query.In(property, new object[] { v1, v2, v3, v4,v5 }, prefix);
        }

        public static Query<T> In<T>(this Query<T> query, Expression<Func<T, object>> property, object v1, object v2, object v3, object v4, object v5, object v6, string prefix = "")
        {
            return query.In(property, new object[] { v1, v2, v3, v4,v5,v6 }, prefix);
        }
        public static Query<T> In<T>(this Query<T> query, Expression<Func<T, object>> property, IEnumerable<Object> values, string prefix = "")
        {
            query.Add(Criterion.Create<T>(property, values, CriteriaOperator.In, prefix));
            return query;
        }
        public static Query<T> Orderby<T>(this Query<T> query, Expression<Func<T, object>> property, bool isDesc = false)
        {
            query.AddOrderBy(new OrderByClause() { PropertyName = PropertyNameHelper.ResolvePropertyName<T>(property), Desc = isDesc });
            return query;
        }

        public static Query<T> Orderby<T>(this Query<T> query, Expression<Func<T, object>> property, string methodFormat, bool isDesc = false)
        {
            query.AddOrderBy(new OrderByClause() { PropertyName = string.Format(methodFormat,PropertyNameHelper.ResolvePropertyName<T>(property)), Desc = isDesc });
            return query;
        }

        public static WhereConditionInfo Tranlsate(this Query query,Func<string,string> propertyMap=null)
        {
            var intepreter = new QueryInterpreter();
            return intepreter.GetWhereCriterias(query, propertyMap);
        }
    }
}
