﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Test.cs
//
//  功能描述：    查询条件
//
//  作者(Author):		段玉超
//
//  日期(Create Date):		2013.11.22
//
//
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace uni2uni.com.Framework.Data
{
    public class Criterion
    {
        private string _prefix;
        private string _propertyName;//实体属性
        private object _value;//进行比较的值
        private CriteriaOperator _criteriaOperator;//何种比较方式
        public Criterion(string propertyName, object value, CriteriaOperator criteriaOperator,string prefix="")
        {
            _propertyName = propertyName;
            _value = value;
            _criteriaOperator = criteriaOperator;
            _prefix = prefix;
        }

        /// <summary>
        /// 属性名
        /// </summary>
        public string PropertyName
        {
            get { return _propertyName; }
        }

        /// <summary>
        /// 值
        /// </summary>
        public object Value
        {
            get { return _value; }
        }

        /// <summary>
        /// 前缀
        /// </summary>
        public string Prefix
        {
            get { return _prefix; }
        }

        /// <summary>
        /// 条件操作符
        /// </summary>
        public CriteriaOperator criteriaOperator
        {
            get { return _criteriaOperator; }
        }
        /// <summary>
        /// 是否有前缀
        /// </summary>
        /// <returns></returns>
        public bool HasPrefix()
        {
            return !string.IsNullOrWhiteSpace(Prefix);
        }

        public bool IsOverideQueryOperator { get; set; }

        /// <summary>
        /// Lambda表达式树：创建一个过滤器
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="expression"></param>
        /// <param name="value"></param>
        /// <param name="criteriaOperator"></param>
        /// <returns></returns>
        public static Criterion Create<T>(Expression<Func<T, object>> expression, Object value, CriteriaOperator criteriaOperator,string prefix="")
        {
            string propertyName = PropertyNameHelper.ResolvePropertyName<T>(expression);
            Criterion myCriterion = new Criterion(propertyName, value, criteriaOperator);
            return myCriterion;
        }
    }
}
