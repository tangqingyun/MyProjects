﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Test.cs
//
//  功能描述：  查询解释器基类
//
//  作者(Author):		段玉超
//
//  日期(Create Date):		2013.11.22
//
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace uni2uni.com.Framework.Data
{
    public class QueryInterpreter
    {

        public WhereConditionInfo GetWhereCriterias(Query query,Func<string,string> propertyMap)
        {
            StringBuilder sqlBulider = new StringBuilder();
            List<DbParameter> ps = new List<DbParameter>();
            GetWhereCriterias(query, propertyMap, sqlBulider, ps);

            string orderBy = string.Empty;
            if (query.OrderByClauses != null)
            {
                orderBy = FindOrderBy(query.OrderByClauses, propertyMap);
            }

            return new WhereConditionInfo(sqlBulider.ToString(), orderBy, ps);
        }

        private void GetWhereCriterias(Query query, Func<string, string> propertyMap, StringBuilder sqlBulider, List<DbParameter> ps)
        {
            string queryOperator = FindSQLOperatorFor(query.QueryOperator);

            bool hasAnd = false;

            foreach (var c in query.Criteria)
            {
                if (hasAnd)
                {
                    sqlBulider.Append(queryOperator);
                }
                ICriteriaDescriptor criteriaDescriptor = GetCriteriaDescriptorFor(c, propertyMap);
                sqlBulider.Append(criteriaDescriptor.GetCriteriaStr());
                ps.AddRange(criteriaDescriptor.GetParameters());
                hasAnd = true;
            }


            foreach (var subQuery in query.SubQueries)
            {
                if (sqlBulider.Length > 0)
                {
                    sqlBulider.Append(" AND ");
                }
                sqlBulider.Append("(");
                GetWhereCriterias(subQuery, propertyMap, sqlBulider, ps);
                sqlBulider.Append(")");
            }
           
        }

        public string FindOrderBy(IEnumerable<OrderByClause> orderByClauses, Func<string, string> propertyMap)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var orderByClause in orderByClauses)
            {
                string orderC = orderByClause.Desc ? "DESC" : "ASC";
               
                sb.Append(string.Format("{0} {1}", orderByClause.PropertyName, orderC));
                sb.Append(",");
            }
            return sb.ToString().Trim(',');
        }

        public string FindSQLOperatorFor(QueryOperator queryOperator)
        {
            switch (queryOperator)
            {
                case QueryOperator.And:
                    return " AND ";
                case QueryOperator.Or:
                    return " OR ";
                default:
                    throw new ArgumentException("No operator defined.");
            }
        }

        public ICriteriaDescriptor GetCriteriaDescriptorFor(Criterion criteria,Func<string,string> propertyNameMap=null)
        {
            switch (criteria.criteriaOperator)
            {
                case CriteriaOperator.Equal:
                    return new BinaryCriteriaDescriptor(criteria, " = ", propertyNameMap);
                case CriteriaOperator.NotApplicable:
                    return new BinaryCriteriaDescriptor(criteria, " <> ", propertyNameMap);
                case CriteriaOperator.LessThan:
                    return new BinaryCriteriaDescriptor(criteria, " < ", propertyNameMap);
                case CriteriaOperator.LessThanOrEqual:
                    return new BinaryCriteriaDescriptor(criteria, " <= ", propertyNameMap);
                case CriteriaOperator.GreaterThan:
                    return new BinaryCriteriaDescriptor(criteria, " > ", propertyNameMap);
                case CriteriaOperator.GreaterThanEqual:
                    return new BinaryCriteriaDescriptor(criteria, " >= ", propertyNameMap);
                case CriteriaOperator.Like:
                    return new BinaryCriteriaDescriptor(criteria,  " LIKE ", propertyNameMap);;
                case CriteriaOperator.BetweenAnd:
                    return new BetweenAndCriteriaDescriptor(criteria, " {0} BETWEEN {1} AND {2} ", propertyNameMap);   // ;
                case CriteriaOperator.In :
                      return new MultParamCriteriaDescriptor(criteria, " {0} IN({1}) ", propertyNameMap);// " IN({0}) ";
                default:
                    throw new ArgumentException("No operator defined.");
            }
        }


    }
}
