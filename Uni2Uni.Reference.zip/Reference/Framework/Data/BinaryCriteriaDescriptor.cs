﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Test.cs
//
//  功能描述：  订单领域模型
//
//  作者(Author):		测试
//
//  日期(Create Date):		2013.5.29
//
//  修改记录(Revision History):
//	R1:
//		修改作者:	张三
//		修改日期:	2013.5.29
//		修改理由:	由于某些原因对其中的一些功能进行相关
//				    修改。
//	R2:
//		修改作者:	张三
//		修改日期:	2013.5.29
//		修改理由:	由于某些原因对其中的一些功能进行相关
//				    修改。
//
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using System.Data.SqlClient;

namespace uni2uni.com.Framework.Data
{
    public class BinaryCriteriaDescriptor:ICriteriaDescriptor
    {
        private const string Criterionformat = "{0} {1} {2}";

        protected Criterion _criteria;

        protected Func<string, string> _mapPropertyName;

        protected string _operator;

        public BinaryCriteriaDescriptor(Criterion criteria, string op, Func<string, string> mapPropertyName)
        {
            _criteria = criteria;
            _operator = op;
            _mapPropertyName = mapPropertyName;
        }

        public virtual string GetCriteriaStr()
        {
            return string.Format(Criterionformat, GetColmunName(), _operator, GetParameterName());
        }

        protected string GetColmunName()
        {
            string cName = _criteria.PropertyName;
            if (null != _mapPropertyName)
            {
                cName = _mapPropertyName(cName);
            }

            if (_criteria.HasPrefix())
            {
                cName = string.Format("{0}.{1}", _criteria.Prefix.Trim(), cName);
            }
            return cName;
        }

        protected virtual string GetParameterName()
        {
            
            return "@" + _criteria.PropertyName;
        }

        public virtual IEnumerable<DbParameter> GetParameters()
        {
            object vlaue = DBNull.Value;
            if (null != _criteria.Value)
            {
                vlaue = _criteria.Value;
            }
            return new SqlParameter[] { 
                new SqlParameter(GetParameterName(), vlaue)
            };
        }


        public bool CanclePreOperator
        {
            get  {return false; }
        }
    }
}
