﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Test.cs
//
//  功能描述：  订单领域模型
//
//  作者(Author):		测试
//
//  日期(Create Date):		2013.5.29
//
//  修改记录(Revision History):
//
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace uni2uni.com.Framework.Data
{
    public abstract class DalBase<T> where T : class ,new()
    {
        protected DbHelper _dbHelper;

        protected Func<string, string> mapProperty;

        public DalBase(DbHelper dbHelper)
        {
            _dbHelper = dbHelper;
            mapProperty = null;
            Init();
        }

        public virtual IEnumerable<T> FindBy(Query query)
        {
            var c = query.Tranlsate(mapProperty);
            StringBuilder sb = new StringBuilder(GetEntitySelSql());
            sb.Append(BuilderWhereStatement(c));
            if (!string.IsNullOrWhiteSpace(c.Orderby))
            {
                sb.Append(" ORDER　BY ")
                    .Append(c.Orderby);
            }
            return _dbHelper.GetDataList(sb.ToString(), CommandType.Text, _dbHelper.GetDataReader<T>, c.Parameters) ?? new List<T>();
        }

        public IEnumerable<T> FindBy(Query query, int pageSize, int pageIndex)
        {
            var c = query.Tranlsate(mapProperty);
            StringBuilder sb = new StringBuilder(GetEntitySelSql());
            sb.Append(BuilderWhereStatement(c));
            string sql = SqlHelper.BuildPageSqlStatement(sb.ToString(), "", c.Orderby, pageSize, pageIndex);
            return _dbHelper.GetDataList<T>(sql, CommandType.Text, _dbHelper.GetDataReader<T>, c.Parameters) ?? new List<T>();
        }

        public virtual int GetCount(Query query)
        {
            var c = query.Tranlsate(mapProperty);
            StringBuilder sb = new StringBuilder(GetCountSql());
            sb.Append(BuilderWhereStatement(c));
            return int.Parse(_dbHelper.GetData<Object>(sb.ToString(), CommandType.Text, _dbHelper.GetScalar, c.Parameters).ToString());
        }

        private string BuilderWhereStatement(WhereConditionInfo c)
        {
            StringBuilder wherBuilder = new StringBuilder();

            if (!string.IsNullOrWhiteSpace(c.WhereCondition))
            {
                wherBuilder.Append("  WHERE  ").Append(c.WhereCondition);
            }

            if (!string.IsNullOrWhiteSpace(RequiredCriterias()))
            {
                if (wherBuilder.Length <= 0)
                {
                    wherBuilder.Append("  WHERE ");
                }
                else
                {
                    wherBuilder.Append(" AND ");
                }

                wherBuilder.Append(RequiredCriterias());
            }
            return wherBuilder.ToString();
        }

        protected virtual void Init()
        {

        }

        protected virtual string RequiredCriterias()
        {
            return string.Empty;
        }

        protected abstract string GetEntitySelSql();
        protected abstract string GetCountSql();
    }
}
