﻿/*----------------------------------------------------------------
// Copyright (C) 2010 北京时空信联网络技术有限公司版权所有。 
//
//  文 件 名：  RunningNumber.cs
//  功能描述：  生成流水号
//
//	 
//  创建时间：2010-08-02
//  创 建 人：蒋世芳
//  部    门：技术部
//  职    务：
//
//----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Text;


namespace uni2uni.com.Framework.Common
{
    public class SingleTon<T> where T:new()
    {
        private static readonly T instance = new T();
        private SingleTon()
        { }

        static public T Instance
        {
            get { return instance; }
        }
    }
    /// <summary>
    /// 
    /// </summary>
    public class RunningNumber
    {
        public RunningNumber()
        { 
        }
        /// <summary>
        /// 流水号队列
        /// </summary>
        private System.Collections.Hashtable hash_Searil = new System.Collections.Hashtable();

        private void Init()
        {
            lock (this)
            {
 
            }
        }

        public string GetRunningNumber(string strType)
        {
            if (hash_Searil.Contains(strType))
            {
                //hash_Searil[strType] = hash_Searil[strType] + 1;
            }
            string strNumber = string.Empty;
            return strNumber;
        }

    }
}
