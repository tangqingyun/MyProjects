﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.Pkcs;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace uni2uni.com.Framework.BOCHelper
{
    public class VerifyTool
    {
        /// <summary>
        /// 对输入的字节组从Base64进行转换
        /// </summary>
        /// <param name="inputBytes">输入的字节组</param>
        /// <returns>转换后的字节组</returns>
        public static byte[] DecodeFromBase64(byte[] inputBytes)
        {
            FromBase64Transform myTransform = new FromBase64Transform(FromBase64TransformMode.IgnoreWhiteSpaces);

            byte[] myOutputBytes = new byte[myTransform.OutputBlockSize];

            MemoryStream outputDataStream = new MemoryStream(inputBytes.Length);

            //Transform the data in chunks the size of InputBlockSize.
            int i = 0;
            int inputBlockSize = 4;
            while (inputBytes.Length - i > inputBlockSize)
            {
                int nOutput = myTransform.TransformBlock(inputBytes, i, inputBlockSize, myOutputBytes, 0);
                i += inputBlockSize;
                if (nOutput > 0)
                {
                    outputDataStream.Write(myOutputBytes, 0, nOutput);
                }
            }

            //Transform the final block of data.
            myOutputBytes = myTransform.TransformFinalBlock(inputBytes, i, inputBytes.Length - i);
            outputDataStream.Write(myOutputBytes, 0, myOutputBytes.Length);

            //Free up any used resources.
            myTransform.Clear();

            //myInputFile.Close();
            outputDataStream.Position = 0;
            byte[] outputData = new byte[outputDataStream.Length];
            outputDataStream.Read(outputData, 0, (int)outputDataStream.Length);
            outputDataStream.Close();

            return outputData;
        }

        /// <summary>
        ///  验证签名
        /// </summary>
        /// <param name="sig">签名</param>
        /// <param name="msg">原始字符</param>
        /// <param name="dn"></param>
        /// <returns></returns>
        public static Boolean Verify(byte[] sig, byte[] msg, string dn)
        {
            Boolean b = true;
            try
            {
                ContentInfo signedData = new ContentInfo(msg);
                SignedCms cms = new SignedCms(signedData, true);
                cms.Decode(sig);
                //Check Signature
                cms.CheckSignature(true);
                //Check dn
                if (cms.Certificates.Count > 0)
                {
                    X509Certificate2 cert = cms.Certificates[0];
                    if (!string.IsNullOrEmpty(dn) && !dn.Equals(cert.Subject))
                    {
                        b = false;
                    }
                }

                byte[] data = cms.Encode();
            }
            catch (Exception e)
            {
                b = false;
            }
            return b;
        }

        /// <summary>
        ///  生成签名字符
        /// </summary>
        /// <param name="certFileName">cert路径</param>
        /// <param name="password">密码</param>
        /// <param name="dataTobeSign">要生成签名的字符byte[]</param>
        /// <returns>生成签名的Base64字符</returns>
        public static string SignatureMessage(string certFileName, string password, byte[] dataTobeSign)
        {
            byte[] pfxCert = File.ReadAllBytes(certFileName);
            //  byte[] dataTobeSign = File.ReadAllBytes(dataFileName);
            SecureString pwd = new SecureString();
            char[] pwdCharArray = password.ToCharArray();
            for (int i = 0; i < pwdCharArray.Length; i++)
            {
                pwd.AppendChar(pwdCharArray[i]);
            }
            X509Certificate2 cert = new X509Certificate2(pfxCert, pwd);
            CmsSigner signer = new CmsSigner(cert);
            signer.DigestAlgorithm = new Oid("1.3.14.3.2.26", "sha1");

            signer.IncludeOption = X509IncludeOption.EndCertOnly;

            ContentInfo signedData = new ContentInfo(dataTobeSign);
            SignedCms cms = new SignedCms(signedData, true);
            cms.ComputeSignature(signer);
            byte[] signature = cms.Encode();

            //base64
            ToBase64Transform base64Transform = new ToBase64Transform();
            byte[] inputBytes = signature;
            byte[] outputBytes = new byte[base64Transform.OutputBlockSize];
            int inputOffset = 0;
            int inputBlockSize = base64Transform.InputBlockSize;
            MemoryStream outputDataStream = new MemoryStream();
            while (inputBytes.Length - inputOffset > inputBlockSize)
            {
                base64Transform.TransformBlock(inputBytes, inputOffset, inputBytes.Length - inputOffset, outputBytes, 0);

                inputOffset += base64Transform.InputBlockSize;
                outputDataStream.Write(outputBytes, 0, base64Transform.OutputBlockSize);
            }
            outputBytes = base64Transform.TransformFinalBlock(inputBytes, inputOffset, inputBytes.Length - inputOffset);
            outputDataStream.Write(outputBytes, 0, outputBytes.Length);

            outputDataStream.Position = 0;
            byte[] outputData = new byte[outputDataStream.Length];
            outputDataStream.Read(outputData, 0, (int)outputDataStream.Length);
            outputDataStream.Close();

            return System.Text.Encoding.UTF8.GetString(outputData);
        }

    }
    public class InvokeMethod
    { 
        /// <summary>
        /// 通过post方式调接口
        /// </summary>
        /// <param name="url"></param>
        /// <param name="postParaList">post方式参数</param>
        /// <returns>退口返回结果</returns>
        private static string InvokePostMethod(string url, System.Collections.Hashtable postParaList)
        {
            try
            {
                System.Net.WebClient WebClientObj = new System.Net.WebClient();
                WebClientObj.Encoding = System.Text.Encoding.UTF8;

                System.Collections.Specialized.NameValueCollection PostVars = new System.Collections.Specialized.NameValueCollection();

                foreach (System.Collections.DictionaryEntry entry in postParaList)
                {
                    PostVars.Add(Convert.ToString(entry.Key), Convert.ToString(entry.Value));
                }
                //for (int i = 0; i < postParaList.Count; i++)
                //{
                //    PostPara para = postParaList[i] as PostPara;
                //    PostVars.Add(para.ParaName, para.ParaValue);
                //}

                byte[] byRemoteInfo = WebClientObj.UploadValues(url, "POST", PostVars);
                return System.Text.Encoding.UTF8.GetString(byRemoteInfo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 执行退款接口
        /// </summary>
        /// <param name="refundAmount">退款金额</param>
        /// <param name="orderNo">商户订单号</param>
        /// <param name="mRefundSeq">商户退款交易流水号</param>
        /// <returns>退款接口返回结果xml</returns>
        public static string RefundOrder(decimal refundAmount, string orderNo, string mRefundSeq)
        {
            System.Collections.Hashtable postParaList = CreateRefundPostParaList(refundAmount, orderNo, mRefundSeq);
            string url = System.Configuration.ConfigurationManager.AppSettings["bocRefundOrderAddr"].ToString();
            return InvokePostMethod(url, postParaList);
        }

        /// <summary>
        /// 生成退款Post参数
        /// </summary>
        /// <param name="refundAmount">退款金额</param>
        /// <param name="orderNo">商户订单号</param>
        /// <param name="mRefundSeq">商户退款交易流水号</param>
        /// <param name="curCode">退款币种</param>
        /// <returns></returns>
        private static System.Collections.Hashtable CreateRefundPostParaList(decimal refundAmount, string orderNo, string mRefundSeq, string curCode = "001")
        {
            string merchantNo = System.Configuration.ConfigurationManager.AppSettings["bocMerchantNo"].ToString();
            string pfxPassword = System.Configuration.ConfigurationManager.AppSettings["bocPfxPassword"].ToString();
            string pfxFilePath = System.Configuration.ConfigurationManager.AppSettings["bocPfxFilePath"].ToString();
            //string pfxFilePath = System.AppDomain.CurrentDomain.BaseDirectory + pfxSettingValue;

            System.Collections.Hashtable paraList = new System.Collections.Hashtable();
            paraList.Add("merchantNo", merchantNo);
            paraList.Add("mRefundSeq", mRefundSeq);
            paraList.Add("curCode", curCode);
            paraList.Add("refundAmount", refundAmount.ToString());
            paraList.Add("orderNo", orderNo);

            //商户签名数据串格式，各项数据用管道符分隔：
            //商户号|商户退款交易流水号|退款币种|退款金额|商户订单号
            //merchantNo | mRefundSeq | curCode | refundAmount |orderNo
            string strSign = string.Format("{0}|{1}|{2}|{3}|{4}", merchantNo, mRefundSeq, curCode, refundAmount, orderNo);
            string strSignData = BOCHelper.VerifyTool.SignatureMessage(pfxFilePath, pfxPassword, System.Text.Encoding.UTF8.GetBytes(strSign));

            paraList.Add("signData", strSignData);//商户签名数据

            return paraList;
        }
    }
}
