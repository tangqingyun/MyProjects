﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Reflection;
using System.Xml;
using System.Configuration;
using System.ComponentModel;

namespace uni2uni.com.Framework.Common
{
    /// <summary>
    /// ReflectHelper
    /// </summary>
    public class ReflectHelper
    {

        /// <summary>
        /// 获得指定属性的默认值
        /// </summary>
        /// <param name="p">属性对象</param>
        /// <returns>获得的默认值</returns>
        private static object GetDefaultValue(System.Reflection.PropertyInfo p)
        {
            Type pt = p.PropertyType;
            System.ComponentModel.DefaultValueAttribute dva =
                (System.ComponentModel.DefaultValueAttribute)
                Attribute.GetCustomAttribute(
                p, typeof(System.ComponentModel.DefaultValueAttribute));
            if (dva == null)
            {
                if (pt.Equals(typeof(byte)))
                    return (byte)0;
                else if (pt.Equals(typeof(short)))
                    return (short)0;
                else if (pt.Equals(typeof(int)))
                    return (int)0;
                else if (pt.Equals(typeof(uint)))
                    return (uint)0;
                else if (pt.Equals(typeof(long)))
                    return (long)0;
                else if (pt.Equals(typeof(float)))
                    return (float)0;
                else if (pt.Equals(typeof(double)))
                    return (double)0;
                else if (pt.Equals(typeof(decimal)))
                    return (decimal)0;
                else if (pt.Equals(typeof(DateTime)))
                    return DateTime.MinValue;
                else if (pt.Equals(typeof(char)))
                    return char.MinValue;
                else if (pt.Equals(typeof(Guid)))
                    return Guid.Empty;
                else if (pt.Equals(typeof(string)))
                    return string.Empty;
                else
                    return null;
            }
            else
            {
                System.ComponentModel.TypeConverter converter =
                    System.ComponentModel.TypeDescriptor.GetConverter(pt);
                if (dva.Value != null)
                {
                    Type t = dva.Value.GetType();
                    if (t.Equals(pt) || t.IsSubclassOf(pt))
                    {
                        return dva.Value;
                    }
                }
                if (converter == null)
                {
                    return dva.Value;
                }
                else
                {
                    return converter.ConvertFrom(dva.Value);
                }
            }
        }

        /// <summary>
        /// 获取可控类型值
        /// </summary>
        /// <param name="itemProperty"></param>
        /// <returns></returns>
        private static object GetIsObjectNullValue(PropertyInfo itemProperty, object col)
        {
            try
            {
                var pt = itemProperty.PropertyType;
                if (pt == typeof(DateTime?))
                {
                    return Convert.ToDateTime(col);
                }
                else if (pt == typeof(int?))
                {
                    return Convert.ToInt32(col);
                }
                else if (pt == typeof(Guid?))
                {
                    return Guid.Parse(col.ToString());
                }
                else if (pt == typeof(decimal?))
                {
                    return Convert.ToDecimal(col);
                }
                else if (pt == typeof(long?))
                {
                    return Convert.ToInt64(col.ToString());
                }
                else if (pt == typeof(bool?))
                {
                    return Convert.ToBoolean(col);
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        #region Get Data Info [method]=PopulateChangeFromIDataReader<T>

        /// <summary>
        /// PopulateChangeFromIDataReader
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dr"></param>
        /// <returns></returns>
        public static T PopulateChangeFromIDataReader<T>(IDataReader dr) where T : new()
        {
            if (dr == null)
            {
                throw new ArgumentNullException("dr");
            }

            T item = new T();
            var columnCount = dr.FieldCount;
            for (int i = 0; i < columnCount; i++)
            {
                //根据数据列名称得到匹配的实体属性对象。
                var columnName = dr.GetName(i);
                var itemProperty = item.GetType().GetProperty(columnName, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);

                //如果实体属性对象未找到，则跳过赋值操作
                if (itemProperty == null)
                {
                    continue;
                }

                //实体属性对象进行赋值操作
                try
                {
                    if (dr[i] == System.DBNull.Value)
                    {
                        var defultValue = GetDefaultValue(itemProperty);

                        var curItemProperty = itemProperty.GetValue(item, null);
                        if (curItemProperty == null || string.IsNullOrEmpty(curItemProperty.ToString()))
                        {
                            itemProperty.SetValue(item, defultValue, null);
                        }
                    }
                    else
                    {

                        itemProperty.SetValue(item, ConvertFrom(dr[i], itemProperty.PropertyType), null);
                    }
                }
                catch (Exception ex)
                {
                    itemProperty.SetValue(item, GetIsObjectNullValue(itemProperty, dr[i]), null);
                }
            }

            return item;

        }

        private  static object ConvertFrom(object dbValue,Type propertyType)
        {

            if (propertyType.IsAssignableFrom(dbValue.GetType()))
            {
                return dbValue;
            }
            var converter =  System.ComponentModel.TypeDescriptor.GetConverter(propertyType);

            if (converter.CanConvertFrom(dbValue.GetType()))
            {
                return  converter.ConvertFrom(dbValue);
            }

            if (converter.CanConvertFrom(typeof(string)))
            {
                return converter.ConvertFrom(dbValue.ToString());
            }
           
            return Convert.ChangeType(dbValue, propertyType);
        }

        #endregion

        /// <summary>
        /// GetFieldValue
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="t"></param>
        /// <param name="FieldName"></param>
        /// <returns></returns>
        public static object GetFieldValue<T>(T t, string FieldName)
        {
            if (string.IsNullOrEmpty(FieldName)) throw new ArgumentNullException("FieldName");
            if (t == null) throw new ArgumentNullException("t");
            object ReturnObjValue = null;
            try
            {
                System.Reflection.PropertyInfo[] propertys = GetPropertys(t.GetType());
                //检索所有字段
                foreach (PropertyInfo property in propertys)
                {
                    if (property.Name.ToLower() == FieldName.ToLower())
                    {
                        ReturnObjValue = property.GetValue(t, null);
                        break;
                    }
                }
            }
            catch
            {
                ReturnObjValue = null;
            }

            return ReturnObjValue;
        }

        /// <summary>
        /// GetEntityByXmlAttributeCollection
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="xmlAttributeCollection"></param>
        /// <returns></returns>
        public static T GetEntityByXmlAttributeCollection<T>(XmlAttributeCollection xmlAttributeCollection) where T : new()
        {
            if (xmlAttributeCollection == null) throw new ArgumentNullException("FieldName");
            T t = new T();
            System.Reflection.PropertyInfo[] propertys = GetPropertys(t.GetType());
            //检索所有字段
            foreach (PropertyInfo property in propertys)
            {
                foreach (XmlAttribute xmlAttribute in xmlAttributeCollection)
                {
                    if (property.Name.ToLower() == xmlAttribute.Name.ToLower())
                    {
                        if (property.PropertyType.IsEnum)
                        {
                            property.SetValue(t, Enum.Parse(property.PropertyType, xmlAttribute.Value), null);
                        }
                        else
                        {
                            property.SetValue(t, Convert.ChangeType(xmlAttribute.Value, property.PropertyType), null);
                        }
                        break;
                    }
                }
            }
            return t;
        }

        #region cacheData
        /// <summary>
        /// cache propertys data
        /// </summary>
        /// <param name="EntityType"></param>
        /// <returns></returns>
        public static PropertyInfo[] GetPropertys(Type EntityType)
        {
            string EntityKey = EntityType.Name.ToString();
            PropertyInfo[] propertys = CacheHelper.Get(EntityKey) as PropertyInfo[];

            if (propertys == null)
            {
                propertys = EntityType.GetProperties();

                CacheHelper.Insert(EntityKey, propertys, CacheHelper.DayFactor * 5);
            }
            return propertys;
        }

        public static object GetDelegateMethod(string AppName, Type DelegateType)
        {
            object ReturnObj = CacheHelper.Get(AppName);
            if (ReturnObj == null)
            {
                //做容错处理以下
                string TempStr = ConfigurationManager.AppSettings.Get(AppName);
                if (!string.IsNullOrEmpty(TempStr))
                {
                    string[] Str = TempStr.Split(',');
                    if (Str.Length == 3)
                    {

                        Object theObj = Assembly.Load(Str[0]).CreateInstance(Str[0] + "." + Str[1]);
                        ReturnObj = (object)Delegate.CreateDelegate(DelegateType, theObj, theObj.GetType().GetMethod(Str[2]));
                        CacheHelper.Insert(AppName, ReturnObj, CacheHelper.DayFactor * 5);
                    }
                }
            }
            return ReturnObj;
        }
        #endregion
    }
}
