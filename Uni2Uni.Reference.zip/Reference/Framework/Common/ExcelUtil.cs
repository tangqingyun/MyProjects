﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web;
using System.Web.UI;
using System.IO;
using System.Reflection;
using Microsoft.Office.Interop.Excel;
using System.Collections;

namespace uni2uni.com.Framework.Common
{
    /// <summary>
    /// 导出excel 简单实现
    /// </summary>
    public static class ExcelUtil
    {
        private static System.Web.UI.Page currentPage = HttpContext.Current.Handler as System.Web.UI.Page;
        private static Object sycObj = new Object();
        private static int incremental = 10;
        /// <summary>
        /// 按照时间生成excel名称 防止生成相同名的excel造成文件覆盖
        /// </summary>
        /// <returns></returns>
        private static string CreateExcelName()
        {
            lock (sycObj)
            {
                incremental = incremental + 1;
                if (incremental > 99)
                    incremental = 10;
                return Convert.ToInt64(DateTime.Now.ToString("yyyyMMddHHmmssfff") + incremental).ToString();
            }
        }

        /// <summary>
        /// 生成临时文件名
        /// </summary>
        /// <returns></returns>
        public static string CreateTmpFile()
        {
            string strMapPath = HttpContext.Current.Server.MapPath("~/");   //获取Web应用程序的物理路径
            string strBakPath = strMapPath + "report\\bak";
            if (!Directory.Exists(strBakPath))
            {
                Directory.CreateDirectory(strBakPath);
            }
            string sourceExcelFileName = strMapPath + "report\\bak" + DateTime.Now.ToString("yyyyMMddhhmmssff") + ".xls";
            return sourceExcelFileName;
        }

        /// <summary>
        /// 导出excel 
        /// </summary>
        /// <typeparam name="T">泛型实体</typeparam>
        /// <param name="response"></param>
        /// <param name="listColumes">要显示的列名</param>
        /// <param name="listProperty">要显示的导出属性名  和实体的属性名有关,顺序由显示的列确定 可以同listColumes</param>
        /// <param name="listModel">实体集合</param>
        public static void ExportExcel<T>(HttpResponse response, IList<string> listColumns, IList<string> listProperty, IList<T> listModel) where T : class, new()
        {
            if (listColumns.Count == 0)
            {
                throw new IndexOutOfRangeException("No Columnes!");
            }
            if (listColumns.Count != listProperty.Count)
            {
                throw new ArgumentException("Columns and properties length are not equal.");
            }
            string sheetName = "sheetName";
            using (StringWriter writer = new StringWriter())
            {
                writer.WriteLine("<html xmlns:x=\"urn:schemas-microsoft-com:office:excel\">");
                writer.WriteLine("<head>");
                writer.WriteLine("<!--[if gte mso 9]>");
                writer.WriteLine("<xml>");
                writer.WriteLine(" <x:ExcelWorkbook>");
                writer.WriteLine("  <x:ExcelWorksheets>");
                writer.WriteLine("   <x:ExcelWorksheet>");
                writer.WriteLine("    <x:Name>" + sheetName + "</x:Name>");
                writer.WriteLine("    <x:WorksheetOptions>");
                writer.WriteLine("      <x:Print>");
                writer.WriteLine("       <x:ValidPrinterInfo />");
                writer.WriteLine("      </x:Print>");
                writer.WriteLine("    </x:WorksheetOptions>");
                writer.WriteLine("   </x:ExcelWorksheet>");
                writer.WriteLine("  </x:ExcelWorksheets>");
                writer.WriteLine("</x:ExcelWorkbook>");
                writer.WriteLine("</xml>");
                writer.WriteLine("<![endif]-->");
                writer.WriteLine("</head>");
                writer.WriteLine("<body>");
                writer.WriteLine("<table>");
                writer.WriteLine("<tr>");
                foreach (string item in listColumns)
                {
                    writer.WriteLine("<td>" + item + "</td>"); //列名
                }
                writer.WriteLine("</tr>");
                //通过反射 显示要显示的列
                BindingFlags bf = BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static;//反射标识
                Type objType = typeof(T);
                PropertyInfo[] propInfoArr = objType.GetProperties(bf);
                foreach (T model in listModel)
                {
                    writer.WriteLine("<tr>");
                    foreach (string propName in listProperty)
                    {
                        foreach (PropertyInfo propInfo in propInfoArr)
                        {
                            if (string.Compare(propInfo.Name.ToUpper(), propName.ToUpper()) == 0)
                            {
                                PropertyInfo modelProperty = model.GetType().GetProperty(propName);
                                if (modelProperty != null)
                                {
                                    object objResult = modelProperty.GetValue(model, null);
                                    writer.WriteLine("<td>" + ((objResult == null) ? string.Empty : objResult) + "</td>");
                                }
                                else
                                {
                                    throw new Exception("Property name may be not exists!");
                                }
                            }
                        }
                    }
                    writer.WriteLine("</tr>");
                }
                writer.WriteLine("</table>");
                writer.WriteLine("</body>");
                writer.WriteLine("</html>");
                writer.Close();
                response.Clear();
                response.Buffer = true;
                response.Charset = "UTF-8";
                currentPage.EnableViewState = false;
                response.AddHeader("Content-Disposition", "attachment; filename=" + CreateExcelName() + ".xls");
                response.ContentType = "application/ms-excel";
                response.ContentEncoding = System.Text.Encoding.GetEncoding("utf-8");
                response.Write(writer);
                //response.End();
                HttpContext.Current.ApplicationInstance.CompleteRequest();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="response"></param>
        /// <param name="columnNameList"></param>
        /// <param name="propertyList"></param>
        /// <param name="moduleList"></param>
        public static void ExportCsv<T>(HttpResponse response, List<Header> headerList,
            string[] columnNameList, string[] propertyList, IList<T> moduleList,
            string extMessage, OffsetType type)
        {
            if (columnNameList == null || columnNameList.Length == 0 ||
                propertyList == null || propertyList.Length == 0)
            {
                throw new IndexOutOfRangeException("No Columnes!");
            }
            if (propertyList.Length != columnNameList.Length)
            {
                throw new ArgumentException("Columns and properties length are not equal.");
            }
            string fileName = string.Empty;
            Microsoft.Office.Interop.Excel.Application excel1 = null;
            Workbook workbook1 = null;
            Worksheet worksheet1 = null;
            try
            {

                excel1 = new Microsoft.Office.Interop.Excel.Application();
                int rowindex = 1;
                workbook1 = excel1.Workbooks.Add(true);
                worksheet1 = workbook1.Sheets.get_Item(1) as Microsoft.Office.Interop.Excel.Worksheet;
                worksheet1.Activate();

                excel1.Visible = true;
                excel1.DisplayAlerts = false;


                if (headerList != null && headerList.Count > 0)
                {
                    foreach (Header obj in headerList)
                    {
                        setHeader(obj, worksheet1);
                        if (obj.IsEnter)
                        {
                            rowindex++;
                        }
                    }
                }

                // 写入字段
                for (int i = 0; i < columnNameList.Length; i++)
                {
                    worksheet1.Cells[rowindex, i + 1] = columnNameList[i];
                }

                rowindex++;

                // 设置表格内容
                setContent<T>(moduleList, propertyList, columnNameList,
                    rowindex, ref worksheet1);

                fileName = CreateTmpFile();
                workbook1.Close(true, fileName, null);

                System.IO.FileInfo file = new System.IO.FileInfo(fileName);

                response.Clear();
                response.Charset = "UTF-8";
                response.ContentEncoding = System.Text.Encoding.UTF8;
                response.AddHeader("Content-Disposition", "attachment;filename=" + HttpUtility.UrlEncode(CreateExcelName() + ".xls", Encoding.UTF8).ToString()); //设置回发内容为Excel
                response.AddHeader("Content-Length", file.Length.ToString());
                response.ContentType = "application/ms-excel";
                response.WriteFile(fileName);    //把刚刚生成的Excel文件写入Http流
                //response.End();
                HttpContext.Current.ApplicationInstance.CompleteRequest();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                if (workbook1 != null)
                {
                    //关闭
                    worksheet1 = null;
                    workbook1 = null;
                    excel1.Quit();
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(excel1);
                    excel1 = null;
                    System.GC.Collect();
                }
            }
        }

        /// <summary>
        /// 将excel导入到DataTable (通用)
        /// </summary>
        /// <param name="fileName">导入文件的名称</param>
        /// <param name="startRow">起始行</param>
        /// <param name="endColumn">结束列</param>
        /// <param name="mainIndex">重要列（不能为空列）</param>
        /// <returns></returns>
        public static System.Data.DataTable ImportExcelCommon(string fileName, int startRow, int endColumn, int mainRow)
        {
            System.Data.DataTable dataTable = null;
            if (File.Exists(fileName))
            {
                Microsoft.Office.Interop.Excel.Application excelApp = null;
                Microsoft.Office.Interop.Excel.Workbook excelWb = null;
                Microsoft.Office.Interop.Excel.Worksheet excelWs = null;
                try
                {
                    excelApp = new Microsoft.Office.Interop.Excel.Application();
                    excelWb = excelApp.Workbooks.Open(fileName);
                    excelWs = excelWb.Sheets.get_Item(1) as Microsoft.Office.Interop.Excel.Worksheet;
                    initTable(ref dataTable, endColumn);
                    while (true)
                    {
                        DataRow dr = dataTable.NewRow();
                        for (int i = 1; i <= endColumn; i++)
                        {
                            string s = Convert.ToString(((Range)excelWs.Cells[startRow, i]).Value);
                            dr[i - 1] = (s == null ? string.Empty : s);
                        }
                        dataTable.Rows.Add(dr);
                        startRow++;
                        if (((Range)excelWs.Cells[startRow, mainRow]).Value == null)
                        {
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    if (excelWb != null)
                    {
                        excelWb.Close();
                        excelApp.Workbooks.Close();
                        excelApp.Quit();
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                        excelApp = null;
                        System.GC.Collect();
                    }
                }

            }

            return dataTable;
        }
        /// <summary>
        /// 将excel导入到发票表
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static System.Data.DataTable ImportExcelReceipt(string fileName, int startRow, int endColumn)
        {
            System.Data.DataTable dataTable = null;
            if (File.Exists(fileName))
            {
                Microsoft.Office.Interop.Excel.Application excelApp = null;
                Microsoft.Office.Interop.Excel.Workbook excelWb = null;
                Microsoft.Office.Interop.Excel.Worksheet excelWs = null;
                try
                {
                    excelApp = new Microsoft.Office.Interop.Excel.Application();
                    excelWb = excelApp.Workbooks.Open(fileName);
                    excelWs = excelWb.Sheets.get_Item(1) as Microsoft.Office.Interop.Excel.Worksheet;
                    initTable(ref dataTable, endColumn);
                    while (true)
                    {
                        DataRow dr = dataTable.NewRow();
                        for (int i = 1; i <= endColumn; i++)
                        {
                            string s = Convert.ToString(((Range)excelWs.Cells[startRow, i]).Value);
                            dr[i - 1] = (s == null ? string.Empty : s);
                        }
                        dataTable.Rows.Add(dr);
                        startRow++;
                        if (((Range)excelWs.Cells[startRow, 1]).Value == null)
                        {
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    if (excelWb != null)
                    {
                        excelWb.Close();
                        excelApp.Workbooks.Close();
                        excelApp.Quit();
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                        excelApp = null;
                        System.GC.Collect();
                    }
                }

            }

            return dataTable;
        }

        /// <summary>
        /// 将excel导入到物流表
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="startRow"></param>
        /// <param name="endColumn"></param>
        /// <returns></returns>
        public static System.Data.DataTable ImportExcelLogistes(string fileName, int startRow, int endColumn)
        {
            System.Data.DataTable dataTable = null;
            if (File.Exists(fileName))
            {
                Microsoft.Office.Interop.Excel.Application excelApp = null;
                Microsoft.Office.Interop.Excel.Workbook excelWb = null;
                Microsoft.Office.Interop.Excel.Worksheet excelWs = null;
                try
                {
                    excelApp = new Microsoft.Office.Interop.Excel.Application();
                    excelWb = excelApp.Workbooks.Open(fileName);
                    excelWs = excelWb.Sheets.get_Item(1) as Microsoft.Office.Interop.Excel.Worksheet;
                    initTable(ref dataTable, endColumn);
                    while (true)
                    {
                        DataRow dr = dataTable.NewRow();
                        for (int i = 1; i <= endColumn; i++)
                        {
                            string s = Convert.ToString(((Range)excelWs.Cells[startRow, i]).Value);
                            dr[i - 1] = (s == null ? string.Empty : s);
                        }
                        dataTable.Rows.Add(dr);
                        startRow++;
                        if (((Range)excelWs.Cells[startRow, 3]).Value == null)
                        {
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    if (excelWb != null)
                    {
                        excelWb.Close();
                        excelApp.Workbooks.Close();
                        excelApp.Quit();
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                        excelApp = null;
                        System.GC.Collect();
                    }
                }

            }

            return dataTable;
        }

        /// <summary>
        /// 初始化表格
        /// </summary>
        /// <param name="dataTable"></param>
        private static void initTable(ref System.Data.DataTable dataTable, int columnNum)
        {
            dataTable = new System.Data.DataTable();
            for (int i = 1; i <= columnNum; i++)
            {
                dataTable.Columns.Add(new DataColumn(i.ToString()));
            }
        }

        /// <summary>
        /// 设置excel表头
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="sheet"></param>
        private static void setHeader(Header obj, Worksheet sheet)
        {
            Range range1 = null;
            if (obj.IsSingle)
            {
                range1 = sheet.get_Range(obj.From);
            }
            else
            {
                range1 = sheet.get_Range(obj.From, obj.To);
            }
            range1.Value2 = obj.HeaderTitle;
            range1.Merge(false);
        }

        /// <summary>
        /// 设置excel表格内容
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="moduleList"></param>
        /// <param name="propertyList"></param>
        /// <param name="columnNameList"></param>
        /// <param name="rowindex"></param>
        /// <param name="worksheet1"></param>
        private static void setContent<T>(IList<T> moduleList, string[] propertyList,
            string[] columnNameList, int rowindex, ref Worksheet worksheet1)
        {
            //通过反射 显示要显示的列
            BindingFlags bf = BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static;//反射标识
            Type objType = typeof(T);
            PropertyInfo[] propInfoArr = objType.GetProperties(bf);
            foreach (T model in moduleList)
            {
                //foreach (string propName in propertyList)
                for (int j = 0; j < propertyList.Length; j++)
                {
                    //
                    foreach (PropertyInfo propInfo in propInfoArr)
                    {
                        if (string.Compare(propInfo.Name.ToUpper(), propertyList[j].ToUpper()) == 0)
                        {
                            PropertyInfo modelProperty = model.GetType().GetProperty(propertyList[j]);
                            if (modelProperty != null)
                            {
                                object objResult = modelProperty.GetValue(model, null);
                                worksheet1.Cells[rowindex, j + 1] = (objResult == null) ? string.Empty : objResult;
                            }
                            else
                            {
                                throw new Exception("Property name may be not exists!");
                            }
                        }
                    }
                }
                rowindex++;
            }
        }

        /// <summary>
        /// 导出excel 
        /// </summary>
        /// <typeparam name="T">泛型实体</typeparam>
        /// <param name="response"></param>
        /// <param name="listColumes">要显示的列名</param>
        /// <param name="listProperty">要显示的导出属性名  和实体的属性名有关,顺序由显示的列确定 可以同listColumes</param>
        /// <param name="dsResult">dataset</param>
        public static void ExportExcel(HttpResponse response, IList<string> listColumns, DataSet dsResult)
        {
            if (listColumns.Count == 0)
            {
                throw new IndexOutOfRangeException("No Columnes!");
            }
            string sheetName = "sheetName";
            using (StringWriter writer = new StringWriter())
            {
                writer.WriteLine("<html xmlns:x=\"urn:schemas-microsoft-com:office:excel\">");
                writer.WriteLine("<head>");
                writer.WriteLine("<!--[if gte mso 9]>");
                writer.WriteLine("<xml>");
                writer.WriteLine(" <x:ExcelWorkbook>");
                writer.WriteLine("  <x:ExcelWorksheets>");
                writer.WriteLine("   <x:ExcelWorksheet>");
                writer.WriteLine("    <x:Name>" + sheetName + "</x:Name>");
                writer.WriteLine("    <x:WorksheetOptions>");
                writer.WriteLine("      <x:Print>");
                writer.WriteLine("       <x:ValidPrinterInfo />");
                writer.WriteLine("      </x:Print>");
                writer.WriteLine("    </x:WorksheetOptions>");
                writer.WriteLine("   </x:ExcelWorksheet>");
                writer.WriteLine("  </x:ExcelWorksheets>");
                writer.WriteLine("</x:ExcelWorkbook>");
                writer.WriteLine("</xml>");
                writer.WriteLine("<![endif]-->");
                writer.WriteLine("</head>");
                writer.WriteLine("<body>");
                writer.WriteLine("<table>");
                writer.WriteLine("<tr>");
                foreach (string item in listColumns)
                {
                    writer.WriteLine("<td>" + item + "</td>"); //列名
                }
                writer.WriteLine("</tr>");
                foreach (DataRow dr in dsResult.Tables[0].Rows)
                {
                    writer.WriteLine("<tr>");
                    for (int i = 0; i < dr.ItemArray.Length; i++)
                    {
                        writer.WriteLine("<td>" + dr[i] + "</td>");
                    }
                    writer.WriteLine("</tr>");
                }
                writer.WriteLine("</table>");
                writer.WriteLine("</body>");
                writer.WriteLine("</html>");
                writer.Close();
                response.Clear();
                response.Buffer = true;
                response.Charset = "UTF-8";
                currentPage.EnableViewState = false;
                response.AddHeader("Content-Disposition", "attachment; filename=" + CreateExcelName() + ".xls");
                response.ContentType = "application/ms-excel";
                response.ContentEncoding = System.Text.Encoding.GetEncoding("utf-8");
                response.Write(writer);
                //response.End();
                HttpContext.Current.ApplicationInstance.CompleteRequest();
            }
        }

        /// <summary>
        /// 导出excel（暂时过度） 
        /// </summary>
        /// <typeparam name="T">泛型实体</typeparam>
        /// <param name="response"></param>
        /// <param name="listColumes">要显示的列名</param>
        /// <param name="listProperty">要显示的导出属性名  和实体的属性名有关,顺序由显示的列确定 可以同listColumes</param>
        /// <param name="dsResult">dataset</param>
        public static void ExportExcelFinance(HttpResponse response, IList<string> listColumns, DataSet dsResult)
        {
            if (listColumns.Count == 0)
            {
                throw new IndexOutOfRangeException("No Columnes!");
            }
            string sheetName = "sheetName";
            using (StringWriter writer = new StringWriter())
            {
                writer.WriteLine("<html xmlns:x=\"urn:schemas-microsoft-com:office:excel\">");
                writer.WriteLine("<head>");
                writer.WriteLine("<!--[if gte mso 9]>");
                writer.WriteLine("<xml>");
                writer.WriteLine(" <x:ExcelWorkbook>");
                writer.WriteLine("  <x:ExcelWorksheets>");
                writer.WriteLine("   <x:ExcelWorksheet>");
                writer.WriteLine("    <x:Name>" + sheetName + "</x:Name>");
                writer.WriteLine("    <x:WorksheetOptions>");
                writer.WriteLine("      <x:Print>");
                writer.WriteLine("       <x:ValidPrinterInfo />");
                writer.WriteLine("      </x:Print>");
                writer.WriteLine("    </x:WorksheetOptions>");
                writer.WriteLine("   </x:ExcelWorksheet>");
                writer.WriteLine("  </x:ExcelWorksheets>");
                writer.WriteLine("</x:ExcelWorkbook>");
                writer.WriteLine("</xml>");
                writer.WriteLine("<![endif]-->");
                writer.WriteLine("</head>");
                writer.WriteLine("<body>");
                writer.WriteLine("<table>");
                writer.WriteLine("<tr>");
                foreach (string item in listColumns)
                {
                    writer.WriteLine("<td>" + item + "</td>"); //列名
                }
                writer.WriteLine("</tr>");
                foreach (DataRow dr in dsResult.Tables[0].Rows)
                {
                    writer.WriteLine("<tr>");
                    for (int i = 0; i < dr.ItemArray.Length; i++)
                    {
                        if (i != 4 && i != 6 && i != 9)
                        {
                            writer.WriteLine("<td>" + dr[i] + "</td>");
                        }
                        else
                        { }
                    }
                    writer.WriteLine("</tr>");
                }
                writer.WriteLine("</table>");
                writer.WriteLine("</body>");
                writer.WriteLine("</html>");
                writer.Close();
                response.Clear();
                response.Buffer = true;
                response.Charset = "UTF-8";
                currentPage.EnableViewState = false;
                response.AddHeader("Content-Disposition", "attachment; filename=" + CreateExcelName() + ".xls");
                response.ContentType = "application/ms-excel";
                response.ContentEncoding = System.Text.Encoding.GetEncoding("utf-8");
                response.Write(writer);
                //response.End();
                HttpContext.Current.ApplicationInstance.CompleteRequest();
            }
        }

        /// <summary>
        /// 将excel导入到DataTable (财务模块订单查询专用)
        /// </summary>
        /// <param name="fileName">导入文件的名称</param>
        /// <param name="endColumn">结束列</param>
        /// <param name="mainIndex">重要列（不能为空列）</param>
        /// <returns></returns>
        public static System.Data.DataTable ImportExcelCommon(string fileName, int endColumn, int mainIndex)
        {
            System.Data.DataTable dataTable = null;
            if (File.Exists(fileName))
            {
                Microsoft.Office.Interop.Excel.Application excelApp = null;
                Microsoft.Office.Interop.Excel.Workbook excelWb = null;
                Microsoft.Office.Interop.Excel.Worksheet excelWs = null;
                try
                {
                    excelApp = new Microsoft.Office.Interop.Excel.Application();
                    excelWb = excelApp.Workbooks.Open(fileName);
                    excelWs = excelWb.Sheets.get_Item(1) as Microsoft.Office.Interop.Excel.Worksheet;
                    initTable(ref dataTable, endColumn);
                    //得到起始行号(订单号title所在行号)
                    int startRow = 1;
                    while (startRow < excelWs.UsedRange.Rows.Count)
                    {
                        string strTemp = "";
                        if (Convert.ToString(((Range)excelWs.Cells[startRow, mainIndex]).Value) != null)
                        {
                            strTemp = Convert.ToString(((Range)excelWs.Cells[startRow, mainIndex]).Value).Trim();
                        }
                        if (strTemp == "订单号")
                        {
                            break;
                        }
                        startRow++;
                    }
                    //设置订单号ID开始行号
                    startRow++;

                    //得到DataTable
                    while (true)
                    {
                        DataRow dr = dataTable.NewRow();
                        for (int i = 1; i <= endColumn; i++)
                        {
                            string s = Convert.ToString(((Range)excelWs.Cells[startRow, i]).Value);
                            dr[i - 1] = (s == null ? string.Empty : s);
                        }
                        dataTable.Rows.Add(dr);
                        startRow++;
                        if (((Range)excelWs.Cells[startRow, mainIndex]).Value == null)
                        {
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                finally
                {
                    if (excelWb != null)
                    {
                        excelWb.Close();
                        excelApp.Workbooks.Close();
                        excelApp.Quit();
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                        excelApp = null;
                        System.GC.Collect();
                    }
                }

            }

            return dataTable;
        }
        
        /// <summary>
        /// 将Table导入到Excel
        /// </summary>
        /// <param name="dt">table</param>
        /// <param name="strFileName">导出时的excel文件名</param>
        /// <param name="head">excel表头文字</param>
        public static void DataTabletoExcelds(System.Data.DataTable dt, string strFileName, string[] head)
        {
            if (dt == null)
                return;

            string fileName = "";
            int rowNum = dt.Rows.Count;
            int columnNum = dt.Columns.Count;
            int rowIndex = 1;
            int columnIndex = 0;
            Application xlApp = new Application();
            xlApp.DefaultFilePath = "";
            xlApp.DisplayAlerts = true;
            xlApp.SheetsInNewWorkbook = 1;
            Workbook xlBook = xlApp.Workbooks.Add(true);

            //将DataTable的列名导入Excel表第一行
            //foreach (DataColumn dc in dt.Columns)
            //{
            //    columnIndex++;
            //    xlApp.Cells[rowIndex, columnIndex] = dc.ColumnName;
            //}

            //设置Excel表头s
            for (int i = 0; i < head.Length; i++)
            {
                columnIndex++;
                xlApp.Cells[rowIndex, columnIndex] = head[i];
            }
            

            //将DataTable中的数据导入Excel中
            for (int i = 0; i < rowNum; i++)
            {
                rowIndex++;
                columnIndex = 0;
                for (int j = 0; j < columnNum; j++)
                {
                    columnIndex++;
                    xlApp.Cells[rowIndex, columnIndex] = dt.Rows[i][j].ToString();
                }
            }
            xlBook.SaveCopyAs(fileName);
            fileName = CreateTmpFile();
            xlBook.Close(true, fileName, null);
            System.IO.FileInfo file = new System.IO.FileInfo(fileName);

            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Charset = "UTF-8";
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.UTF8;
            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + HttpUtility.UrlEncode(strFileName + ".xls", Encoding.UTF8).ToString()); 
            HttpContext.Current.Response.AddHeader("Content-Length", file.Length.ToString());
            HttpContext.Current.Response.ContentType = "application/ms-excel";
            HttpContext.Current.Response.WriteFile(fileName); 
            HttpContext.Current.ApplicationInstance.CompleteRequest();

        }

        /// <summary>
        /// 将多个Table导入到Excel
        /// </summary>
        /// <param name="arrDt">table数组</param>
        /// <param name="strFileName">导出时的excel文件名导出时的excel文件名</param>
        /// <param name="head">excel表头文字</param>
        public static void DataTableToExcel(System.Data.DataTable dt, string strFileName, string[] head) 
        {
            if (dt.Rows.Count == 0)
                return;

            string fileName = "";


            int rowNum = dt.Rows.Count;
            int columnNum = dt.Columns.Count;
            int rowIndex = 1;
            int columnIndex = 0;
            Application xlApp = new Application();
            xlApp.DefaultFilePath = "";
            xlApp.DisplayAlerts = true;
            xlApp.SheetsInNewWorkbook = 1;
            
            Workbook xlBook = xlApp.Workbooks.Add(true);
            //设置Excel表头
            for (int i = 0; i < head.Length; i++)
            {
                columnIndex++;
                xlApp.Cells[rowIndex, columnIndex] = head[i];
            }

            //将DataTable中的数据导入Excel中
            for (int i = 0; i < rowNum; i++)
            {
                rowIndex++;
                columnIndex = 0;
                for (int j = 0; j < columnNum; j++)
                {
                    columnIndex++;
                    xlApp.Cells[rowIndex, columnIndex] = "'"+dt.Rows[i][j].ToString();
                    xlApp.Cells[rowIndex, columnIndex].NumberFormatLocal = "@";
                }
            }
            xlBook.SaveCopyAs(fileName);
            fileName = CreateTmpFile();
            xlBook.Close(true, fileName, null);

            System.IO.FileInfo file = new System.IO.FileInfo(fileName);
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Charset = "UTF-8";
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.UTF8;
            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + HttpUtility.UrlEncode(strFileName + ".xls", Encoding.UTF8).ToString());
            HttpContext.Current.Response.AddHeader("Content-Length", file.Length.ToString());
            HttpContext.Current.Response.ContentType = "application/ms-excel";
            HttpContext.Current.Response.WriteFile(fileName);
            HttpContext.Current.ApplicationInstance.CompleteRequest();

        } 


    }

    /// <summary>
    /// 附加信息位置
    /// </summary>
    public enum OffsetType
    {
        Top,
        Buttom
    }
}
