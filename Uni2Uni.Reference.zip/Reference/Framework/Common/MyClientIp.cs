﻿using System;

namespace uni2uni.com.Framework.Common
{
    public class MyClientIp
    {
        /// <summary>
        /// 获取客户端的IP，可以取到代理后的IP
        /// </summary>

        /// <returns></returns>
        public static string GetClientIp()
        {
            var lRet = string.Empty;
            if (!string.IsNullOrEmpty(System.Web.HttpContext.Current.Request.ServerVariables["HTTP_VIA"]))
                lRet = Convert.ToString(System.Web.HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"]);
            if (string.IsNullOrEmpty(lRet))
                lRet = Convert.ToString(System.Web.HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"]);
            return lRet;
        }
    }
}
