﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using System.IO;

namespace uni2uni.com.Framework.Web
{
    public abstract class PageBase : Page
    {
        protected override void Render(HtmlTextWriter writer)
        {
            if (writer is Html32TextWriter)
            {
                writer = new FormFixerHtml32TextWriter(writer.InnerWriter);
            }
            else
            {
                writer = new FormFixerHtmlTextWriter(writer.InnerWriter);
            }

            StringWriter stringWriter = new StringWriter();
            HtmlTextWriter htmlWriter = new HtmlTextWriter(stringWriter);
            this.IterateControls(this.Controls);
            base.Render(htmlWriter);
            string html = stringWriter.ToString();

            #region 将ViewState代码移到底部
            int startPoint = html.IndexOf("<input type=\"hidden\" name=\"__VIEWSTATE\"");
            if (startPoint >= 0)
            {
                int endPoint = html.IndexOf("/>", startPoint) + 2;
                string viewStateInput = html.Substring(startPoint, endPoint - startPoint);
                html = html.Remove(startPoint, endPoint - startPoint);
                int formEndStart = html.IndexOf("</form>", startPoint);
                if (formEndStart >= 0)
                {
                    html = html.Insert(formEndStart, viewStateInput);
                }
            }
            #endregion

            #region 压缩HTML
            html = Regex.Replace(html, @"\<![ \r\n\t]*--", "");
            html = Regex.Replace(html, @"[/][/]\s--[ \r\n\t]*\>", "");
            html = Regex.Replace(html, @"--\>", "");
            if (html.IndexOf("<textarea") >= 0)
            {
                html = Regex.Replace(html, @">\n\s\t", ">");
            }
            else
            {
                html = html.Replace("\r\n", "");
            }
            html = html.Replace("\t", "");
            #endregion

            #region 转换相对路径
            MatchCollection collection = Regex.Matches(html, "<(a|link|img|script|input|form).[^>]*(href|src|action)=(\\\"|'|)(.[^\\\"']*)(\\\"|'|)[^>]*>", RegexOptions.IgnoreCase);

            foreach (Match match in collection)
            {
                if (match.Groups[match.Groups.Count - 2].Value.IndexOf("~") != -1)
                {
                    string url = this.Page.ResolveUrl(match.Groups[match.Groups.Count - 2].Value);
                    html = html.Replace(match.Groups[match.Groups.Count - 2].Value, url);
                }
            }
            #endregion
            writer.Write(html);

        }


        private void IterateControls(ControlCollection controls)
        {
            foreach (Control c in controls)
            {
                this.ProcessControl(c);
            }
        }

        internal void ProcessControl(Control c)
        {

            if (c is Image)
            {
                Image ctrl = (Image)c;
                if (ctrl.ImageUrl.IndexOf("~") != -1)
                {
                    ctrl.ImageUrl = this.Page.ResolveUrl(ctrl.ImageUrl);
                }
            }
            if (c is HtmlImage)
            {
                HtmlImage ctrl = (HtmlImage)c;
                if (ctrl.Src.IndexOf("~") != -1)
                {
                    ctrl.Src = this.Page.ResolveUrl(ctrl.Src);
                }
            }
            if (c is HtmlAnchor)
            {
                HtmlAnchor ctrl = (HtmlAnchor)c;
                if (ctrl.HRef.IndexOf("~") != -1)
                {
                    ctrl.HRef = this.Page.ResolveUrl(ctrl.HRef);
                }
            }
            if (c is HyperLink)
            {
                HyperLink ctrl = (HyperLink)c;
                if (ctrl.NavigateUrl.IndexOf("~") != -1)
                {
                    ctrl.NavigateUrl = this.Page.ResolveUrl(ctrl.NavigateUrl);
                }
                if (ctrl.ImageUrl.IndexOf("~") != -1)
                {
                    ctrl.ImageUrl = this.Page.ResolveUrl(ctrl.ImageUrl);
                }
            }

            if (c.HasControls())
            {
                this.IterateControls(c.Controls);
            }

        }



    }
}
