using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace uni2uni.com.Framework.Web
{

    public class Globals
    {
        #region Properties
        /// <summary>
        /// ��ȡIP��ַ
        /// </summary>
        static public string IPAddress
        {
            get
            {
                string userIP;
                HttpRequest Request = HttpContext.Current.Request;
                // ���ʹ�ô�������ȡ��ʵIP
                if (Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != "")
                    userIP = Request.ServerVariables["REMOTE_ADDR"];
                else
                    userIP = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
                if (userIP == null || userIP == "")
                    userIP = Request.UserHostAddress;
                return userIP;
            }
        }
        #endregion

        /// <summary>
        /// �ж��ı��Ƿ�Ϊ��
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static bool IsNullorEmpty(string text)
        {
            return text == null || text.Trim() == string.Empty;
        }

        static public string ApplicationPath
        {

            get
            {
                string applicationPath = HttpContext.Current.Request.ApplicationPath;

                // Are we in an application?
                //
                if (applicationPath == "/")
                {
                    return string.Empty;
                }
                else
                {
                    return applicationPath;
                }
            }

        }



        /// <summary>
        /// ��ȡվ��URLʵ��
        /// </summary>
        /// <returns></returns>
        static public SiteUrls GetSiteUrls()
        {
            // return new SiteUrls();
            // ��д
            string cacheKey = "SiteUrls";

            if (HttpRuntime.Cache[cacheKey] == null)
            {
                SiteUrls siteUrls = new SiteUrls();
            }

            return (SiteUrls)HttpRuntime.Cache[cacheKey];
        }
    }
}
