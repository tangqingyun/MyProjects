using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace uni2uni.com.Framework.Web
{
    /// <summary>
    /// Url��д��
    /// </summary>
    public class ReWrittenUrl
    {
        private string _name;
        private string _path;
        private Regex _regex = null;

        public ReWrittenUrl(string name, string pattern, string path)
        {
            _name = name;
            _path = path;
            _regex = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.Compiled);
        }

        public bool IsMatch(string url)
        {

            return _regex.IsMatch(url);
        }

        public virtual string Convert(string url, string qs)
        {
            if (qs != null && qs.StartsWith("?"))
            {
                qs = qs.Replace("?", "&");
            }
            return string.Format("{0}{1}", _regex.Replace(url, _path), qs);
        }
    }
}
