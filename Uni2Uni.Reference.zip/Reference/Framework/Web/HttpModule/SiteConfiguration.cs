using System;
using System.Collections.Generic;
using System.Text;
using uni2uni.com.Framework.Common;
using System.Xml;
using System.Web;
using System.IO;
using System.Web.Caching;

namespace uni2uni.com.Framework.Web
{

    public class SiteConfiguration
    {
        #region Member variables

        public static readonly string CacheKey = "SiteConfiguration";

        string defaultLanguage;
        string filesPath;

        private int cacheFactor = 5;
        private XmlDocument XmlDoc = null;
        #endregion

        #region Properties
        public string FilesPath { get { return filesPath; } }
        public int CacheFactor { get { return cacheFactor; } }
        #endregion

        public SiteConfiguration()
        {

        }

        #region cnstr
        public SiteConfiguration(XmlDocument doc)
        {
            XmlDoc = doc;
            LoadValuesFromConfigurationXml();
        }
        #endregion

        #region GetXML

        /// <summary>
        /// Enables reading of the configuration file's XML without reloading the file
        /// </summary>
        /// <param name="nodePath"></param>
        /// <returns></returns>
        public XmlNode GetConfigSection(string nodePath)
        {
            return XmlDoc.SelectSingleNode(nodePath);
        }

        #endregion

        #region GetConfig
        public static SiteConfiguration GetConfig()
        {
            SiteConfiguration config = CacheHelper.Get(CacheKey) as SiteConfiguration;
            if (config == null)
            {
                string path = null;
                HttpContext context = HttpContext.Current;
                if (context != null)
                    path = context.Server.MapPath("~/HomeSite.config");
                else
                    path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "HomeSite.config");

                XmlDocument doc = new XmlDocument();
                doc.Load(path);
                config = new SiteConfiguration(doc);
                CacheHelper.Max(CacheKey, config, new CacheDependency(path));

                CacheHelper.ReSetFactor(config.CacheFactor);
            }
            return config;

        }

        #endregion

        // *********************************************************************
        //  LoadValuesFromConfigurationXml
        //
        /// <summary>
        /// Loads the forums configuration values.
        /// </summary>
        /// 
        // ***********************************************************************/
        internal void LoadValuesFromConfigurationXml()
        {
            XmlNode node = GetConfigSection("HomeSite/Core");

            XmlAttributeCollection attributeCollection = node.Attributes;

            XmlAttribute att = attributeCollection["cacheFactor"];
            if (att != null)
                cacheFactor = Int32.Parse(att.Value);
            else
                cacheFactor = 5;

            filesPath = "/";
        }
    }
}
