using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Text.RegularExpressions;
using System.Collections;
using System.IO;

namespace uni2uni.com.Framework.Web
{
    // *********************************************************************
    //  SiteHttpModule
    //
    /// <summary>
    /// This HttpModule encapsulates all the uni2uni related events that occur 
    /// during ASP.NET application start-up, errors, and end request.
    /// </summary>
    // ***********************************************************************/
    public class SiteHttpModule : IHttpModule
    {
        public static string SouceUrl = string.Empty;
        #region Member variables and inherited properties / methods

        public String ModuleName
        {
            get { return "SiteHttpModule"; }
        }


        #region IHttpModule
        // *********************************************************************
        //  ForumsHttpModule
        //
        /// <summary>
        /// Initializes the HttpModule and performs the wireup of all application
        /// events.
        /// </summary>
        /// <param name="application">Application the module is being run for</param>
        public void Init(HttpApplication application)
        {

            application.BeginRequest += new EventHandler(this.Application_BeginRequest);
            application.Error += new EventHandler(this.Application_Error);

        }

        public void Dispose()
        {
        }
        #endregion

        #endregion

        #region Application BeginRequest
        private void Application_BeginRequest(Object source, EventArgs e)
        {
            try
            {
                HttpApplication application = (HttpApplication)source;
                HttpContext context = application.Context;

                if (application == null || context == null)
                    return;

                SouceUrl = context.Request.Url.ToString();
                string newPath = null;

                string query = context.Request.Url.Query;
                int position = context.Request.Url.ToString().IndexOf("?");
                string path = (position == -1) ? context.Request.Url.ToString() : context.Request.Url.ToString().Substring(0, position);

                bool isReWritten = RewriteUrl(path, query, out newPath);

                if (isReWritten && newPath != null)
                    context.RewritePath(newPath);

                // Are the forums disabled?
                //
                //if (HttpContext.Current.Request.Url.Host != "localhost")
                //{
                //    SiteConfiguration SiteConfig = new SiteConfiguration();

                //    // Forums is disabled
                //    //
                //    //StreamReader reader = new StreamReader(context.Server.MapPath("/errors/SiteDisabled.htm"));
                //    //string html = reader.ReadToEnd();
                //    //reader.Close();

                //    //context.Response.Write(html);
                //    //context.Response.End();

                //}
            }
            catch (Exception ex)
            {
                Exception SiteEx = new Exception("Unknown error in BeginRequest", ex);
            }
        }

        #endregion

        #region Application_Error
        private void Application_Error(Object source, EventArgs e)
        {
        }
        #endregion

        #region URL��д����
        public static Regex ReWriteFilter = null;
        /// <summary>
        /// url��д����
        /// </summary>
        /// <param name="path"></param>
        /// <param name="queryString">queryStringֵ</param>
        /// <param name="newPath">����·��</param>
        /// <returns>bool</returns>
        public static bool RewriteUrl(string path, string queryString, out string newPath)
        {

            if (ReWriteFilter == null)
            {

                path = Regex.Replace(path, "aspx", "(aspx|html)", RegexOptions.IgnoreCase);


                ReWriteFilter = new Regex(path, RegexOptions.IgnoreCase | RegexOptions.Compiled);
            }

            //now, we walk through all of our ReWritable Urls and see if any match
            SiteUrls siteurl = Globals.GetSiteUrls();
            ArrayList urls = siteurl.ReWrittenUrls;
            if (urls.Count > 0)
            {
                foreach (ReWrittenUrl url in urls)
                {
                    if (url.IsMatch(path))
                    {
                        newPath = url.Convert(path, queryString);
                        return true;
                    }

                }
            }

            //Nothing found
            newPath = null;
            return false;
        }
        #endregion
    }
}
