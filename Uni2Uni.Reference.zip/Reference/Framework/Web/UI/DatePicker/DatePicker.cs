using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.Web.UI.Design;
using System.Drawing.Design;
using System.Drawing;
using System.Globalization;
using System.Text;

[assembly: WebResource("Uni2uni.Framework.Web.UI.DatePicker.DatePicker.js", "application/x-javascript")]
[assembly: WebResource("Uni2uni.Framework.Web.UI.DatePicker.DatePicker.css", "text/css")]
[assembly: WebResource("Uni2uni.Framework.Web.UI.DatePicker.Dropdownbtn.gif", "image/gif")]
namespace uni2uni.com.Framework.Web.UI.WebControls
{
    [ToolboxData("<{0}:DatePicker runat=\"server\" />")]
    [ValidationProperty("SelectedDate")]
    public sealed class DatePicker : WebControl, IPostBackDataHandler
    {
        #region = SelectedDate =
        /// <summary>
        /// Gets or sets the selected date.
        /// </summary>
        /// <remarks>
        /// Gets or sets the selected date.
        /// </remarks>
        /// <value>The selected date.</value>
        [DescriptionAttribute("Gets or sets the selected date."), DefaultValue(typeof(DateTime), "1/1/0001")]
        public DateTime SelectedDate
        {
            get
            {
                object o = this.ViewState["SelectedDate"];
                return o == null ? DateTime.MinValue : (DateTime)o;
            }
            set
            {
                this.ViewState["SelectedDate"] = value;
            }
        }
        #endregion

        #region IPostBackDataHandler Members

        #region = LoadPostData =
        /// <summary>
        /// When implemented by a class, processes postback data for an ASP.NET server control.
        /// </summary>
        /// <param name="postDataKey">The key identifier for the control.</param>
        /// <param name="postCollection">The collection of all incoming name values.</param>
        /// <returns>
        /// true if the server control's state changes as a result of the postback; otherwise, false.
        /// </returns>
        public bool LoadPostData(string postDataKey, System.Collections.Specialized.NameValueCollection postCollection)
        {
            string postdata = postCollection[this.ClientID + "_input"];

            DateTime dt;
            if (DateTime.TryParse(postdata, out dt) == true)
            {
                this.SelectedDate = dt;
            }
            return false;
        }

        #endregion

        #region = RaisePostDataChangedEvent =
        /// <summary>
        /// When implemented by a class, signals the server control to notify the ASP.NET application that the state of the control has changed.
        /// </summary>
        public void RaisePostDataChangedEvent()
        {

        }
        #endregion

        #endregion

        #region = OnPreRender =
        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.PreRender"></see> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnPreRender(EventArgs e)
        {
            if (string.IsNullOrEmpty(this.ID) == true)
            {
                throw new Exception("��������һ��ID");
            }

            base.OnPreRender(e);

            this.Page.RegisterRequiresPostBack(this);

            

            if (this.Page != null)
            {
                this.Page.ClientScript.RegisterClientScriptResource(this.GetType(), "Uni2uni.Framework.Web.UI.DatePicker.DatePicker.js");
            }

            string cssKey = "DatePickerCss";

            if (this.Page.Header.FindControl(cssKey) == null)
            {
                HtmlLink hl = new HtmlLink();
                hl.ID = cssKey;
                hl.Href = this.Page.ClientScript.GetWebResourceUrl(this.GetType(), "Uni2uni.Framework.Web.UI.DatePicker.DatePicker.css");
                hl.Attributes["text"] = "text/css";
                hl.Attributes["rel"] = "stylesheet";

                this.Page.Header.Controls.Add(hl);
            }
        }
        #endregion

        #region = RenderContents =
        /// <summary>
        /// Renders the contents of the control to the specified writer. This method is used primarily by control developers.
        /// </summary>
        /// <param name="writer">A <see cref="T:System.Web.UI.HtmlTextWriter"></see> that represents the output stream to render HTML content on the client.</param>
        protected override void RenderContents(HtmlTextWriter writer)
        {
            base.RenderContents(writer);

            string calendar_input = this.ClientID + "_input";
            string calendar_div = this.ClientID + "_div";
            string clientclick = "show_calendar('" + calendar_input + "','" + calendar_div + "')";

            writer.AddStyleAttribute(HtmlTextWriterStyle.BorderWidth, "0px");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellpadding, "0");
            writer.AddAttribute(HtmlTextWriterAttribute.Cellspacing, "0");
            writer.RenderBeginTag(HtmlTextWriterTag.Table);
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);
            //Left td
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            RanderInput(writer, clientclick);
            writer.RenderEndTag();
            //Right td
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            RanderImages(writer, clientclick);
            writer.RenderEndTag();

            writer.RenderEndTag();
            writer.RenderEndTag();

            writer.AddAttribute(HtmlTextWriterAttribute.Id, calendar_div);
            writer.AddStyleAttribute(HtmlTextWriterStyle.Position, "absolute");
            writer.RenderBeginTag(HtmlTextWriterTag.Div);
            writer.RenderEndTag();
        } 

        private void RanderInput(HtmlTextWriter writer, string clientclick)
        {
            string calendar_input = this.ClientID + "_input";
            string calendar_div = this.ClientID + "_div";

            writer.AddAttribute(HtmlTextWriterAttribute.Onclick, clientclick);
            writer.AddAttribute(HtmlTextWriterAttribute.Type, "text");

            if (this.Width != Unit.Empty)
            {
                writer.AddStyleAttribute(HtmlTextWriterStyle.Width, this.Width.ToString());
            }

            writer.AddAttribute(HtmlTextWriterAttribute.Name, calendar_input);
            writer.AddAttribute(HtmlTextWriterAttribute.Id, calendar_input);

            if (this.SelectedDate != DateTime.MinValue)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Value, this.SelectedDate.ToShortDateString());
            }
            writer.RenderBeginTag(HtmlTextWriterTag.Input);
            writer.RenderEndTag();
        }

        private void RanderImages(HtmlTextWriter writer, string clientclick)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Onclick, clientclick);
            writer.AddStyleAttribute(HtmlTextWriterStyle.Cursor, "pointer");
            writer.AddAttribute(HtmlTextWriterAttribute.Src, this.Page.ClientScript.GetWebResourceUrl(this.GetType(), "Uni2uni.Framework.Web.UI.DatePicker.Dropdownbtn.gif"));
            writer.RenderBeginTag(HtmlTextWriterTag.Img);
            writer.RenderEndTag();
        }
        #endregion
    }
}
