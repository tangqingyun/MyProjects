﻿/*
4 The month you wish to display, where 1=January, and 12=December. 
2003 The year you wish to display. 
main Name of the CSS class to style the calendar's outermost table.  
month Name of the CSS class to style the calendar's month/year bar.  
daysofweek Name of the CSS class to style the calendar's week days row  
days Name of the CSS class to style the individual days cells.  
0 The thickness of the border between all cells. 0=no border. 
*/
function buildCal(m, y, cM, cH, cDW, cD,input,out){
//var mn=['January','February','March','April','May','June','July','August','September','October','November','December'];
var mn=['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月']
var dim=[31,0,31,30,31,30,31,31,30,31,30,31];

var oD = new Date(y, m-1, 1); //DD replaced line to fix date bug when current day is 31st
oD.od=oD.getDay()+1; //DD replaced line to fix date bug when current day is 31st

var todaydate=new Date() //DD added
var scanfortoday=(y==todaydate.getFullYear() && m==todaydate.getMonth()+1)? todaydate.getDate() : 0 //DD added

dim[1]=(((oD.getFullYear()%100!=0)&&(oD.getFullYear()%4==0))||(oD.getFullYear()%400==0))?29:28;
var t='<div class="'+cM+'"><table class="'+cM+'" cols="7" cellpadding="0" cellspacing="0"><tr align="center">';

t+='<tr>';
t+="<td class=\""+cH+"\" onclick=\"updatecalendar_date("+(y-1)+","+m+",'"+input+"','"+out+"')\">&lt;&lt;</td>"; //后退一年
var tm = m-1;
var ty = y;

if(tm == 0)
{
    ty--;
    tm = 12;
}
t+="<td class=\""+cH+"\" onclick=\"updatecalendar_date("+ty+","+tm+",'"+input+"','"+out+"')\">&lt;</td>"; //后退一月
t+='<td colspan="3" class="'+cH+'" style="font-size: 12px;cursor:default">'+y+'&nbsp;&nbsp;&nbsp;&nbsp;'+mn[m-1]+'</td>';
var tm = m+1;
var ty = y;

if(tm == 13)
{
    ty++;
    tm = 1;
}
t+="<td class=\""+cH+"\" onclick=\"updatecalendar_date("+ty+","+tm+",'"+input+"','"+out+"')\">&gt;</td>"; //前进一月
t+="<td class=\""+cH+"\" onclick=\"updatecalendar_date("+(y+1)+","+m+",'"+input+"','"+out+"')\">&gt;&gt;</td>"; //前进一年
t+='</tr>';


t+='<tr>';
for(s=0;s<7;s++)t+='<td class="'+cDW+'">'+"日一二三四五六".substr(s,1)+'</td>';
t+='</tr><tr align="center">';
for(i=1;i<=39;i++)
{
    var x=((i-oD.od>=0)&&(i-oD.od<dim[m-1]))? i-oD.od+1 : '&nbsp;';

    if (x==scanfortoday) //DD added
    {
        x='<span id="today">'+x+'</span>' //Today
    }
    
    t+="<td class=\""+cD+"\" ";
    if(x!="&nbsp;")
    {
        t+="onclick=\"calendar_select(this,"+y+","+m+",'"+input+"','"+out+"')\" ";
        t+="onmouseover=\"style.backgroundColor='#D7E1F0'\" ";
        t+="onmouseout=\"style.backgroundColor='lightyellow'\" ";
    }
    t+=">"+x+'</td>';
if(((i)%7==0)&&(i<36))t+='</tr><tr>';
}
t+="<td colspan=\"3\" class=\""+cD+"\" onclick=\"calendar_close('"+out+"');\">关闭</td>";
return t+'</tr></table></div>';
}

function updatecalendar_date(curyear,curmonth,input,out)
{
    var calendarstr=buildCal(curmonth, curyear, "main", "month", "daysofweek", "days",input,out);
    if (document.getElementById)
    {
        document.getElementById(out).innerHTML=calendarstr;
    }
}

function updatecalendar(sdate,input,out)
{
    var curmonth=sdate.getMonth()+1;
    var curyear=sdate.getFullYear();
    
    updatecalendar_date(curyear,curmonth,input,out)
}

function calendar_close(out)
{
    document.getElementById(out).style.display = "none";
}

function show_calendar(input,out)
{
    var e = document.getElementById(input);
    
    var d_array = e.value.split('-');
    
    //初始化时间
    var sdate = new Date();
    if(d_array.length == 3)
    {
        try{
            sdate = new Date(parseInt(d_array[0]),parseInt(d_array[1])-1,parseInt(d_array[2]));
        }catch(e){}        
    }
            
    updatecalendar(sdate,input,out);
    
    var ttop  = e.offsetTop;     //TT控件的定位点高
    var thei  = e.clientHeight;  //TT控件本身的高
	var tleft = e.offsetLeft;    //TT控件的定位点宽
	
	while (e = e.offsetParent){ttop+=e.offsetTop; tleft+=e.offsetLeft;}
	
	
	document.getElementById(out).style.left = tleft;
	document.getElementById(out).style.top = ttop+thei + 2;
    document.getElementById(out).style.display = "block";
}

function calendar_select(e,y,m,input,out)
{
    while(e.childNodes[0].tagName == "SPAN")
    {
        e = e.childNodes[0];
    }
    var day = e.innerHTML;
    var r=/^\d{1,2}$/ig;
    if(r.test(day)==true)
    {
        document.getElementById(input).value = y+"-"+m+"-"+day;
    }
    
    calendar_close(out);
}


