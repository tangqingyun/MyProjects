﻿function addListener(element,e,fn)
  { 
     if(element.addEventListener)
	 { 
		element.addEventListener(e,fn,false); 
     } 
	 else 
	 { 
		element.attachEvent("on" + e,fn); 
     } 
  } 



  addListener(document,"click",function(evt)
  { 
      var evt = window.event?window.event:evt,target=evt.srcElement||evt.target; 
      if(target.id == "PlaneTicketCity")
	  { 
	  pop_is_menu("PlaneTicketCity","pop_PlaneTicketCity_divId","PlaneTicketCity_fram_bk")
			document.getElementById("pop_PlaneTicketCity_divId").style.display = "";
			document.getElementById("PlaneTicketCity_fram_bk").style.display = "";
			return; 
      }
	  else
	  { 
            while(target.nodeName.toLowerCase() != "div" && target.nodeName.toLowerCase() != "html")
			{ 
                 target = target.parentNode;         
            } 
            if(target.nodeName.toLowerCase() == "html")
			{ 
                 document.getElementById("pop_PlaneTicketCity_divId").style.display = "none"; 
				 document.getElementById("PlaneTicketCity_fram_bk").style.display = "none";
				 document.getElementById("pop_UserInPut_divId").style.display = "none"; 
				 document.getElementById("UserInPut_fram_bk").style.display = "none";
            } 
                         
                     
                }             
        }) 	 
        function pop_is_menu(objId,divId,iframeId)
{ 
  var p = getObj_Point(getId_obj(objId));
  
  if (document.all)
  {
    with (getId_obj(iframeId).style)
    {
      top = p.y+"px";
      left = p.x+"px";

    }
  }
  
  with (getId_obj(divId).style){

    top = p.y+"px";
    left = p.x+"px";
  }
  
}


//直接得到控件坐标,传控件对象过来
function getObj_Point(o){
   var point=new Object();
   point.x=o.offsetLeft;
   point.y=o.offsetTop+o.offsetHeight;
   while(o=o.offsetParent){
     point.x+=o.offsetLeft;
     point.y+=o.offsetTop;
   }
   return point;
}

 
//得到ID对象
function getId_obj(obj_Id){
	try{
	
			if(document.getElementById(obj_Id)!=null){
				return document.getElementById(obj_Id);
			}else{
				
				return null;
			}
			
	}catch(e){
		
		return null;
	}
	
}




function SelectCity(id,name)
{
    document.getElementById("PlaneTicketCity").value=name;
	document.getElementById("PlaneTicketCityId").value=id;
	//hide(var1,var2);
}


/*
ajax
*/

var xmlHttp;



function createXMLHTTP()
{
    if(window.XMLHttpRequest)
    {
        xmlHttp=new XMLHttpRequest();//mozilla浏览器
    }
    else if(window.ActiveXObject)
    {
        try
        {
        
            xmlHttp=new ActiveXObject("Msxml3.XMLHTTP");
        }
        catch(e)
        {}
        try
        {
            xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");//IE老版本
        }
        catch(e)
        {}
        try
        {
            xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");//IE新版本
        }
        catch(e)
        {}
        if(!xmlHttp)
        {
            alert("不能创建XMLHttpRequest对象实例！");
            return false;
        }
    }
}

//通过用户输入得到结果
function GetInPut(userinput)
{
    document.getElementById("pop_PlaneTicketCity_divId").style.display = "none"; 
	document.getElementById("PlaneTicketCity_fram_bk").style.display = "none";
    createXMLHTTP();//创建XMLHttpRequest对象
    
    var url="CitySearchTest.aspx?userinput="+userinput;
    xmlHttp.open("post",url,true);
    xmlHttp.onreadystatechange=GetCity;
    xmlHttp.send(null);
}

//执行检测用户名回调函数
function GetCity()
{ 
    if(xmlHttp.readyState==4)//判断对象状态
    {
        if(xmlHttp.status==200)//信息成功返回，开始处理信息
        {
            document.getElementById("PlaneTicketCity_divId").value = "";
            document.getElementById("pop_UserInPut_divId").style.display = ""; 
			document.getElementById("UserInPut_fram_bk").style.display = "";
            document.getElementById("pop_UserInPut_divId").innerHTML=xmlHttp.responseText;     
        }
        
    }
    else
    {
         document.getElementById("pop_UserInPut_divId").innerHTML="查找中。"; 
    }
}