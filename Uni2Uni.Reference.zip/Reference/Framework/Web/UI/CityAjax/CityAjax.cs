﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.Web.UI.Design;
using System.Drawing.Design;
using System.Drawing;
using System.Globalization;
using System.Text;

[assembly: WebResource("Uni2uni.Framework.Web.UI.CityAjax.CityAjax.js", "application/x-javascript")]
namespace uni2uni.com.Framework.Web.UI.CityAjax
{
    [ToolboxData("<{0}:DatePicker runat=\"server\" />")]
    public sealed class CityAjax  : WebControl
    {
        #region = OnPreRender =
        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.PreRender"></see> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            string cssKey = "PageBarCss";

            if (this.Page == null || this.Page.Header == null)
            {
                return;
            }
            if (string.IsNullOrEmpty(this.CssClass) == true)
            {
                this.CssClass = "PageBar";
            }
            if (this.Page.Header.FindControl(cssKey) == null && this.CssClass == "PageBar")
            {
                string css = this.Page.ClientScript.GetWebResourceUrl(this.GetType(), "Uni2uni.Framework.Web.UI.PageBar.PageBar.css");

                HtmlLink hl = new HtmlLink();
                hl.ID = cssKey;
                hl.Href = css;
                hl.Attributes["type"] = "text/css";
                hl.Attributes["rel"] = "stylesheet";

                this.Page.Header.Controls.Add(hl);

                this.CssClass = "PageBar";
            }
        }
        #endregion
    }
}
