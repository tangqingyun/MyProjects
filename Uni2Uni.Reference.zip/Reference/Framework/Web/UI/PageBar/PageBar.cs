using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.ComponentModel;
using System.Text.RegularExpressions;
using System.Web.UI.HtmlControls;

[assembly: WebResource("Uni2uni.Framework.Web.UI.PageBar.PageBar.css", "text/css", PerformSubstitution = true)]
namespace uni2uni.com.Framework.Web.UI.WebControls
{
    public enum PageBarMode
    {
        Get,
        Post
    }

    #region - PageBar -
    /// <summary>
    /// ��ҳ�ؼ�
    /// </summary>
    [ToolboxData("<{0}:PageBar runat=\"server\" />")]
    [DefaultEvent("Click")]
    [DefaultProperty("Size")]
    public sealed class PageBar : WebControl, IPostBackEventHandler
    {
        #region - Properties -
        #region = Total =
        /// <summary>
        /// �ܹ��ж��ټ�¼����
        /// </summary>
        /// <value>The total.</value>
        [Category("Data"), DescriptionAttribute("�ܹ��ж��ټ�¼����")]
        public int Total
        {
            get
            {
                object o = this.ViewState["Total"];
                return o == null ? 0 : (int)o;
            }
            set
            {
                this.ViewState["Total"] = value;
            }
        }
        #endregion

        #region = CurrentIndex =
        /// <summary>
        /// ��ǰʹ�õ�ҳ��
        /// </summary>
        /// <value>The index of the current.</value>
        [Category("Data"), DescriptionAttribute("��ǰʹ�õ�ҳ��")]
        public int CurrentIndex
        {
            get
            {
                object o = this.ViewState["CurrentIndex"];
                int _currentindex = ((o == null) ? 0 : (int)o);
                if (_currentindex == 0)
                {
                    _currentindex = 1;

                     if (string.IsNullOrEmpty(this.UrlFormatString) == false)
                    {
                        string url = this.Page.Request.Url.ToString();
                        string urlformat = string.Format(this.UrlFormatString, @"(\d+)");
                        urlformat = urlformat.Replace("?", "\\?");
                        urlformat = Regex.Replace(urlformat, "#.+$", string.Empty);

                        Match m = Regex.Match(url, urlformat, RegexOptions.IgnoreCase);

                        if (m.Success == true)
                        {
                            string value = m.Groups[1].Value;
                            if (string.IsNullOrEmpty(value) == false)
                            {
                                _currentindex = int.Parse(value);
                            }
                        }
                    }
                    else
                    {
                        if (this.Page.Request.QueryString[this.QueryStringKey] != null)
                        {
                            int.TryParse(this.Page.Request.QueryString[this.QueryStringKey], out _currentindex);
                        }
                    }
                }
                return _currentindex;
            }
            set { this.ViewState["CurrentIndex"] = value; }
        }
        #endregion

        #region = Size =
        /// <summary>
        /// ÿ��ҳ����ʾ���ټ�¼����
        /// </summary>
        /// <value>The size.</value>
        [Category("Data"), DescriptionAttribute("ÿ��ҳ����ʾ���ټ�¼����")]
        public int Size
        {
            get
            {
                object o = this.ViewState["Size"];
                return o == null ? 10 : (int)o;
            }
            set
            {
                this.ViewState["Size"] = value;
            }
        }
        #endregion

        #region = Displaysize =
        /// <summary>
        /// ��ʾҳ��,�ؼ���ʾ����ҳ����
        /// </summary>
        /// <value>The displaysize.</value>
        [Category("Data"), DescriptionAttribute("�ؼ���ʾ����ҳ����")]
        public int Displaysize
        {
            get
            {
                object o = this.ViewState["Displaysize"];
                return o == null ? 10 : (int)o;
            }
            set
            {
                this.ViewState["Displaysize"] = value;
            }
        }
        #endregion

        #region = Unit =
        /// <summary>
        /// ��¼�ĵ�λ
        /// </summary>
        /// <value>The unit.</value>
        [Category("Appearance"), DescriptionAttribute("��¼�ĵ�λ")]
        public string Unit
        {
            get
            {
                object o = this.ViewState["Unit"];
                return o == null ? string.Empty : (string)o;
            }
            set
            {
                this.ViewState["Unit"] = value;
            }
        }
        #endregion

        #region = UrlFormatString =
        [
        Category("Property"),
        Description("��ȡ������ URL ��ʾ��ʽ��"),
        DefaultValue("")
        ]
        public string UrlFormatString
        {
            get
            {
                object o = this.ViewState["UrlFormatString"];
                return o == null ? string.Empty : (string)o;
            }
            set
            {
                this.ViewState["UrlFormatString"] = value;
            }
        }
        #endregion

        #region = QueryStringKey =
        /// <summary>
        /// ����ֵ��ʹ�õĹؼ���
        /// </summary>
        /// <value>The query string key.</value>
        [DescriptionAttribute("����ֵ��ʹ�õĹؼ���"), DefaultValue("page")]
        public string QueryStringKey
        {
            get
            {
                object o = this.ViewState["QueryStringKey"];
                return o == null ? "page" : (string)o;
            }
            set
            {
                this.ViewState["QueryStringKey"] = value;
            }
        }
        #endregion

        #region = Format =
        /// <summary>
        /// ���ָ�ʽ��
        /// </summary>
        /// <value>The format.</value>
        [DescriptionAttribute("���ָ�ʽ��"), DefaultValue("")]
        public string Format
        {
            get
            {
                object o = this.ViewState["Format"];
                return o == null ? string.Empty : (string)o;
            }
            set
            {
                this.ViewState["Format"] = value;
            }
        }
        #endregion

        #region = NextPageImageUrl =
        /// <summary>
        /// ��һҳͼƬ·��
        /// </summary>
        /// <value>The next page image URL.</value>
        [DescriptionAttribute("��һҳͼƬ·��"), DefaultValue("")]
        public string NextPageImageUrl
        {
            get
            {
                object o = this.ViewState["NextPageImageUrl"];
                return o == null ? string.Empty : (string)o;
            }
            set
            {
                this.ViewState["NextPageImageUrl"] = value;
            }
        }
        #endregion

        #region = LastPageImageUrl =
        private string _lastimage = string.Empty;
        /// <summary>
        /// ��һҳͼƬ·��
        /// </summary>
        /// <value>The last page image URL.</value>
        [DescriptionAttribute("��һҳͼƬ·��"), DefaultValue("")]
        public string LastPageImageUrl
        {
            get
            {
                object o = this.ViewState["LastPageImageUrl"];
                return o == null ? string.Empty : (string)o;
            }
            set
            {
                this.ViewState["LastPageImageUrl"] = value;
            }
        }
        #endregion

        #region = Mode =
        [
        Category("Property"),
        Description("Pagebar��ģʽ"),
        DefaultValue("")
        ]
        public PageBarMode Mode
        {
            get
            {
                object o = this.ViewState["Mode"];
                return o == null ? PageBarMode.Get : (PageBarMode)o;
            }
            set
            {
                this.ViewState["Mode"] = value;
            }
        }
        #endregion

        #region = ValidationGroup =
        [Category("Behavior"), DefaultValue(""), Themeable(false), Description("PostBackControl_ValidationGroup")]
        public string ValidationGroup
        {
            get
            {
                string text1 = (string)this.ViewState["ValidationGroup"];
                if (text1 != null)
                {
                    return text1;
                }
                return string.Empty;
            }
            set
            {
                this.ViewState["ValidationGroup"] = value;
            }
        }
        #endregion

        #region = CausesValidation =
        /// <summary>
        /// ��ȡ������һ��ֵ����ֵָʾ�ڵ��� LinkButton �ؼ�ʱ�Ƿ�ִ����֤�� 
        /// </summary>
        /// <value><c>true</c> if [causes validation]; otherwise, <c>false</c>.</value>
        [Category("Behavior"), Themeable(false), Description("Button_CausesValidation"), DefaultValue(true)]
        public bool CausesValidation
        {
            get
            {
                object obj1 = this.ViewState["CausesValidation"];
                if (obj1 != null)
                {
                    return (bool)obj1;
                }
                return true;
            }
            set
            {
                this.ViewState["CausesValidation"] = value;
            }
        }
        #endregion

        #region = Target =
        /// <summary>
        /// Gets or sets the target.
        /// </summary>
        /// <value>The target.</value>
        [
        Category("Navigation"),
        TypeConverter(typeof(TargetConverter)),
        DefaultValue(""),
        Description("HyperLink_Target")]
        public string Target
        {
            get
            {
                string text1 = (string)this.ViewState["Target"];
                if (text1 != null)
                {
                    return text1;
                }
                return "_self";
            }
            set
            {
                this.ViewState["Target"] = value;
            }
        }
        #endregion

        #endregion

        #region - Event -

        #region = OnClick =
        private static readonly object EventClick = new object();
        [Description("PageBar_OnClick"), Category("Action")]
        public event EventHandler Click
        {
            add
            {
                Events.AddHandler(EventClick, value);
            }
            remove
            {
                Events.RemoveHandler(EventClick, value);
            }
        }
        #endregion

        #endregion

        #region = OnPreRender =
        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.PreRender"></see> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            string cssKey = "PageBarCss";

            if (this.Page == null || this.Page.Header == null)
            {
                return;
            }
            if (string.IsNullOrEmpty(this.CssClass) == true)
            {
                this.CssClass = "PageBar";
            }
            if (this.Page.Header.FindControl(cssKey) == null && this.CssClass == "PageBar")
            {
                string css = this.Page.ClientScript.GetWebResourceUrl(this.GetType(), "Uni2uni.Framework.Web.UI.PageBar.PageBar.css");

                HtmlLink hl = new HtmlLink();
                hl.ID = cssKey;
                hl.Href = css;
                hl.Attributes["type"] = "text/css";
                hl.Attributes["rel"] = "stylesheet";

                //this.Page.Header.Controls.Add(hl);

                this.CssClass = "PageBar";
            }
        }
        #endregion

        #region = RenderContents =
        /// <summary>
        /// Renders the contents of the control to the specified writer. This method is used primarily by control developers.
        /// </summary>
        /// <param name="writer">A <see cref="T:System.Web.UI.HtmlTextWriter"></see> that represents the output stream to render HTML content on the client.</param>
        protected override void RenderContents(HtmlTextWriter writer)
        {
            base.RenderContents(writer);

            #region - Valid -
            if (this.IsEnabled == false)
            {
                return;
            }

            if (this.Size == 0 || this.Displaysize == 0)
            {
                return;
            }
            #endregion

            if (this.Total > 0 && this.CurrentIndex > 0)
            {
                double dPageCount = 1.0 * this.Total / this.Size;
                int PageCount = Convert.ToInt32(Math.Ceiling(dPageCount)); //������ҳ

                if (this.CurrentIndex > PageCount)
                {
                    this.CurrentIndex = PageCount;
                }

                //�ܹ�2784����
                writer.Write(PageBarResource.Total);
                //writer.Write("�ܹ�");
                writer.Write(" ");
                writer.RenderBeginTag(HtmlTextWriterTag.Label);
                writer.Write(this.Total.ToString(this.Format));
                writer.RenderEndTag();
                writer.Write(this.Unit);
                writer.Write(", ");

                writer.Write(PageBarResource.Page);
                //writer.Write("��ǰ");
                writer.Write(" ");
                writer.RenderBeginTag(HtmlTextWriterTag.Label);
                writer.Write(this.CurrentIndex.ToString(this.Format));
                writer.RenderEndTag();
                writer.Write("/");
                writer.RenderBeginTag(HtmlTextWriterTag.Label);
                writer.Write(PageCount.ToString(this.Format));
                writer.RenderEndTag();

                if (PageCount > 1)
                {
                    writer.Write(",");
                    int PagerGroup = Convert.ToInt32(Math.Ceiling(1.0 * PageCount / this.Displaysize)); //������ҳ��
                    int CurrentGroup = (this.CurrentIndex - 1) / this.Displaysize + 1; //��ǰҳ��

                    int displaystart = (CurrentGroup - 1) * this.Displaysize + 1;
                    int displayend = displaystart + this.Displaysize;

                    if (displayend > (PageCount + 1))
                    {
                        displayend = PageCount + 1;
                    }


                    //��һҳ
                    if (this.CurrentIndex > 1)
                    {
                        writer.RenderBeginTag(HtmlTextWriterTag.Span);
                        if (string.IsNullOrEmpty(this.LastPageImageUrl) == true)
                        {
                            LinkText(PageBarResource.Previous, this.CurrentIndex - 1, writer);
                            //LinkText("����һҳ��", this.CurrentIndex - 1, writer);
                        }
                        else
                        {
                            LinkText("<img alt=\"" + PageBarResource.Previous + "\" src=\"" + this.LastPageImageUrl + "\" />", this.CurrentIndex - 1, writer);
                            //LinkText("<img alt=\"" +"����һҳ��" + "\" src=\"" + this.LastPageImageUrl + "\" />", this.CurrentIndex - 1, writer);
                        }
                        writer.RenderEndTag();
                    }

                    //��һ��
                    if (CurrentGroup > 1)
                    {
                        LinkText("&lt;&lt;", displaystart - 1, writer);
                    }
                    string attr = string.Empty;

                    //��ʾ����
                    for (int i = displaystart; i < displayend; i++)
                    {
                        writer.RenderBeginTag(HtmlTextWriterTag.Span);
                        if (i != this.CurrentIndex)
                        {

                            LinkText(i.ToString(), i, writer);

                        }
                        else
                        {
                            //��ǰҳ
                            writer.RenderBeginTag(HtmlTextWriterTag.Label);
                            writer.Write("&nbsp;" + i + "&nbsp;");
                            writer.RenderEndTag();

                        }
                        writer.RenderEndTag();
                    }

                    //��һ��
                    if (CurrentGroup < PagerGroup)
                    {

                        LinkText("&gt;&gt;", displayend, writer);
                    }

                    //��һҳ
                    if (this.CurrentIndex < PageCount)
                    {
                        writer.RenderBeginTag(HtmlTextWriterTag.Span);
                        if (string.IsNullOrEmpty(this.NextPageImageUrl) == true)
                        {
                            LinkText(PageBarResource.Next, this.CurrentIndex + 1, writer);
                            //LinkText("����һҳ��", this.CurrentIndex + 1, writer);
                        }
                        else
                        {
                            LinkText("<img alt=\"" + PageBarResource.Next + "\" src=\"" + this.NextPageImageUrl + "\" />", this.CurrentIndex + 1, writer);
                            //LinkText("<img alt=\"" + "����һҳ��" + "\" src=\"" + this.NextPageImageUrl + "\" />", this.CurrentIndex + 1, writer);
                        }
                        writer.RenderEndTag();
                    }
                }
            }
            else
            {
                this.Visible = false;
            }
        }
        #endregion

        #region - LinkText -
        private void LinkText(string text, int index, HtmlTextWriter write)
        {

            StringBuilder strHtml = new StringBuilder();
            //href
            if (this.Mode == PageBarMode.Get)
            {
                #region = ��ȡ�ͽ�����ǰ��url =
                if (string.IsNullOrEmpty(this.UrlFormatString) == true)
                {
                    strHtml.Append(UrlHelper.Current.Path);
                    strHtml.Append("?");
                    System.Collections.Specialized.NameValueCollection querys = this.Page.Request.QueryString;

                    foreach (string s in querys.Keys)
                    {
                        if (s != this.QueryStringKey)
                        {
                            strHtml.AppendFormat("{0}={1}&", s, this.Page.Server.UrlEncode(querys[s]));
                        }
                    }

                    strHtml.AppendFormat("{0}={1}", this.QueryStringKey, index);
                }
                else
                {
                    strHtml.AppendFormat(this.UrlFormatString, index);
                }
                #endregion
            }
            else
            {

                PostBackOptions options = GetPostBackOptions(index);

                string js = null;
                if (options != null)
                {
                    js = this.Page.ClientScript.GetPostBackEventReference(options, true);
                }
                if (string.IsNullOrEmpty(js) == true)
                {
                    js = "javascript:void(0)";
                }
                strHtml.Append(js);
            }

            //text
            write.AddAttribute(HtmlTextWriterAttribute.Href, strHtml.ToString());
            if (this.Mode == PageBarMode.Get)
            {
                write.AddAttribute(HtmlTextWriterAttribute.Target, this.Target);
            }
            write.Write("&nbsp;");

            write.RenderBeginTag(HtmlTextWriterTag.A);
            write.Write(text );
            write.RenderEndTag();
            write.Write("&nbsp;");

        }
        #endregion

        #region - GetPostBackOptions -
        private PostBackOptions GetPostBackOptions(int index)
        {
            PostBackOptions options1 = new PostBackOptions(this, index.ToString());
            options1.RequiresJavaScriptProtocol = true;

            if (this.CausesValidation && (this.Page.GetValidators(this.ValidationGroup).Count > 0))
            {
                options1.PerformValidation = true;
                options1.ValidationGroup = this.ValidationGroup;
            }
            return options1;
        }
        #endregion

        #region - OnClick -
        private void OnClick(EventArgs e)
        {
            EventHandler handler1 = (EventHandler)base.Events[EventClick];
            if (handler1 != null)
            {
                handler1(this, e);
            }
        }
        #endregion

        #region IPostBackEventHandler Members

        public void RaisePostBackEvent(string eventArgument)
        {
            if (this.CausesValidation)
            {
                this.Page.Validate(this.ValidationGroup);
            }

            int _currentindex;
            if (int.TryParse(eventArgument, out _currentindex))
            {
                this.CurrentIndex = _currentindex;
            }

            this.OnClick(EventArgs.Empty);
        }

        #endregion
    }
    #endregion
}
