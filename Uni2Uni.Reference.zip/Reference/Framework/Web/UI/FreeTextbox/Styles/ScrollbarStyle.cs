using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Resources;
using System.Collections;
using System.Collections.Specialized;
using System.Text;
using System.Drawing;
using FreeTextBoxControls.Common;

namespace FreeTextBoxControls {
	/// <summary>
	/// Contains all the style parameters for ToolbarButtons
	/// </summary>
	public class ScrollbarStyle : Style {
		public ScrollbarStyle() {}

		public ScrollbarStyle(Color threeDLightColor,Color arrowColor,Color baseColor,Color darkShadowColor,Color faceColor,Color highlightColor,Color shadowColor,Color trackColor) {
			ViewState["ThreeDLightColor"] = threeDLightColor;
			ViewState["ArrowColor"] = arrowColor;
			ViewState["BaseColor"] = baseColor;
			ViewState["DarkShadowColor"] = darkShadowColor;
			ViewState["FaceColor"] = faceColor;
			ViewState["HighlightColor"] = highlightColor;
			ViewState["ShadowColor"] = shadowColor;
			ViewState["TrackColor"] = trackColor;
		}
		/// <summary>
		/// The color of the top and left edges of the scroll box and scroll arrows of a scroll bar.
		/// </summary>	
		[
		NotifyParentProperty(true)
		]
		public Color ThreeDLightColor {
			get { 				
				object savedState = this.ViewState["ThreeDLightColor"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["ThreeDLightColor"] = value;}
		}
		/// <summary>
		/// The color of the arrow elements of a scroll arrow.
		/// </summary>		
		[
		NotifyParentProperty(true)
		]
		public Color ArrowColor {
			get { 
				object savedState = this.ViewState["ArrowColor"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set {
				ViewState["ArrowColor"] = value;
			}
		}
		/// <summary>
		/// The color of the main elements of a scroll bar, which include the scroll box, track, and scroll arrows
		/// </summary>	
		[
		NotifyParentProperty(true)
		]
		public Color BaseColor {
			get { 				
				object savedState = this.ViewState["BaseColor"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["BaseColor"] = value;}
		}
		/// <summary>
		/// The color of the gutter of a scroll bar.
		/// </summary>	
		[
		NotifyParentProperty(true)
		]
		public Color DarkShadowColor {
			get { 				
				object savedState = this.ViewState["DarkShadowColor"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["DarkShadowColor"] = value;}
		}
		/// <summary>
		/// The color of the scroll box and scroll arrows of a scroll bar.
		/// </summary>	
		[
		NotifyParentProperty(true)
		]
		public Color FaceColor {
			get { 
				object savedState = this.ViewState["FaceColor"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["FaceColor"] = value;}
		}
		/// <summary>
		/// The color of the top and left edges of the scroll box and scroll arrows of a scroll bar.
		/// </summary>		
		[
		NotifyParentProperty(true)
		]
		public Color HighlightColor {
			get { 				
				object savedState = this.ViewState["HighlightColor"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["HighlightColor"] = value;}
		}
		/// <summary>
		/// The color of the bottom and right edges of the scroll box and scroll arrows of a scroll bar.
		/// </summary>	
		[
		NotifyParentProperty(true)
		]
		public Color ShadowColor {
			get { 				
				object savedState = this.ViewState["ShadowColor"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["ShadowColor"] = value;}
		}
		/// <summary>
		/// The color of the track.
		/// </summary>	
		[
		NotifyParentProperty(true)
		]
		public Color TrackColor {
			get { 				
				object savedState = this.ViewState["TrackColor"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["TrackColor"] = value;}
		}
	}	
}
