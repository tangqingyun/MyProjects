using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Resources;
using System.Collections;
using System.Collections.Specialized;
using System.Text;
using System.Drawing;
using FreeTextBoxControls.Common;

namespace FreeTextBoxControls {	
	/// <summary>
	/// Contains all the style parameters for ToolbarButtons
	/// </summary>
	public class ToolbarButtonStyle : Style {
		/// <summary>
		/// Empty constructor
		/// </summary>			
		public ToolbarButtonStyle() {}

		/// <summary>
		/// Constructor for colors only
		/// </summary>
		public ToolbarButtonStyle(Color borderColorLight,Color borderColorDark,Color overBackColor,Color overBorderColorLight,Color overBorderColorDark,Color downBackColor,Color downBorderColorLight,Color downBorderColorDark) {
			ViewState["BorderColorLight"] = borderColorLight;
			ViewState["BorderColorDark"] = borderColorDark;
			ViewState["OverBackColor"] = overBackColor;
			ViewState["OverBorderColorLight"] = overBorderColorLight;
			ViewState["OverBorderColorDark"] = overBorderColorDark;
			ViewState["DownBackColor"] = downBackColor;
			ViewState["DownBorderColorLight"] = downBorderColorLight;
			ViewState["DownBorderColorDark"] = downBorderColorDark;
		}
		/// <summary>
		/// Constructor with colors and images
		/// </summary>
		public ToolbarButtonStyle(Color borderColorLight,Color borderColorDark,string overBackgroundImage,Color overBorderColorLight,Color overBorderColorDark,string downBackgroundImage,Color downBorderColorLight,Color downBorderColorDark) {
			ViewState["BorderColorLight"] = borderColorLight;
			ViewState["BorderColorDark"] = borderColorDark;
			ViewState["OverBackgroundImage"] = overBackgroundImage;
			ViewState["OverBorderColorLight"] = overBorderColorLight;
			ViewState["OverBorderColorDark"] = overBorderColorDark;
			ViewState["DownBackgroundImage"] = downBackgroundImage;
			ViewState["DownBorderColorLight"] = downBorderColorLight;
			ViewState["DownBorderColorDark"] = downBorderColorDark;	
		}
		/// <summary>
		/// Sets BorderColorLight and BorderColorDark.
		/// </summary>	
		[
		NotifyParentProperty(true)
		]
		public new Color BorderColor {
			get { 				
				object savedState = this.ViewState["BorderColor"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { 
				base.BorderColor = value;
				ViewState["BorderColorLight"] = value;
				ViewState["BorderColorDark"] = value;
			}
		}
		/// <summary>
		/// The default light (top and left) border color of buttons.
		/// </summary>	
		[
		NotifyParentProperty(true)
		]
		public Color BorderColorLight {
			get { 				
				object savedState = this.ViewState["BorderColorLight"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["BorderColorLight"] = value;}
		}
		/// <summary>
		/// The default dark (right and bottom) border color of buttons.
		/// </summary>		
		[
		NotifyParentProperty(true)
		]
		public Color BorderColorDark {
			get { 				
				object savedState = this.ViewState["BorderColorDark"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["BorderColorDark"] = value;}
		}
		/// <summary>
		/// The default onMouseOver back color of buttons.
		/// </summary>	
		[
		NotifyParentProperty(true)
		]
		public Color OverBackColor {
			get { 				
				object savedState = this.ViewState["OverBackColor"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["OverBackColor"] = value;}
		}
		/// <summary>
		/// The default onMouseOver light (top and left) border color of buttons.
		/// </summary>	
		[
		NotifyParentProperty(true)
		]
		public Color OverBorderColorLight {
			get { 				
				object savedState = this.ViewState["OverBorderColorLight"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["OverBorderColorLight"] = value;}
		}
		/// <summary>
		/// The default onMouseOver dark (right and bottom) border color of buttons.
		/// </summary>		
		[
		NotifyParentProperty(true)
		]
		public Color OverBorderColorDark {
			get { 				
				object savedState = this.ViewState["OverBorderColorDark"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["OverBorderColorDark"] = value;}
		}
		/// <summary>
		/// The background image onMouseDown.
		/// </summary>	
		[
		NotifyParentProperty(true)
		]
		public string OverBackgroundImage {
			get { 				
				object savedState = this.ViewState["OverBackgroundImage"];
				return (savedState == null) ? "" : (string) savedState;
			}
			set { ViewState["OverBackgroundImage"] = value;}		
		}
		/// <summary>
		/// The default onMouseDown back color of buttons.
		/// </summary>	
		[
		NotifyParentProperty(true)
		]
		public Color DownBackColor {
			get { 				
				object savedState = this.ViewState["DownBackColor"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["DownBackColor"] = value;}
		}
		/// <summary>
		/// The default onMouseDown light (top and left) border color of buttons onMouseDown.
		/// </summary>	
		[
		NotifyParentProperty(true)
		]
		public Color DownBorderColorLight {
			get { 				
				object savedState = this.ViewState["DownBorderColorLight"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["DownBorderColorLight"] = value;}
		}
		/// <summary>
		/// The default onMouseDown dark (right and bottom) border color of buttons onMouseDown.
		/// </summary>	
		[
		NotifyParentProperty(true)
		]
		public Color DownBorderColorDark {
			get { 				
				object savedState = this.ViewState["DownBorderColorDark"];
				return (savedState == null) ? Color.Empty : (Color) savedState;
			}
			set { ViewState["DownBorderColorDark"] = value;}
		}
		/// <summary>
		/// The background image onMouseDown.
		/// </summary>
		[
		NotifyParentProperty(true)
		]
		public string DownBackgroundImage {
			get { 				
				object savedState = this.ViewState["DownBackgroundImage"];
				return (savedState == null) ? "" : (string) savedState;
			}
			set { ViewState["DownBackgroundImage"] = value;}
		}
	}	
}