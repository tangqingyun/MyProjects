using System;

namespace FreeTextBoxControls {
	/// <summary>
	/// Several predefined sets of buttons
	/// </summary>
	public enum AutoConfigure {
		/// <summary>
		/// Uses the default string of buttons
		/// </summary>		
		Default = 0,
		/// <summary>
		/// Enables only a few buttons
		/// </summary>		
		Minimal = 1,
		/// <summary>
		/// Enables all buttons and dropdowns
		/// </summary>		
		EnableAll = 2,
		/// <summary>
		/// Any alternate layout that emphasizes the save button and color pickers
		/// </summary>
		Alternate = 3,

        /// <summary>
        /// ���ⴰ��
        /// </summary>
        Public = 4
	}
}
