using System;

namespace FreeTextBoxControls {
	/// <summary>
	/// Determines what is displayed for Downlevel browsers
	/// </summary>
	public enum DownlevelMode {
		/// <summary>
		/// A basic editor consisting of a normal TEXTAREA with a WYSISYG Div
		/// </summary>		
		BasicEditor = 0,
		/// <summary>
		/// Displays the HTML inline with no form control
		/// </summary>		
		Document = 1,
		/// <summary>
		/// Outputs a predefined message
		/// </summary>
		Message = 2,
		/// <summary>
		/// Outputs a standard HTML textarea
		/// </summary>
		TextArea = 3,
	}
}
