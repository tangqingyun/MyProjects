using System;

namespace FreeTextBoxControls {
	/// <summary>
	/// Determines how buttons are drawn
	/// </summary>
	public enum ButtonType {
		/// <summary>
		/// Uses images for buttons.  Button borders and backcolors default to Office XP style
		/// </summary>
		Image = 0,
		/// <summary>
		/// Uses HTML &lt;input type="button"&gt; for ToolbarButtons
		/// </summary>
		FormButton = 1
	}
}