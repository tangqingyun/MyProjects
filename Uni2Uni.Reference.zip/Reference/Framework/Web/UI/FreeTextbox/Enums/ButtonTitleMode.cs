using System;

namespace FreeTextBoxControls {
	/// <summary>
	/// Determines how or if titles are displayed on buttons
	/// </summary>
	public enum ButtonTitleMode  {
		/// <summary>
		/// No button titles are displayed.  Overrides ToolbarButton.TitleVisible
		/// </summary>
		None = 0,
		/// <summary>
		/// Button Titles are only show if the buttons TitleVisible property is true
		/// </summary>
		Selective = 1,
		/// <summary>
		/// All button titles are shown
		/// </summary>
		All = 2
	}
}
