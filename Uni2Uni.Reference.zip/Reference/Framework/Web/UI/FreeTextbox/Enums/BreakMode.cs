using System;

namespace FreeTextBoxControls {
	/// <summary>
	/// Determines what happens when the "enter" key is pressed in the editor
	/// </summary>
	public enum BreakMode {
		/// <summary>
		/// Enter key inserts &lt;br&gt;
		/// </summary>
		LineBreak = 0,
		/// <summary>
		/// Enter key inserts new paragraph, Ctrl+Enter inserts &lt;br&gt;
		/// </summary>
		ParagraphBreak = 1
	}
}