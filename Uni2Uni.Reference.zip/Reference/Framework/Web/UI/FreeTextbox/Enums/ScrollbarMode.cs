using System;

namespace FreeTextBoxControls {
	/// <summary>
	/// Determines the style of the scroll bar.
	/// </summary>
	public enum ScrollbarMode  {
		/// <summary>
		/// No styles are applied.  The default scroll bar is used.
		/// </summary>
		None = 0,
		/// <summary>
		/// Uses styles from the ScrollbarStyle object which defaults to a Visual Studio.NET style flat scrollbar.
		/// </summary>
		Style = 1
	}
}
