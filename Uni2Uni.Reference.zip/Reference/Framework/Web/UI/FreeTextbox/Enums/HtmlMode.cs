using System;

namespace FreeTextBoxControls {
	/// <summary>
	/// Determines what type of interface is displayed for switching between HtmlMode and DesignMode
	/// </summary>
	public enum HtmlMode {
		/// <summary>
		/// Default.  ASP.NET Web Matrix style tabs
		/// </summary>		
		Tabs = 0,
		/// <summary>
		/// An HTML checkbox is used for switching modes
		/// </summary>		
		Checkbox = 1
	}
}
