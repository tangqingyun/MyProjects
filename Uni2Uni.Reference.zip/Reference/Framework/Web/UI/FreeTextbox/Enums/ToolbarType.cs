using System;

namespace FreeTextBoxControls {
	/// <summary>
	/// Determines how the toolbars and its buttons and dropdownlists are displayed
	/// </summary>
	public enum ToolbarType {
		/// <summary>
		/// Sets images, borders and backcolors to Office XP style
		/// </summary>
		OfficeXP = 0,
		/// <summary>
		/// Sets images, borders and backcolors to Office 2000 style
		/// </summary>
		Office2000 = 1,
		/// <summary>
		/// Sets images, borders and backcolors to Office 2003 style
		/// </summary>
		Office2003 = 2,
		/// <summary>
		/// You must use this setting if you want custom colors. Otherwise the other settings will override your settings.
		/// </summary>
		Custom = 3
	}
}