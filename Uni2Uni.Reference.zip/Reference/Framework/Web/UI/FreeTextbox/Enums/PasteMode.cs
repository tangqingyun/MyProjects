using System;

namespace FreeTextBoxControls {
	/// <summary>
	/// Determines what happens when a user pastes into the control
	/// </summary>
	public enum PasteMode {
		Default = 0,
		NoScript = 1,
		NoHtml = 2,
		Disabled = 3
	}
}
