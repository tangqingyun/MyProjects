using System;

namespace FreeTextBoxControls {
	/// <summary>
	/// A button used in an Toolbar
	/// </summary>
	public class ToolbarButton : ToolbarItem {
		public ToolbarButton() {}
		public ToolbarButton(string title, string name, string function) {
			this.Title = title;
			this.Name = name;
			this.Function = function;
		}
		private string href = "";
		private string target = "";
		private bool titleVisible = false;

		/// <summary>
		/// Determines whether a button's Title is shown
		/// </summary>
		public bool TitleVisible {
			get { return titleVisible; }
			set { titleVisible = value; }
		}
		/// <summary>
		/// Used if a button does not execute a function
		/// </summary>
		public string Href {
			get { return href; }
			set { href = value; }
		}	
		/// <summary>
		/// The target for Href property
		/// </summary>
		public string Target {
			get { return target; }
			set { target = value; }
		}

		/// <summary>
		/// Determines how the title of the button will be displayed
		/// </summary>
		public ButtonTitleMode ButtonTitleMode = ButtonTitleMode.None;	
	}
}
