using System;
using System.Drawing;
using FreeTextBoxControls.Common;

namespace FreeTextBoxControls {
	/// <summary>
	/// A DropDownList for a Toolbar
	/// </summary>
	public class ToolbarDropDownList : ToolbarItem {
		public ToolbarDropDownList() {}
		public ToolbarDropDownList(string title, string name, string function) {
			this.Title = title;
			this.Name = name;
			this.Function = function;
		}
		/// <summary>
		/// Collection of ToolbarListItems
		/// </summary>
		public ToolbarDropDownListItems Items = new ToolbarDropDownListItems();
	}

	/// <summary>
	/// A DropDownList Item for a Toolbar
	/// </summary>
	public class ToolbarListItem {
		public ToolbarListItem() {}
		public ToolbarListItem(string name, string theValue) {			
			this.Name = name;
			this.Value = theValue;
			this.BackColor = new Color();
		}
		public ToolbarListItem(string name, string theValue, Color backColor) {			
			this.Name = name;
			this.Value = theValue;
			this.BackColor = backColor;
		}
		private string name = "";
		private string _value = "";
		private Color backColor = new Color();

		/// <summary>
		/// The name displayed for the DropDown Item
		/// </summary>
		public string Name  {
			get { return name; }
			set { name = value; }
		}
		/// <summary>
		/// The value of the DropDown item
		/// </summary>
		public string Value  {
			get { return _value; }
			set { _value = value; }
		}
		/// <summary>
		/// The backcolor of the DropDown item
		/// </summary>
		public Color BackColor  {
			get { return backColor; }
			set { backColor = value; }
		}
	}
}
