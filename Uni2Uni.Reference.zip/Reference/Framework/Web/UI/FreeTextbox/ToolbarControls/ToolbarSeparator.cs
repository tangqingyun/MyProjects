using System;

namespace FreeTextBoxControls {
	/// <summary>
	/// Creates a separator bar in a Toolbar
	/// </summary>
	public class ToolbarSeparator : ToolbarItem {
		/// <summary>
		/// Empty Constructor
		/// </summary>
		public ToolbarSeparator() {}
	}
}
