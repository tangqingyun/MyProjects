using System;


namespace FreeTextBoxControls {
	/// <summary>
	/// Contains all the built-in ToolbarButtons and ToolbarDropDownLists
	/// </summary>
	public class ToolbarItems {
		/// <summary>
		/// Returns a ToolbarButton with ieSpellCheck JavaScript functions builtin
		/// </summary>
		public static ToolbarButton ieSpellCheck {
			get {
				ToolbarButton button = new ToolbarButton("ƴд���","SpellCheck","FTB_ieSpellCheck");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_ieSpellCheck(editor,htmlmode) {
    if (htmlmode) return;
	try {
		var tspell = new ActiveXObject('ieSpell.ieSpellExtension');
		tspell.CheckAllLinkedDocuments(window.document);
	} catch (err){
		if (window.confirm('����ƴд�����Ҫ��װ ieSpell �������Ҫ��װ��')){window.open('http://www.iespell.com/download.php');};
	};
}
</script>";
				return button;
			}
		}
		
		/// <summary>
		/// Returns a ToolbarButton with Save JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Save {
			get {
				ToolbarButton button = new ToolbarButton("����","Save","FTB_Save_CLIENTID");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Save_CLIENTID(editor,htmlmode) { 
	FTB_CopyHtmlToHidden(editor,document.getElementById('CLIENTID'),htmlmode);	
	<POSTBACK>Save</POSTBACK>
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with Bold JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Bold {
			get {
				ToolbarButton button = new ToolbarButton("����","bold","FTB_Bold");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Bold(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'bold'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with Italic JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Italic {
			get {
				ToolbarButton button = new ToolbarButton("б��","italic","FTB_Italic");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Italic(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'italic'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with Underline JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Underline {
			get {
				ToolbarButton button = new ToolbarButton("�»���","underline","FTB_Underline");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Underline(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'underline'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with Strikethrough JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Strikethrough {
			get {
				ToolbarButton button = new ToolbarButton("ɾ����","strikethrough","FTB_Strikethrough");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Strikethrough(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'strikethrough'); 
}
</script>";
				return button;
			}
		}

		/// <summary>
		/// Returns a ToolbarButton with Superscript JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Superscript {
			get {
				ToolbarButton button = new ToolbarButton("�ϱ�","superscript","FTB_Superscript");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Superscript(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'superscript'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with Subscript JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Subscript {
			get {
				ToolbarButton button = new ToolbarButton("�±�","subscript","FTB_Subscript");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Subscript(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'subscript'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with RemoveFormat JavaScript functions builtin
		/// </summary>
		public static ToolbarButton RemoveFormat {
			get {
				ToolbarButton button = new ToolbarButton("ɾ����ʽ","removeformat","FTB_RemoveFormat");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_RemoveFormat(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'removeFormat'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with FontForeColorPicker JavaScript functions builtin
		/// </summary>
		public static ToolbarButton FontForeColorPicker {
			get {
				ToolbarButton button = new ToolbarButton("������ɫ","fontforecolorpicker","FTB_ForeColorPicker");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_ForeColorPicker(editor,htmlmode) {
	if (htmlmode) return;
	script = FTB_HelperFilesPath + 'ftb.colorpicker.aspx';
	if (FTB_HelperFilesParameters != '') script += '?' + FTB_HelperFilesParameters
	color = showModalDialog(script,window,'dialogWidth:210px;dialogHeight:170px;status:0;scroll:0;help:0;');
	editor.document.execCommand('forecolor','',color);
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with FontBackColorPicker JavaScript functions builtin
		/// </summary>
		public static ToolbarButton FontBackColorPicker {
			get {
				ToolbarButton button = new ToolbarButton("����ɫ","fontbackcolorpicker","FTB_BackColorPicker");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_BackColorPicker(editor,htmlmode) {
	if (htmlmode) return;
	script = FTB_HelperFilesPath + 'ftb.colorpicker.aspx';
	if (FTB_HelperFilesParameters != '') script += '?' + FTB_HelperFilesParameters
	color = showModalDialog(script,window,'dialogWidth:210px;dialogHeight:170px;status:0;scroll:0;help:0;');
	editor.document.execCommand('backcolor','',color);
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with JustifyLeft JavaScript functions builtin
		/// </summary>
		public static ToolbarButton JustifyLeft {
			get {
				ToolbarButton button = new ToolbarButton("�����","justifyleft","FTB_JustifyLeft");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_JustifyLeft(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'justifyleft'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with JustifyRight JavaScript functions builtin
		/// </summary>
		public static ToolbarButton JustifyRight {
			get {
				ToolbarButton button = new ToolbarButton("�Ҷ���","justifyright","FTB_JustifyRight");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_JustifyRight(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'justifyright'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with JustifyCenter JavaScript functions builtin
		/// </summary>
		public static ToolbarButton JustifyCenter {
			get {
				ToolbarButton button = new ToolbarButton("���ж���","justifycenter","FTB_JustifyCenter");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_JustifyCenter(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'justifycenter'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with JustifyFull JavaScript functions builtin
		/// </summary>
		public static ToolbarButton JustifyFull {
			get {
				ToolbarButton button = new ToolbarButton("���˶���","justifyfull","FTB_JustifyFull");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_JustifyFull(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'justifyfull'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with BulletedList JavaScript functions builtin
		/// </summary>
		public static ToolbarButton BulletedList {
			get {
				ToolbarButton button = new ToolbarButton("��Ŀ�����б�","bullets","FTB_BulletedList");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_BulletedList(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'insertunorderedlist'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with NumberedList JavaScript functions builtin
		/// </summary>
		public static ToolbarButton NumberedList {
			get {
				ToolbarButton button = new ToolbarButton("������Ŀ�б�","numberedlist","FTB_NumberedList");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_NumberedList(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'insertorderedlist'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with Indent JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Indent {
			get {
				ToolbarButton button = new ToolbarButton("��������","indent","FTB_Indent");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Indent(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'indent'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with Outdent JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Outdent {
			get {
				ToolbarButton button = new ToolbarButton("��������","outdent","FTB_Outdent");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Outdent(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'outdent'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with Cut JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Cut {
			get {
				ToolbarButton button = new ToolbarButton("����","cut","FTB_Cut");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Cut(editor,htmlmode) {
	editor.focus();
	editor.document.execCommand('cut','',null);
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with Copy JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Copy {
			get {
				ToolbarButton button = new ToolbarButton("����","copy","FTB_Copy");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Copy(editor,htmlmode) {
	editor.focus();
	editor.document.execCommand('copy','',null);
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with Paste JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Paste {
			get {
				ToolbarButton button = new ToolbarButton("ճ��","paste","FTB_Paste");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Paste(editor,htmlmode) {
	editor.focus();
	editor.document.execCommand('paste','',null);
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with Undo JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Undo {
			get {
				ToolbarButton button = new ToolbarButton("����","undo","FTB_Undo");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Undo(editor,htmlmode) {
	editor.focus();
	editor.document.execCommand('undo','',null);
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with Redo JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Redo {
			get {
				ToolbarButton button = new ToolbarButton("����","redo","FTB_Redo");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Redo(editor,htmlmode) {
	editor.focus();
 	editor.document.execCommand('redo','',null);
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with Print JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Print {
			get {
				ToolbarButton button = new ToolbarButton("��ӡ","print","FTB_Print");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Print(editor,htmlmode) { 
	editor.document.execCommand('print','',null); 
}
</script>";
				return button;
			}
		}
		/*
		/// <summary>
		/// Returns a ToolbarButton with Find JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Find {
			get {
				ToolbarButton button = new ToolbarButton("����","find","FTB_Find");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Find(editor,htmlmode) {
	var aOut = new Array();
	aOut[""editor""] = editor;
	findArr = showModalDialog(""find.html"",aOut,""dialogWidth:370px; dialogHeight:130px;help:0;status:0;"");
	editor.focus();
}
</script>";
				return button;
			}
		}
		*/
		/// <summary>
		/// Returns a ToolbarButton with ChangeCase JavaScript functions builtin
		/// </summary>
		public static ToolbarButton ChangeCase {
			get {
				ToolbarButton button = new ToolbarButton("���Ĵ�Сд","changecase","FTB_ChangeCase");
				button.ScriptBlock = @"<script language=""JavaScript"">
var changetype = 0;
function FTB_ChangeCase(editor,htmlmode) {
	sel = editor.document.selection.createRange();
	txt = sel.htmlText;

	splitwords = txt.split("" "");
	var f = '';

	for (var i=0; i<splitwords.length;i++) {
		//alert('changing: ' + splitwords[i]);
		switch (changetype) {
			case 0:
				f += splitwords[i].toUpperCase();
				break;
			case 1:
				f += splitwords[i].toLowerCase();
				break;
			case 2:
				tot = splitwords[i].length;
				if (tot > 1) {
					//alert(splitwords[i].substring(1,2).toLowerCase());
					f += splitwords[i].substring(0,1).toUpperCase() + splitwords[i].substring(1,splitwords[i].length).toLowerCase();
				} else {
					f += splitwords[i].toUpperCase();
				}
				break;
		}
		if (i <(splitwords.length-1)) f += "" "";
	}
	sel.pasteHTML(f);
	sel = editor.document.selection.createRange();
	sel.findText(f);
	sel.select();

	//editor.focus();

	changetype++;
	if (changetype > 2) changetype = 0;
}
		}
</script>";
				return button;
			}
		}	
		/// <summary>
		/// Returns a ToolbarButton with Delete JavaScript functions builtin
		/// </summary>
		public static ToolbarButton Delete {
			get {
				ToolbarButton button = new ToolbarButton("���","delete","FTB_Delete");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Delete(editor,htmlmode) {
	if (confirm('ȷʵҪɾ���༭�������е����ֺ� HTML ������')) {	
		editor.document.body.innerHTML = '';
		editor.document.body.innerText = '';
	}
	editor.focus();
}
</script>";
				return button;
			}
		}	
		/// <summary>
		/// Returns a ToolbarButton with CreateLink JavaScript functions builtin
		/// </summary>	
		public static ToolbarButton CreateLink {
			get {
				ToolbarButton button = new ToolbarButton("���볬����","createlink","FTB_CreateLink");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_CreateLink(editor,htmlmode) {
	if (htmlmode) return;
	editor.focus();
    editor.document.execCommand('createlink','1',null);
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with Unlink JavaScript functions builtin
		/// </summary>	
		public static ToolbarButton Unlink {
			get {
				ToolbarButton button = new ToolbarButton("ȥ��������","unlink","FTB_Unlink");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_Unlink(editor,htmlmode) {
	if (htmlmode) return;
	editor.focus();
    editor.document.execCommand('unlink','1',null);
}
</script>";
				return button;
			}
		}

		/// <summary>
		/// Returns a ToolbarButton with InsertImage JavaScript functions builtin
		/// </summary>			
		public static ToolbarButton InsertImage {
			get {
                ToolbarButton button = new ToolbarButton("�����ⲿͼƬ����", "image", "FTB_InsertImage");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_InsertImage(editor,htmlmode) {
	if (htmlmode) return;
	editor.focus();
	editor.document.execCommand('insertimage',1,'');
}
</script>";
				return button;
			}
		}
		
		/// <summary>
		/// Returns a ToolbarButton with InsertImageFromGallery JavaScript functions builtin
		/// </summary>			
		public static ToolbarButton InsertImageFromGallery {
			get {
				ToolbarButton button = new ToolbarButton("����ͼƬ������ͼƬ�⣩","insertimagefromgallery","FTB_InsertImageFromGallery_CLIENTID");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_InsertImageFromGallery_CLIENTID(editor,htmlmode) {
	if (htmlmode) return;
	editor.focus();

	obj = FTB_GetRangeReference(editor);
	if (obj.tagName == 'IMG') {
		editor.document.execCommand('insertimage',1,'');
		return;
	}

	var folder = 'IMAGEGALLERYPATH';
	var galleryscript = FTB_HelperFilesPath + 'ftb.imagegallery.aspx?rif='+folder+'&cif='+folder;
	if (FTB_HelperFilesParameters != '') galleryscript += '&' + FTB_HelperFilesParameters;
	imgArr = showModalDialog(galleryscript,window,'dialogWidth:560px; dialogHeight:500px;help:0;status:0;resizeable:1;');

	if (imgArr != null) {
		imagestring = '<IMG SRC=""' + imgArr['filename'] + '"" HEIGHT=' + imgArr['height'] + ' WIDTH=' + imgArr['width'] + ' BORDER=0>';
		sel = editor.document.selection.createRange();
		sel.pasteHTML(imagestring);
	} else {
		//alert(""��û��ѡ��ͼƬ��"");
	}
}
</script>";
				return button;
			}
		}	
	
		/// <summary>
		/// Returns a ToolbarButton with InsertRule JavaScript functions builtin
		/// </summary>	
		public static ToolbarButton InsertRule {
			get {
				ToolbarButton button = new ToolbarButton("����ˮƽ��","insertrule","FTB_InsertRule");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_InsertRule(editor,htmlmode) { 
	FTB_Format(editor,htmlmode,'inserthorizontalrule'); 
}
</script>";
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with InsertDate JavaScript functions builtin
		/// </summary>	
		public static ToolbarButton InsertDate {
			get {
				ToolbarButton button = new ToolbarButton("��������","insertdate","FTB_InsertDate");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_InsertDate(editor,htmlmode) {
	editor.focus();
	var d = new Date();
	sel = editor.document.selection.createRange();
	sel.pasteHTML(d.toLocaleDateString());
}
</script>";
				button.ButtonTitleMode = ButtonTitleMode.Selective;
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with InsertTime JavaScript functions builtin
		/// </summary>	
		public static ToolbarButton InsertTime {
			get {
				ToolbarButton button = new ToolbarButton("����ʱ��","inserttime","FTB_InsertTime");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_InsertTime(editor,htmlmode) {
	editor.focus();
	var d = new Date();
	sel = editor.document.selection.createRange();
	sel.pasteHTML(d.toLocaleTimeString());
}
</script>";
				button.ButtonTitleMode = ButtonTitleMode.Selective;
				return button;
			}
		}
		/// <summary>
		/// Returns a ToolbarButton with WordCount JavaScript functions builtin
		/// </summary>	
		public static ToolbarButton WordCount {
			get {
				ToolbarButton button = new ToolbarButton("����ͳ��","wordcount","FTB_WordCount");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_WordCount(editor,htmlmode) {
    if (htmlmode) return;
    var iSumWords = 0;
    var rng = editor.document.body.createTextRange();
    rng.collapse(true);
    while(rng.move(""word"",1)) {
	    iSumWords++;
    }
    alert(""��Լ  "" + iSumWords + "" ��"");
}
</script>";
				button.ButtonTitleMode = ButtonTitleMode.Selective;
				return button;
			}
		}

		/***************************************************
		// The following Word Cleaner is a modified version
		// of a cleaner I found in a free ASP.NET
		// MSHTML editor, but I cannot find the source.
		// Please email me for credits. Sorry!
		***************************************************/

		/// <summary>
		/// Returns a ToolbarButton with WordClean JavaScript functions builtin
		/// </summary>			
		public static ToolbarButton WordClean {
			get {
				ToolbarButton button = new ToolbarButton("��� Word ��ʽ","wordclean","FTB_WordClean");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_WordClean(editor,htmlmode) {
	editor.focus();
	// 0bject based cleaning
	var body = editor.document.body;
	for (var index = 0; index < body.all.length; index++) {
		tag = body.all[index];
		//if (tag.Attribute[""className""].indexOf(""mso"") > -1)
		tag.removeAttribute(""className"","""",0);
		tag.removeAttribute(""style"","""",0);
	}

	// Regex based cleaning
	var html = editor.document.body.innerHTML;
	html = html.replace(/<o:p>&nbsp;<\/o:p>/g, """");
	html = html.replace(/o:/g, """");
	html = html.replace(/<st1:.*?>/g, """");

	// Final clean up of empty tags
	html = html.replace(/<font>/g, """");
	html = html.replace(/<span>/g, """");
	
	editor.document.body.innerHTML = html;

}
</script>";
				return button;
			}
		}

        /// <summary>
        /// ����QQ����
        /// </summary>
        public static ToolbarButton QQ
        {
            get
            {
                ToolbarButton button = new ToolbarButton("����QQ����", "QQ", "FTB_InsertQQ");

                button.ScriptBlock = @"<script language=""JavaScript"">
                function FTB_InsertQQ(editor,htmlmode)
                {
                    if (htmlmode) return;
                    editor.focus();
                    var tablescript = '/app_common/ftb.insertqq.html?temp='+getRandom(1,1000);
                    tableArr = showModalDialog(tablescript,window,'dialogWidth:400px; dialogHeight:350px;help:0;status:0;resizeable:1;scroll:0;');
                    
if (tableArr != null) {
    sel = editor.document.selection.createRange();
	sel.pasteHTML('<img src=""'+tableArr+'"" />');
}
                                        
                }
                </script>
                ";

                return button;
            }
        }

        /// <summary>
        /// ����MSN����
        /// </summary>
        public static ToolbarButton MSN
        {
            get
            {
                ToolbarButton button = new ToolbarButton("����MSN����", "msn", "FTB_InsertMSN");

                button.ScriptBlock = @"<script language=""JavaScript"">
                function FTB_InsertMSN(editor,htmlmode)
                {
                    if (htmlmode) return;
                    editor.focus();
                    var tablescript = '/app_common/ftb.insertmsn.html?temp='+getRandom(1,1000);
                    tableArr = showModalDialog(tablescript,window,'dialogWidth:390px; dialogHeight:170px;help:0;status:0;resizeable:1;scroll:0;');
                    
if (tableArr != null) {
    sel = editor.document.selection.createRange();
	sel.pasteHTML('<img src=""'+tableArr+'"" />');
}
                                        
                }
                </script>
                ";

                return button;
            }
        }

        /// <summary>
        /// ����Yahoo����
        /// </summary>
        public static ToolbarButton Yahoo
        {
            get
            {
                ToolbarButton button = new ToolbarButton("����Yahoo����", "yahoo", "FTB_InsertYahoo");

                button.ScriptBlock = @"<script language=""JavaScript"">
                function FTB_InsertYahoo(editor,htmlmode)
                {
                    if (htmlmode) return;
                    editor.focus();
                    var tablescript = '/app_common/ftb.insertyahoo.html?temp='+getRandom(1,1000);
                    tableArr = showModalDialog(tablescript,window,'dialogWidth:560px; dialogHeight:195px;help:0;status:0;resizeable:1;scroll:0;');
                    
if (tableArr != null) {
    sel = editor.document.selection.createRange();
	sel.pasteHTML('<img src=""'+tableArr+'"" />');
}
                                        
                }
                </script>
                ";

                return button;
            }
        }

        /// <summary>
        /// �ϴ�ͼ��
        /// </summary>
        public static ToolbarButton UploadImage
        {
            get{
                ToolbarButton button = new ToolbarButton("�ϴ�ͼ��", "insertimage", "FTB_UploadImage");
                button.ScriptBlock = @"<script language=""JavaScript"">
                function FTB_UploadImage(editor,htmlmode)
                {
    if (htmlmode) return;
	editor.focus();
	var url = 'upload.aspx?ext=img&temp='+getRandom(1,1000);
    var value = showModalDialog(url,window,'dialogWidth:390px; dialogHeight:180px;help:0;status:0;scroll:0');
    if (value != null) {
        sel = editor.document.selection.createRange();
	    sel.pasteHTML('<img src=""'+value+'"" />');
    }
                }  
    </script>
                ";

                return button;
            }
        }

        public static ToolbarButton UploadFlash
        {
            get{
                ToolbarButton button = new ToolbarButton("�ϴ�Flash", "flash", "FTB_UploadFlash");
                button.ScriptBlock = @"<script language=""JavaScript"">
                function FTB_UploadFlash(editor,htmlmode)
                {
    if (htmlmode) return;
    editor.focus();
    var url = 'upload.aspx?ext=flash&temp='+getRandom(1,1000);
	var value = showModalDialog(url,window,'dialogWidth:390px; dialogHeight:180px;help:0;status:0;resizeable:0;scroll:0');
    if (value != null) {
        sel = editor.document.selection.createRange();
	    sel.pasteHTML('<object classid=\'clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\' codebase=\'http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0\' width=\'200\' height=\'200\'><param name=\'movie\' value=\''+value+'\'><param name=\'quality\' value=\'high\'><embed src=\''+value+'\' quality=\'high\' pluginspage=\'http://www.macromedia.com/go/getflashplayer\' type=\'application/x-shockwave-flash\' width=\'200\' height=\'200\'></embed></object>');
    }
    
                }  
                </script>";

                return button;
            }
        }

        public static ToolbarButton UploadZip
        {
            get{
                ToolbarButton button = new ToolbarButton("�ϴ�ѹ���ļ�", "zip", "FTB_UploadZip");
                button.ScriptBlock = @"<script language=""JavaScript"">
                function FTB_UploadZip(editor,htmlmode)
                {
    if (htmlmode) return;
    editor.focus();
    var url = 'upload.aspx?ext=zip&temp='+getRandom(1,1000);
	var value = showModalDialog(url,window,'dialogWidth:390px; dialogHeight:180px;help:0;status:0;resizeable:0;scroll:0;');
    var exc = value.substring(value.length-3);
    if (value != null) {
        sel = editor.document.selection.createRange();
	    sel.pasteHTML('<a href=\''+value+'\'><img src=\'/images/fileico/'+exc+'.gif\' border=\'0\' /></a>');
    }
                }  
                </script>";

                return button;                
            }
        }

        public static ToolbarButton UploadDocument
        {
            get
            {
                ToolbarButton button = new ToolbarButton("�ϴ��ĵ�", "document", "FTB_UploadDocument");
                button.ScriptBlock = @"<script language=""JavaScript"">
                function FTB_UploadDocument(editor,htmlmode)
                {
    if (htmlmode) return;
    editor.focus();
    var url = 'upload.aspx?ext=doc&temp='+getRandom(1,1000);
	var value = showModalDialog(url,window,'dialogWidth:390px; dialogHeight:180px;help:0;status:0;resizeable:0;scroll:0;');
    var exc = value.substring(value.length-3);
    if (value != null) {
        sel = editor.document.selection.createRange();
	    sel.pasteHTML('<a href=\''+value+'\'><img src=\'/images/fileico/'+exc+'.gif\' border=\'0\' /></a>');
    }
                }  
                </script>";

                return button;
            }
        }


        
		/// <summary>
		/// Returns a ToolbarButton with InsertTable JavaScript functions builtin
		/// </summary>			
		public static ToolbarButton InsertTable {
			get {
				ToolbarButton button = new ToolbarButton("�������","inserttable","FTB_InsertTable");
				button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_InsertTable(editor,htmlmode) {
	if (htmlmode) return;
	editor.focus();

	var tablescript = FTB_HelperFilesPath + 'ftb.inserttable.aspx';
	if (FTB_HelperFilesParameters != '') tablescript += '?' + FTB_HelperFilesParameters;
	tableArr = showModalDialog(tablescript,window,'dialogWidth:350px; dialogHeight:210px;help:0;status:0;resizeable:1;');

	if (tableArr != null) {
		var newTable = editor.document.createElement('TABLE');
		for(y=0; y<tableArr['rows']; y++) {
			var newRow = newTable.insertRow();
			for(x=0; x<tableArr['cols']; x++) {
				var newCell = newRow.insertCell();				
				if (tableArr['valigncells'] != """") {
					newCell.valign = tableArr['valigncells'];
				}
				if (tableArr['haligncells'] != """") {
					newCell.align = tableArr['haligncells'];
				}				
				if (tableArr['percentcols'] == true) {					
					newCell.width = Math.round((1 / tableArr['cols']) * 100) + ""%"";
				}					
			}
		}
		newTable.border = tableArr['border'];
		newTable.cellspacing = tableArr['cellspacing'];
		newTable.cellpadding = tableArr['cellpadding'];		
		if (tableArr['width'] != """") newTable.width = tableArr['width'];
		if (tableArr['height'] != """") newTable.height = tableArr['height'];

		if (editor.document.selection.type=='Control') {
			sel.pasteHTML(newTable.outerHTML);
		} else {
			sel = editor.document.selection.createRange();
			sel.pasteHTML(newTable.outerHTML);
		}
	} else {
		//alert(""You did not select an image"");
	}
}
</script>";
				return button;
			}
		}

        public static ToolbarButton ParagraphIndent
        {
            get
            {
                ToolbarButton button = new ToolbarButton("��������", "indentnew", "FTB_ParagraphIndent");

                button.ScriptBlock = @"<script language=""JavaScript"">
function FTB_ParagraphIndent(editor,htmlmode) {
    if (htmlmode) return;
	editor.focus();
    for (var i=0; i<editor.document.getElementsByTagName(""P"").length;i++)
    {
        var o = editor.document.getElementsByTagName(""P"")[i];
        if (o.innerHTML.substring(0,Marks.length) == Marks)
        {
            o.innerHTML =o.innerHTML.substring(Marks.length);
        }else{
            o.innerHTML = Marks+o.innerHTML;
        }
    }    
}
</script>";
                return button;
            }
        }


		/// <summary>
		/// Returns a ToolbarSeparator
		/// </summary>			
		public static ToolbarSeparator Separator {
			get {
				return new ToolbarSeparator();
			}
		}
		/// <summary>
		/// Returns a ToolbarDropDownList with FontFacesMenu JavaScript functions builtin.  Items will be filled by FreeTextBox.FillEmptyDefaultDropDowns.
		/// </summary>	
		public static ToolbarDropDownList FontFacesMenu {
			get {
				ToolbarDropDownList dropdown = new ToolbarDropDownList("����","FontFacesMenu","FTB_SetFontFace");
				dropdown.CommandIdentifier = "fontname";
				dropdown.ScriptBlock = @"<script language=""JavaScript"">
function FTB_SetFontFace(editor,htmlmode,name,value) {
	if (htmlmode) return;
	editor.focus();
	editor.document.execCommand('fontname','',value);
}
</script>";
				return dropdown;
			}
		}
		/// <summary>
		/// Returns a ToolbarDropDownList with FontSizesMenu JavaScript functions builtin.  Items will be filled by FreeTextBox.FillEmptyDefaultDropDowns.
		/// </summary>	
		public static ToolbarDropDownList FontSizesMenu {
			get {
				ToolbarDropDownList dropdown = new ToolbarDropDownList("�ֺ�","FontSizesMenu","FTB_SetFontSize");
				dropdown.CommandIdentifier = "fontsize";
				dropdown.ScriptBlock = @"<script language=""JavaScript"">
function FTB_SetFontSize(editor,htmlmode,name,value) {
	if (htmlmode) return;
	editor.focus();
	editor.document.execCommand('fontsize','',value);
}
</script>";
				return dropdown;
			}
		}
		/// <summary>
		/// Returns a ToolbarDropDownList with FontForeColorsMenu JavaScript functions builtin.  Items will be filled by FreeTextBox.FillEmptyDefaultDropDowns.
		/// </summary>	
		public static ToolbarDropDownList FontForeColorsMenu {
			get {
				ToolbarDropDownList dropdown = new ToolbarDropDownList("������ɫ","FontForeColorsMenu","FTB_SetFontForeColor");
				dropdown.CommandIdentifier = "forecolor";
				dropdown.ScriptBlock = @"<script language=""JavaScript"">
function FTB_SetFontForeColor(editor,htmlmode,name,value) {
	if (htmlmode) return;
	editor.focus();
	editor.document.execCommand('forecolor','',value);
}
</script>";

				return dropdown;
			}
		}
		/// <summary>
		/// Returns a ToolbarDropDownList with FontBackColorsMenu JavaScript functions builtin.  Items will be filled by FreeTextBox.FillEmptyDefaultDropDowns.
		/// </summary>	
		public static ToolbarDropDownList FontBackColorsMenu {
			get {
				ToolbarDropDownList dropdown = new ToolbarDropDownList("������ɫ","FontBackColorsMenu","FTB_SetFontBackColor");
				dropdown.CommandIdentifier = "backcolor";
				dropdown.ScriptBlock = @"<script language=""JavaScript"">
function FTB_SetFontBackColor(editor,htmlmode,name,value) {
	if (htmlmode) return;
	editor.focus();
	editor.document.execCommand('backcolor','',value);
}
</script>";

				return dropdown;
			}
		}
		/// <summary>
		/// Returns a ToolbarDropDownList with StyleMenu JavaScript functions builtin.  Items will be filled by FreeTextBox.FillEmptyDefaultDropDowns.
		/// </summary>	
		public static ToolbarDropDownList StyleMenu {
			get {
				ToolbarDropDownList dropdown = new ToolbarDropDownList("��ʽ","StyleMenu","FTB_SetStyle");

				dropdown.ScriptBlock = @"<script language=""JavaScript"">
function FTB_SetStyle(editor,htmlmode,name,value) {
	if (htmlmode) return;
	if (value != '') {
		editor.focus();
		editor.document.execCommand('removeFormat');
		editor.document.execCommand('formatBlock','','Normal');
		sel = editor.document.selection.createRange();
		html = '<span class=\'' + value + '\'>' + sel.htmlText + '</span>';
		sel.pasteHTML(html);
	}
}
</script>";
				return dropdown;
			}
		}
		/// <summary>
		/// Returns a ToolbarDropDownList with InsertHtmlMenu JavaScript functions builtin.  Items will be filled by FreeTextBox.FillEmptyDefaultDropDowns.
		/// </summary>	
		public static ToolbarDropDownList InsertHtmlMenu {
			get {
				ToolbarDropDownList dropdown = new ToolbarDropDownList("���� HTML","InsertHtmlMenu","FTB_InsertHtml");

				dropdown.ScriptBlock = @"<script language=""JavaScript"">
function FTB_InsertHtml(editor,htmlmode,name,value) {
	if (htmlmode) return;
	editor.focus();
	sel = editor.document.selection.createRange();
	sel.pasteHTML(value);
}
</script>";
				return dropdown;
			}
		}
		/// <summary>
		/// Returns a ToolbarDropDownList with SymbolsMenu JavaScript functions builtin.  Items will be filled by FreeTextBox.FillEmptyDefaultDropDowns.
		/// </summary>	
		public static ToolbarDropDownList SymbolsMenu {
			get {
				ToolbarDropDownList dropdown = new ToolbarDropDownList("�������","SymbolsMenu","FTB_InsertSymbol");
				dropdown.ScriptBlock = @"<script language=""JavaScript"">
function FTB_InsertSymbol(editor,htmlmode,name,value) {
	if (htmlmode) return;
	editor.focus();
	sel = editor.document.selection.createRange();
	sel.pasteHTML(value);
}
</script>";
				return dropdown;
			}
		}

		/// <summary>
		/// Returns a ToolbarDropDownList with ParagraphMenu JavaScript functions builtin.  Items will be filled by FreeTextBox.FillEmptyDefaultDropDowns.
		/// </summary>	
		public static ToolbarDropDownList ParagraphMenu {
			get {
				ToolbarDropDownList dropdown = new ToolbarDropDownList("�����ʽ","ParagraphMenu","FTB_SetParagraph");
				dropdown.ScriptBlock = @"<script language=""JavaScript"">
function FTB_SetParagraph(editor,htmlmode,name,value) {
	if (htmlmode) return;
	editor.focus();
	if (value == '<body>') {
		editor.document.execCommand('formatBlock','','Normal');
		editor.document.execCommand('removeFormat');
		return;
	}
	editor.document.execCommand('formatBlock','',value);
}
</script>";
				return dropdown;
			}
		}
	}
}