using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Resources;
using System.Collections;
using System.Collections.Specialized;
using System.Text;
using System.Drawing;
using FreeTextBoxControls.Common;

namespace FreeTextBoxControls {
	/// <summary>
	/// A Toolbar for FreeTextBox
	/// </summary>
	public class Toolbar {
		public Toolbar() {}
		public Toolbar(string name) {
			this.Name = name;
		}
		public Toolbar(string name, bool moveable) {
			Name = name;
			Moveable = moveable;
		}
		private string name = "";
		private bool movable = false;
		private bool visible = true;

		/// <summary>
		/// The name of the Toolbar
		/// </summary>
		public string Name  {
			get { return name; }
			set { name = value; }
		}
		/// <summary>
		/// Whether the toolbar will be rendered visible
		/// </summary>
		public bool Visible  {
			get { return visible; }
			set { visible = value; }
		}
		/// <summary>
		/// Not Implimented
		/// </summary>
		public bool Moveable  {
			get { return movable; }
			set { movable = value; }
		}		

		/// <summary>
		/// The Items (ToolbarButton, ToolbarDropDownList, ToolbarSeparator) in the toolbar
		/// </summary>
		public ToolbarItemsList Items = new ToolbarItemsList();
	}
}