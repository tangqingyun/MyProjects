using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FreeTextBoxControls {
	/// <summary>
	/// Abstract class for all toolbar items
	/// </summary>
	public abstract class ToolbarItem {
		public ToolbarItem() {}
		private string title = "";
		private string name = "";
		private bool visible = true;
		private string function = "";
		private string commandIdentifier = "";
		private string scriptBlock = "";
		private string scriptBlockBasic = "";
		private Unit width = new Unit("21px");
		private Unit height = new Unit("20px");

		/// <summary>
		/// The Title of the ToolbarItem
		/// </summary>
		public string Title {
			get { return title; }
			set { title = value; }
		}
		/// <summary>
		/// The Name of the ToolbarItem
		/// </summary>
		public string Name {
			get { return name; }
			set { name = value; }
		}
		/// <summary>
		/// Whether the item is visible
		/// </summary>
		public bool Visible {
			get { return visible; }
			set { visible = value; }
		}
		/// <summary>
		/// The MSHTML specific command identifier used for dynamic updating through the queryCommandState method
		/// </summary>
		public string CommandIdentifier {
			get { return commandIdentifier; }
			set { commandIdentifier = value; }
		}
		/// <summary>
		/// The javascript function fired when the item's action is triggered
		/// </summary>
		public string Function {
			get { return function; }
			set { function = value; }
		}
		/// <summary>
		/// The JavaScript code for the function
		/// </summary>
		public string ScriptBlock {
			get { return scriptBlock; }
			set { scriptBlock = value; }
		}
		/// <summary>
		/// The JavaScript used for the simple editor for Netscape and IE4
		/// </summary>
		public string ScriptBlockBasic {
			get { return scriptBlockBasic; }
			set { scriptBlockBasic = value; }
		}
		/// <summary>
		/// Button Width
		/// </summary>
		public Unit Width {
			get { return width; }
			set { width = value; }
		}
		/// <summary>
		/// Button Height
		/// </summary>
		public Unit Height {
			get { return height; }
			set { height = value; }
		}
	}
}
