using System;
using FreeTextBoxControls.Common;

namespace FreeTextBoxControls {
	/// <summary>
	/// Builds Toolbars and ToolbarItems from strings 
	/// </summary>	
	public class ToolbarGenerator {
		//Toolbar layouts
		public static string DefaultConfigString = "Bold,Italic,Underline,Strikethrough;Superscript,Subscript,RemoveFormat|FontFacesMenu,FontSizesMenu,FontForeColorsMenu|JustifyLeft,JustifyRight,JustifyCenter,JustifyFull;BulletedList,NumberedList,Indent,Outdent;CreateLink,Unlink,InsertImageFromGallery,InsertTable,InsertRule|Cut,Copy,Paste;Undo,Redo,Print,ieSpellCheck";
		public static string AlternateConfigString = "Save,Print,Undo,Redo,WordClean,InsertTable|ParagraphMenu,FontFacesMenu,FontSizesMenu,FontForeColorPicker,FontBackColorPicker,SymbolsMenu|Bold,Italic,Underline,Strikethrough;Superscript,Subscript,RemoveFormat|JustifyLeft,JustifyRight,JustifyCenter,JustifyFull;BulletedList,NumberedList,Indent,Outdent;CreateLink,Unlink,InsertImageFromGallery,InsertRule|Cut,Copy,Paste,ieSpellCheck";
        public static string EnableAllConfigString = "ParagraphMenu,FontFacesMenu,FontSizesMenu|FontForeColorsMenu,FontForeColorPicker,FontBackColorsMenu,FontBackColorPicker|Bold,Italic,Underline,Strikethrough,Superscript,Subscript;InsertImageFromGallery,CreateLink,Unlink,RemoveFormat|JustifyLeft,JustifyRight,JustifyCenter,JustifyFull;BulletedList,NumberedList,Indent,Outdent|Cut,Copy,Paste,Delete;Undo,Redo,Print,Save|StyleMenu,SymbolsMenu,InsertHtmlMenu|InsertRule,InsertDate,InsertTime,WordCount,ieSpellCheck,WordClean,InsertTable|UploadFlash,UploadDocument, UploadZip";
		public static string MinimalConfigString = "Bold,Italic,Underline";
        public static string PublicConfigString = "Bold,Italic,Underline,Strikethrough;Superscript,Subscript,RemoveFormat|FontFacesMenu,FontSizesMenu,FontForeColorsMenu|JustifyLeft,JustifyRight,JustifyCenter,JustifyFull;BulletedList,NumberedList,Indent,Outdent;CreateLink,Unlink,InsertTable,InsertRule|insertdate,inserttime|Cut,Copy,Paste;Undo,Redo,ieSpellCheck|qq,msn,yahoo|UploadImage,insertimage,UploadFlash,UploadDocument, UploadZip|WordClean";	
		
		/// <summary>
		/// Returns a Toolbars with the default configuration
		/// </summary>			
		public static ToolbarList Default {
			get {
				return ToolbarGenerator.ToolbarsFromString(DefaultConfigString);
			}
		}
		/// <summary>
		/// Returns a Toolbars with the all buttons and dropdowns enabled
		/// </summary>			
		public static ToolbarList EnableAll {
			get {
				return ToolbarGenerator.ToolbarsFromString(EnableAllConfigString);
			}
		}
		/// <summary>
		/// Returns a Toolbars with an alternate configuration
		/// </summary>			
		public static ToolbarList Alternate {
			get {
				return ToolbarGenerator.ToolbarsFromString(AlternateConfigString);
			}
		}
		/// <summary>
		/// Returns a Toolbars with only bold, italic, and underline
		/// </summary>			
		public static ToolbarList Minimal {
			get {
				return ToolbarsFromString(MinimalConfigString);
			}
		}

        /// <summary>
        /// ���ⴰ��
        /// </summary>
        public static ToolbarList Public
        {
            get
            {
                return ToolbarsFromString(PublicConfigString);
            }
        }
		/// <summary>
		/// Generates Toolbars from ToolbarLayout string
		/// </summary>
		public static ToolbarList ToolbarsFromString(string toolbarLayout) {
			ToolbarList myToolbars = new ToolbarList();
			try {
				string[] ToolbarStrings = toolbarLayout.Replace(" ","").Replace(";",",;,").Replace(",,",",").ToLower().Split(new char[] {'|'});
				for (int i=0; i<ToolbarStrings.Length; i++) {
					Toolbar myToolBar = new Toolbar("Toolbar" + i.ToString());
					string[] ItemStrings = ToolbarStrings[i].Split(new char[] {','});
					for (int j = 0; j<ItemStrings.Length; j++) {
						myToolBar.Items.Add(ToolbarItemFromString(ItemStrings[j]));
					}
					myToolbars.Add(myToolBar);
				}
			} catch (Exception e) {
				throw new Exception("Invalid ToolbarLayout -> " + e.ToString());
			}
			return myToolbars;
		}	
		/// <summary>
		/// Returns a ToolbarItem from it's string representation.  If an invalid string is given, a ToolbarSeparator is returned.
		/// </summary>
		public static ToolbarItem ToolbarItemFromString(string StringName)  {
			switch (StringName.ToLower()) {
				case "iespellcheck":
					return ToolbarItems.ieSpellCheck;
				case "save":
					return ToolbarItems.Save;
				case "bold":
					return ToolbarItems.Bold;
				case "italic":
					return ToolbarItems.Italic;
				case "underline":
					return ToolbarItems.Underline;
				case "strikethrough":
					return ToolbarItems.Strikethrough;
				case "superscript":
					return ToolbarItems.Superscript;
				case "subscript":
					return ToolbarItems.Subscript;
				case "removeformat":
					return ToolbarItems.RemoveFormat;
				case "fontforecolorpicker":
					return ToolbarItems.FontForeColorPicker;
				case "fontbackcolorpicker":
					return ToolbarItems.FontBackColorPicker;
				case "justifyleft":
					return ToolbarItems.JustifyLeft;
				case "justifycenter":
					return ToolbarItems.JustifyCenter;
				case "justifyright":
					return ToolbarItems.JustifyRight;
				case "justifyfull":
					return ToolbarItems.JustifyFull;
				case "bulletedlist":
					return ToolbarItems.BulletedList;
				case "numberedlist":
					return ToolbarItems.NumberedList;
				case "indent":
					return ToolbarItems.Indent;
				case "outdent":
					return ToolbarItems.Outdent;
				case "cut":
					return ToolbarItems.Cut;
				case "copy":
					return ToolbarItems.Copy;
				case "paste":
					return ToolbarItems.Paste;
				case "delete":
					return ToolbarItems.Delete;
				case "undo":
					return ToolbarItems.Undo;
				case "redo":
					return ToolbarItems.Redo;
				case "print":
					return ToolbarItems.Print;
				case "changecase":
					return ToolbarItems.ChangeCase;
				case "createlink":
					return ToolbarItems.CreateLink;
				case "unlink":
					return ToolbarItems.Unlink;
				case "insertimagefromgallery":
					return ToolbarItems.InsertImageFromGallery;		
				case "insertimage":
					return ToolbarItems.InsertImage;
				case "insertrule":
					return ToolbarItems.InsertRule;
				case "insertdate":
					return ToolbarItems.InsertDate;
				case "inserttime":
					return ToolbarItems.InsertTime;
				case "wordcount":
					return ToolbarItems.WordCount;
				case "fontfacesmenu":
					return ToolbarItems.FontFacesMenu;
				case "fontsizesmenu":
					return ToolbarItems.FontSizesMenu;
				case "fontforecolorsmenu":
					return ToolbarItems.FontForeColorsMenu;
				case "fontbackcolorsmenu":
					return ToolbarItems.FontBackColorsMenu;
				case "stylemenu":
					return ToolbarItems.StyleMenu;
				case "inserthtmlmenu":
					return ToolbarItems.InsertHtmlMenu;
				case "symbolsmenu":
					return ToolbarItems.SymbolsMenu;
				case "paragraphmenu":
					return ToolbarItems.ParagraphMenu;
				case "inserttable":
					return ToolbarItems.InsertTable;
				case "wordclean":
					return ToolbarItems.WordClean;
                case "qq":
                    return ToolbarItems.QQ;
                case "msn":
                    return ToolbarItems.MSN;
                case "yahoo":
                    return ToolbarItems.Yahoo;
                case "uploadimage":
                    return ToolbarItems.UploadImage;
                case "uploadflash":
                    return ToolbarItems.UploadFlash;
                case "uploaddocument":
                    return ToolbarItems.UploadDocument;
                case "uploadzip":
                    return ToolbarItems.UploadZip;
				default:					
					return ToolbarItems.Separator;
			}
		}	
	}
}
