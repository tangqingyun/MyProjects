﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Security.Permissions;
using System.Threading;
using System.Net;
using uni2uni.com.Framework.Common;
using System.IO.Compression;

namespace uni2uni.com.Framework.WebCatch
{
    public class ImageCatchParam
    {
        private string url;

        public string ImageUrl
        {
            get { return url; }
            set { url = value; }
        }
        private string sourceurl;

        public string SourceUrl
        {
            get { return sourceurl; }
            set { sourceurl = value; }
        }
        private ImageUrlParse parse;

        public ImageUrlParse Parse
        {
            get { return parse; }
            set { parse = value; }
        }
        private Proxy proxy;

        public Proxy Proxy
        {
            get { return proxy; }
            set { proxy = value; }
        }
    }

    public class WebBrowserImageDownload
    {
        private static IList<ImageCatchParam> taskList = new List<ImageCatchParam>();
        private static object lockObj = new object();
        private static Thread DownloadThread = new Thread(new ThreadStart(DownloadProc));
        private static bool bStart = false;
        public static void StartDownload()
        {
            if (!bStart)
            {
                bStart = true;
                DownloadThread.SetApartmentState(ApartmentState.STA);
                DownloadThread.Start();

            }
        }

        private static void DownloadProc()
        {
            while (bStart)
            {
                if (taskList.Count > 0)
                {
                    GetImage(taskList[0]);
                    taskList.RemoveAt(0);
                }
                Thread.Sleep(10);
            }
        }

        public static void Stop()
        {
            bStart = false;
            DownloadThread.Join();
        }

        /// <summary>  
        /// 获取源代码  
        /// </summary>  
        /// <param name="url"></param>  
        /// <returns></returns>  
        public static string GetHtml(string url)
        {
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            StreamReader reader = null;
            try
            {
                request = (HttpWebRequest)WebRequest.Create(url);
                request.Timeout = 20000;
                request.AllowAutoRedirect = false;

                response = (HttpWebResponse)request.GetResponse();
                if (response.StatusCode == HttpStatusCode.OK && response.ContentLength < 1024 * 1024)
                {
                    if (response.ContentEncoding != null && response.ContentEncoding.Equals("gzip", StringComparison.InvariantCultureIgnoreCase))
                        reader = new StreamReader(new GZipStream(response.GetResponseStream(), CompressionMode.Decompress), Encoding.GetEncoding(WebBrowserImageDownload.GetEncoding(response)));
                    else
                        reader = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding(WebBrowserImageDownload.GetEncoding(response)));
                    string html = reader.ReadToEnd();
                    return html;
                }
            }
            catch
            {
            }
            finally
            {

                if (response != null)
                {
                    response.Close();
                    response = null;
                }
                if (reader != null)
                    reader.Close();

                if (request != null)
                    request = null;
            }
            return string.Empty;
        }

        private static string GetEncoding(HttpWebResponse response)
        {
            try
            {

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    if (response.CharacterSet != string.Empty)
                    {
                        return response.CharacterSet;
                    }
                    else
                        return Encoding.Default.BodyName;
                }
                else
                {
                    return Encoding.Default.BodyName;
                }
            }
            catch
            {
                return Encoding.Default.BodyName;
            }
        }

        public static void GetImage(string url, string sourceurl, Proxy proxy)
        {
            WebBrowser wb = new WebBrowser();
            try
            {
                string strPath;
                string cachePath;
                if (proxy != null)
                {
                    bool ret = SetProxy(proxy.Proxyip, proxy.Port);
                    SimpleLog.WriteLog("WebBrowserImageDownload", "GetImage,", proxy.Proxyip + "|" + proxy.Port.ToString() + "|" + ret.ToString());
                }
                //ImageUrlParse parse = 
                wb.Navigate(sourceurl);
                DateTime dtStart = DateTime.Now;

                while (wb.ReadyState != WebBrowserReadyState.Complete)
                {
                    System.Windows.Forms.Application.DoEvents();
                    TimeSpan tm = DateTime.Now - dtStart;
                    if (tm.TotalSeconds > 300)
                    {
                        SimpleLog.WriteLog("WebBrowserImageDownload", "GetImage,", "Navigate break！");
                        break;
                    }
                }
                SimpleLog.WriteLog("WebBrowserImageDownload", "GetImage,", "Navigate finished！");

                strPath = GetSaveUrl(url);
                for (int i = 0; i < wb.Document.Images.Count; i++)
                {
                    String strImgUrl = System.Text.RegularExpressions.Regex.Match(wb.Document.Images[i].OuterHtml, "src=\"(?<var>.*?)\"").Groups["var"].ToString();

                    SimpleLog.WriteLog("WebBrowserImageDownload", "GetImage,", strPath);
                    if (!File.Exists(strPath))
                    {
                        cachePath = GetPathForCachedFile(strImgUrl);
                        SimpleLog.WriteLog("WebBrowserImageDownload", "GetImage,", cachePath);
                        File.Copy(cachePath, strPath);
                    }
                }
            }
            catch (ThreadStateException ex)
            {
                SimpleLog.WriteLog("WebBrowserImageDownload", "GetImage,", ex.Message);
            }
            catch (ExternalException ex)
            {
                SimpleLog.WriteLog("WebBrowserImageDownload", "GetImage,", ex.Message);
            }
            catch (Exception ex)
            {
                SimpleLog.WriteLog("WebBrowserImageDownload", "GetImage,", ex.Message);
            }
            finally
            {
                wb.Dispose();
            }

        }

        public static string GetSourceImage(string url, ImageUrlParse parse, Proxy proxy)
        {
            //string strImageId = Regex.Match(url, "/(?<var>\\d+)_\\d+_\\d+.jpg").Groups["var"].ToString();
            string sourceUrl = string.Empty;
            //if (strImageId != null && strImageId != null)
            //{
            //    string strImageUrl = "http://www.zhigou.com//product-picture-" + strImageId + ".html";

            //    string strHtml = GetHtmlContext(strImageUrl, "gb2312", ProxyCatch.Instance.GetProxy(ProxyCatch.ProxyOrder.Sequence));
            //    if (strHtml == "error")
            //    {
            //        return GetSourceImage(url, parse, proxy);
            //    }
            //    else
            //    {
            //        sourceUrl = Regex.Match(strHtml, "prodImg.*?src=\"(?<img>.*?)\"").Groups["img"].ToString();
            sourceUrl = url.Replace("_200_200", "").Replace("_100_100", "");
                    ImageCatchParam param = new ImageCatchParam();
                    param.ImageUrl = url;
                    param.SourceUrl = sourceUrl;
                    param.Parse = parse;
                    param.Proxy = proxy;
                    taskList.Add(param);
                //}
                //ThreadPool.QueueUserWorkItem(new WaitCallback(GetImage), param);
            //}
            return sourceUrl;
        }


        public static void GetImage(object param)
        {
            ImageCatchParam catchParam = (ImageCatchParam)param;
            GetImage(catchParam.ImageUrl, catchParam.SourceUrl, catchParam.Proxy);
        }

        /// <summary>
        /// 获取网页数据流
        /// </summary>
        /// <param name="url">url</param>
        /// <returns>数据流</returns>
        public static string GetHtmlContext(string url, string code, Proxy proxy)
        {
            string html = string.Empty;
            try
            {
                HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(url);
                CookieContainer cc = new CookieContainer();
                myRequest.Method = "GET";
                if (proxy != null)
                {
                    myRequest.Proxy = new WebProxy(proxy.Proxyip, proxy.Port);
                }
                myRequest.ContentType = "application/x-www-form-urlencoded";
                myRequest.CookieContainer = cc;
                myRequest.Accept = "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-ms-application, application/x-ms-xbap, application/vnd.ms-xpsdocument, application/xaml+xml, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, application/x-shockwave-flash, */*";
                myRequest.UserAgent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; InfoPath.2; CIBA; Alexa Toolbar)";
                myRequest.Timeout = 15000;
                HttpWebResponse myResponse = (HttpWebResponse)myRequest.GetResponse();
                /*switch (myResponse.StatusCode)
                {
                    case HttpStatusCode.Redirect:
                        return GetHtmlContext(myResponse.GetResponseHeader(
                }*/
                Encoding encoding = Encoding.UTF8;
                if (code.ToLower() == "gb2312")
                {
                    encoding = Encoding.GetEncoding("gb2312");
                }
                StreamReader reader = new StreamReader(myResponse.GetResponseStream(), encoding);
                html = reader.ReadToEnd();
                if (html == "" || html == null)
                {
                    html = "Error";
                }
                myResponse.Close();
                reader.Close();
            }
            catch
            {
                html = "Error";
            }
            return html;
        }

        /// <summary>
        /// 获取图片存储路径
        /// </summary>
        /// <param name="strimg">图片地址</param>
        /// <returns>存储路径</returns>
        public static string GetSaveUrl(string strimg)
        {
            string Fpath = System.Configuration.ConfigurationSettings.AppSettings["FileUploadSite"];
            string path = Fpath;

            string[] tmpUrlImg = strimg.Replace("http://", "").Replace(@"http:\\", "").Split('/');
            if (tmpUrlImg.Length == 1 && strimg.IndexOf(@"\") > 0)
            {
                tmpUrlImg = strimg.Replace("http://", "").Replace(@"http:\\", "").Split('\\');
            }

            for (int i = 0; i < tmpUrlImg.Length - 1; i++)
            {
                path += tmpUrlImg[i] + "\\";
            }
            //path = path.Replace("\\img.zhigou.com", "");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            return path + tmpUrlImg[tmpUrlImg.Length - 1];
        }

        #region 设置代理
        public struct Struct_INTERNET_PROXY_INFO
        {
            public int dwAccessType;
            public IntPtr proxy;
            public IntPtr proxyBypass;
        };

        [DllImport("wininet.dll", SetLastError = true)]
        private static extern bool InternetSetOption(IntPtr hInternet, int dwOption, IntPtr lpBuffer, int lpdwBufferLength);
        [DllImport("Wininet.dll", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern Boolean GetUrlCacheEntryInfo(String lpxaUrlName, IntPtr lpCacheEntryInfo, ref int lpdwCacheEntryInfoBufferSize);

        public static bool RefreshIESettings(string strProxy)
        {
            const int INTERNET_OPTION_PROXY = 38;
            const int INTERNET_OPEN_TYPE_PROXY = 3;
            Struct_INTERNET_PROXY_INFO struct_IPI;
            // Filling in structure 
            struct_IPI.dwAccessType = INTERNET_OPEN_TYPE_PROXY;
            struct_IPI.proxy = Marshal.StringToHGlobalAnsi(strProxy);
            struct_IPI.proxyBypass = Marshal.StringToHGlobalAnsi("local");
            // Allocating memory 
            IntPtr intptrStruct = Marshal.AllocCoTaskMem(Marshal.SizeOf(struct_IPI));
            // Converting structure to IntPtr 
            Marshal.StructureToPtr(struct_IPI, intptrStruct, true);
            bool iReturn = InternetSetOption(IntPtr.Zero, INTERNET_OPTION_PROXY, intptrStruct, Marshal.SizeOf(struct_IPI));
            return iReturn;
        }

        const int ERROR_FILE_NOT_FOUND = 0x2;
        struct LPINTERNET_CACHE_ENTRY_INFO
        {
            public int dwStructSize;
            IntPtr lpszSourceUrlName;
            public IntPtr lpszLocalFileName;
            int CacheEntryType;
            int dwUseCount;
            int dwHitRate;
            int dwSizeLow;
            int dwSizeHigh;
            FILETIME LastModifiedTime;
            FILETIME Expiretime;
            FILETIME LastAccessTime;
            FILETIME LastSyncTime;
            IntPtr lpHeaderInfo;
            int dwheaderInfoSize;
            IntPtr lpszFileExtension;
            int dwEemptDelta;
        }

        // 返回 指定URL文件的缓存在本地文件系统中的路径
        private static string GetPathForCachedFile(string fileUrl)
        {
            int cacheEntryInfoBufferSize = 0;
            IntPtr cacheEntryInfoBuffer = IntPtr.Zero;
            int lastError; Boolean result;
            try
            {
                result = GetUrlCacheEntryInfo(fileUrl, IntPtr.Zero, ref cacheEntryInfoBufferSize);
                lastError = Marshal.GetLastWin32Error();
                if (result == false)
                {
                    if (lastError == ERROR_FILE_NOT_FOUND) return null;
                }
                cacheEntryInfoBuffer = Marshal.AllocHGlobal(cacheEntryInfoBufferSize);

                result = GetUrlCacheEntryInfo(fileUrl, cacheEntryInfoBuffer, ref cacheEntryInfoBufferSize);
                lastError = Marshal.GetLastWin32Error();
                if (result == true)
                {
                    Object strObj = Marshal.PtrToStructure(cacheEntryInfoBuffer, typeof(LPINTERNET_CACHE_ENTRY_INFO));
                    LPINTERNET_CACHE_ENTRY_INFO internetCacheEntry = (LPINTERNET_CACHE_ENTRY_INFO)strObj;
                    String localFileName = Marshal.PtrToStringAuto(internetCacheEntry.lpszLocalFileName); return localFileName;
                }
                else return null;// file not found
            }
            finally
            {
                if (!cacheEntryInfoBuffer.Equals(IntPtr.Zero)) Marshal.FreeHGlobal(cacheEntryInfoBuffer);
            }
        }

        private static bool SetProxy(string strProxyip, int nProxyPort)
        {
            return RefreshIESettings(strProxyip + ":" + nProxyPort.ToString());
        }

        #endregion
    }

    public class ImageUrlParseFactory
    {
        public static ImageUrlParse CreateParse(string url)
        {
            string strDomain = string.Empty;
            strDomain = Regex.Match(url, "http://(?<host>.*?)/").Groups["host"].ToString();
            ImageUrlParse parse;
            switch (strDomain)
            {
                case "img.zhigou.com":
                    parse = new ZhigouImageUrlParse();
                    break;
                default:
                    parse = new ImageUrlParse();
                    break;
            }
            return parse;
        }
    }
    public class ImageUrlParse
    {
        public ImageUrlParse()
        {
        }

        public virtual string Parse(string url)
        {
            return url;
        }
    }

    public class ZhigouImageUrlParse : ImageUrlParse
    {
        public override string Parse(string url)
        {
            MatchCollection mc = Regex.Matches(url, "/(\\d+)/");
            string strID = mc[1].Groups[1].ToString();
            string strUrl = "http://www.zhigou.com/product-price-" + strID + ".html?isnow";
            SimpleLog.WriteLog("ZhigouImageUrlParse", "ImageUrlParse,", strUrl);
            return strUrl;
        }
    }


}
