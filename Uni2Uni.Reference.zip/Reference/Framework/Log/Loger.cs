﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Test.cs
//
//  功能描述：  订单领域模型
//
//  作者(Author):		测试
//
//  日期(Create Date):		2013.5.29
//
//  修改记录(Revision History):
//	R1:
//		修改作者:	张三
//		修改日期:	2013.5.29
//		修改理由:	由于某些原因对其中的一些功能进行相关
//				    修改。
//	R2:
//		修改作者:	张三
//		修改日期:	2013.5.29
//		修改理由:	由于某些原因对其中的一些功能进行相关
//				    修改。
//
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace uni2uni.com.Framework.Log
{
    internal class Loger:ILog
    {
        log4net.ILog loger;
        public Loger(log4net.ILog loger)
        {
            this.loger = loger;
        }

        public void Debug(object message, Exception exception)
        {
            loger.Debug(message, exception);
        }

        public void Debug(object message)
        {
            loger.Debug(message);
        }

        public void DebugFormat(IFormatProvider provider, string format, params object[] args)
        {
            loger.DebugFormat(provider, format, args);
        }

        public void DebugFormat(string format, object arg0, object arg1, object arg2)
        {
            loger.DebugFormat(format, arg0, arg1, arg2);
        }

        public void DebugFormat(string format, object arg0, object arg1)
        {
            loger.DebugFormat(format, arg0, arg1);
        }

        public void DebugFormat(string format, object arg0)
        {
            loger.DebugFormat(format, arg0);
        }

        public void DebugFormat(string format, params object[] args)
        {
            loger.DebugFormat(format, args);
        }

        public void Error(object message, Exception exception)
        {
            loger.Error(message, exception);
        }

        public void Error(object message)
        {
            loger.Error(message);
        }

        public void ErrorFormat(IFormatProvider provider, string format, params object[] args)
        {
            loger.ErrorFormat(provider, format, args);
        }

        public void ErrorFormat(string format, object arg0, object arg1, object arg2)
        {
            loger.ErrorFormat(format, arg0, arg1, arg2);
        }

        public void ErrorFormat(string format, object arg0, object arg1)
        {
            loger.ErrorFormat(format, arg0, arg1);
        }

        public void ErrorFormat(string format, object arg0)
        {
            loger.ErrorFormat(format, arg0);
        }

        public void ErrorFormat(string format, params object[] args)
        {
            loger.ErrorFormat(format, args);
        }

        public void Fatal(object message, Exception exception)
        {
            loger.Fatal(message, exception);
        }

        public void Fatal(object message)
        {
            loger.Fatal(message);
        }

        public void FatalFormat(IFormatProvider provider, string format, params object[] args)
        {
            loger.FatalFormat(provider, format, args);
        }

        public void FatalFormat(string format, object arg0, object arg1, object arg2)
        {
            loger.FatalFormat(format, arg0, arg1, arg2);
        }

        public void FatalFormat(string format, object arg0, object arg1)
        {
            loger.FatalFormat(format, arg0, arg1);
        }

        public void FatalFormat(string format, object arg0)
        {
            loger.FatalFormat(format, arg0);
        }

        public void FatalFormat(string format, params object[] args)
        {
            loger.FatalFormat(format, args);
        }

        public void Info(object message, Exception exception)
        {
            loger.Info(message, exception);
        }

        public void Info(object message)
        {
            loger.Info(message);
        }

        public void InfoFormat(IFormatProvider provider, string format, params object[] args)
        {
            loger.InfoFormat(provider, format, args);
        }

        public void InfoFormat(string format, object arg0, object arg1, object arg2)
        {
            loger.InfoFormat(format, arg0, arg1, arg2);
        }

        public void InfoFormat(string format, object arg0, object arg1)
        {
            loger.InfoFormat(format, arg0, arg1);
        }

        public void InfoFormat(string format, object arg0)
        {
            loger.InfoFormat(format, arg0);
        }

        public void InfoFormat(string format, params object[] args)
        {
            loger.InfoFormat(format, args);
        }

        public bool IsDebugEnabled
        {
            get { return loger.IsDebugEnabled; }
        }

        public bool IsErrorEnabled
        {
            get { return loger.IsErrorEnabled; }
        }

        public bool IsFatalEnabled
        {
            get { return loger.IsFatalEnabled; }
        }

        public bool IsInfoEnabled
        {
            get { return loger.IsInfoEnabled; }
        }

        public bool IsWarnEnabled
        {
            get { return loger.IsWarnEnabled; }
        }

        public void Warn(object message, Exception exception)
        {
            loger.Warn(message,exception);
        }

        public void Warn(object message)
        {
            loger.Warn(message);
        }

        public void WarnFormat(IFormatProvider provider, string format, params object[] args)
        {
            loger.WarnFormat(provider, format, args);
        }

        public void WarnFormat(string format, object arg0, object arg1, object arg2)
        {
            loger.WarnFormat(format,arg0,arg1,arg2);
        }

        public void WarnFormat(string format, object arg0, object arg1)
        {
            loger.WarnFormat(format, arg0, arg1);
        }

        public void WarnFormat(string format, object arg0)
        {
            loger.WarnFormat(format, arg0);
        }

        public void WarnFormat(string format, params object[] args)
        {
            loger.WarnFormat(format, args);
        }

        public log4net.Core.ILogger Logger
        {
            get { return loger.Logger; }
        }
    }
}
