﻿// *****************************************************************
//
//  Copyright (C) 2013 北京时空信联网络技术有限公司版权所有。 
// 
//  文件名(File Name):		Test.cs
//
//  功能描述：  订单领域模型
//
//  作者(Author):		测试
//
//  日期(Create Date):		2013.5.29
//
//  修改记录(Revision History):
//	R1:
//		修改作者:	张三
//		修改日期:	2013.5.29
//		修改理由:	由于某些原因对其中的一些功能进行相关
//				    修改。
//	R2:
//		修改作者:	张三
//		修改日期:	2013.5.29
//		修改理由:	由于某些原因对其中的一些功能进行相关
//				    修改。
//
// ******************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using log4net;

namespace uni2uni.com.Framework.Log
{
    public class LogManager
    {
        /// <summary>
        /// 配置并启动日志系统
        /// </summary>
        /// <param name="logFileName"></param>
        public static void Configuration(string logFileName)
        {
            FileInfo file = new FileInfo(logFileName);
            log4net.Config.XmlConfigurator.ConfigureAndWatch(file);
        }
        /// <summary>
        /// 获取一个日志记录器
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static ILog GetLogger(string name)
        {
            return new Loger(log4net.LogManager.GetLogger(name));
        }

        /// <summary>
        /// 如果日志名存在,则返回该日志
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static ILog Exists(string name)
        {
            return new Loger(log4net.LogManager.Exists(name));
        }

        /// <summary>
        /// 获取一个日志记录器
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static ILog GetLogger(Type type)
        {
            return new Loger(log4net.LogManager.GetLogger(type));
        }
        /// <summary>
        /// 获取当前所有的日志
        /// </summary>
        /// <returns></returns>
        public static IEnumerable<ILog> GetCurrentLoggers()
        {
            return log4net.LogManager.GetCurrentLoggers().Select(m => new Loger(m));
        }

        /// <summary>
        /// 关闭日志系统
        /// </summary>
        public void Shutdown()
        {
            log4net.LogManager.Shutdown();
        }
    }
}
