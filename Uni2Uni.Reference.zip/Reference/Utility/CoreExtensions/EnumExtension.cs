﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace uni2uni.com.Utility.CoreExtensions
{
    public static class EnumExtension
    {
        private static Type attrType = typeof(EnumStrValAttribute);

        /// <summary>
        /// 扩展枚举类型的ToString方法实现枚举值的字符串表示
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public static string TString(this Enum e)
        {
            var type = e.GetType();
            var values = Enum.GetValues(type).Cast<Enum>();
            var Fiels = type.GetFields(System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public);
            Func<Enum, bool> filter = null;

            if (!type.GetCustomAttributes(true).Any(a => typeof(FlagsAttribute).IsAssignableFrom(a.GetType())))
            {
                filter = (val) => val.CompareTo(e) == 0;
            }
            else
            {
                filter = (val) => e.HasFlag(val);
            }

            StringBuilder sb = new StringBuilder();
            foreach (var f in Fiels)
            {
                Enum val = f.GetValue(null) as Enum;
                if (filter(val))
                {
                    var attrStrVal = f.GetCustomAttributes(attrType, false).FirstOrDefault() as EnumStrValAttribute;
                    if (null != attrStrVal)
                    {
                        sb.Append(attrStrVal.StringValue);
                    }
                    else
                    {
                        sb.Append(val.ToString());
                    }
                    sb.Append(",");
                }
            }
            return sb.ToString().TrimEnd(',');
        }
    }
}
