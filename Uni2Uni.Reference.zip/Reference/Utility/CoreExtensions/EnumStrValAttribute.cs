﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace uni2uni.com.Utility.CoreExtensions
{
    public class EnumStrValAttribute : Attribute
    {
        private string _value;
        public string StringValue
        {
            get
            {
                return _value;
            }
        }

        public EnumStrValAttribute(string value)
        {
            this._value = value;
        }
    }
}
