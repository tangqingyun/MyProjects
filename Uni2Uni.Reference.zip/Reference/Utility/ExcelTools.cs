﻿using System;
using System.Data;
using System.IO;
using System.Text;
using NPOI.HSSF.UserModel;

namespace uni2uni.com.Utility
{
    public class ExcelTools
    {
        public static Stream DataTableToExcel(DataTable sourceTable)
        {
            var workbook = new HSSFWorkbook();
            var ms = new MemoryStream();
            HSSFSheet sheet = workbook.CreateSheet();
            HSSFRow headerRow = sheet.CreateRow(0);

            foreach (DataColumn column in sourceTable.Columns)
                headerRow.CreateCell(column.Ordinal).SetCellValue(column.ColumnName);

            int rowIndex = 1;

            foreach (DataRow row in sourceTable.Rows)
            {
                HSSFRow dataRow = sheet.CreateRow(rowIndex);

                foreach (DataColumn column in sourceTable.Columns)
                {
                    dataRow.CreateCell(column.Ordinal).SetCellValue(row[column].ToString());
                }

                rowIndex++;
            }

            workbook.Write(ms);
            ms.Flush();
            ms.Position = 0;

            return ms;
        }

        public static void DataTableToExcel(DataTable sourceTable, string fileName)
        {
            var ms = DataTableToExcel(sourceTable) as MemoryStream;
            var fs = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            byte[] data = ms.ToArray();

            fs.Write(data, 0, data.Length);
            fs.Flush();
            fs.Close();
        }

        public static DataTable DataTableFromExcel(Stream excelFileStream, string sheetName, int headerRowIndex)
        {
            HSSFWorkbook workbook = new HSSFWorkbook(excelFileStream);
            HSSFSheet sheet = workbook.GetSheet(sheetName);

            DataTable table = new DataTable();

            HSSFRow headerRow = sheet.GetRow(headerRowIndex);
            int cellCount = headerRow.LastCellNum;

            for (int i = headerRow.FirstCellNum; i < cellCount; i++)
            {
                DataColumn column = new DataColumn(headerRow.GetCell(i).StringCellValue);
                table.Columns.Add(column);
            }
            for (int i = (sheet.FirstRowNum + 1); i < sheet.LastRowNum; i++)
            {
                HSSFRow row = sheet.GetRow(i);
                DataRow dataRow = table.NewRow();

                for (int j = row.FirstCellNum; j < cellCount; j++)
                    dataRow[j] = row.GetCell(j).ToString();
            }

            excelFileStream.Close();
            return table;
        }

        #region 读取Excel文件内容转换为DataSet

        /// <summary>
        /// 执行单EXCEL数据读取
        /// </summary>
        /// <param name="FileName"></param>
        /// <param name="type">导入类型</param>
        /// <returns></returns>
        public static DataTable ReadPetrolExecuteExcel(string FileName, int type)
        {
            return ReadExcel(FileName, 1, type).Tables[0];
        }

        /// <summary>  
        /// 读取Excel文件内容转换为DataSet,列名依次为 "c0"……c[columnlength-1]  
        /// </summary>  
        /// <param name="FileName">文件绝对路径</param>  
        /// <param name="startRow">数据开始行数（1为第一行）</param>  
        /// <param name="type">导入类型 </param>
        /// <returns></returns>  
        public static DataSet ReadExcel(string FileName, int startRow, int type)
        {
            var ds = new DataSet("ds");
            var dt = new DataTable("dt");
            var sb = new StringBuilder();
            using (var stream = new FileStream(@FileName, FileMode.Open, FileAccess.Read))
            {
                var workbook = new HSSFWorkbook(stream);//整个Excel文件 
                var sheet = workbook.GetSheetAt(0);//得到里面第一个sheet  
                var rowTitle = sheet.GetRow(0);
                for (var i = 0; i < rowTitle.LastCellNum; i++)
                {
                    dt.Columns.Add(GetCellData(datatype.String, rowTitle, i).ToString(), Type.GetType("System.String"));
                }
                var cols = dt.Columns;

                ValidExcel(cols, type);

                for (var i = startRow; i <= sheet.LastRowNum; i++)
                {
                    var row = sheet.GetRow(i);//得到第i行
                    try
                    {
                        var dr = dt.NewRow();
                        for (var j = 0; j < dt.Columns.Count; j++)
                        {
                            if (cols[j].ColumnName.Contains("日期"))
                            {
                                dr[cols[j].ColumnName] = GetCellData(datatype.Datetime, row, j).ToString();                               
                            }
                            else
                            {
                                dr[cols[j].ColumnName] = GetCellData(datatype.String, row, j).ToString();
                            }
                        }
                        dt.Rows.Add(dr);
                    }
                    catch (Exception er)
                    {
                        sb.Append(string.Format("第{0}行出错：{1}\r\n", i + 1, er.Message));
                        continue;
                    }
                }
                ds.Tables.Add(dt);
                if (ds.Tables[0].Rows.Count != sheet.LastRowNum - 1 && sb.ToString() != "")
                {
                    throw new Exception(sb.ToString());
                }
            }
            return ds;
        }

        /// <summary>
        ///  验证发票信息
        /// </summary>
        /// <param name="cols"></param>
        /// <param name="type"></param>
        private static void ValidExcel(DataColumnCollection cols, int type)
        {
            if (type == 1)
            {
                if (!cols.Contains("订单号")) throw new Exception("你导入的EXCEL不包含‘订单号’列！");
                if (!cols.Contains("加油卡号")) throw new Exception("你导入的EXCEL不包含‘加油卡号’列！");
                if (!cols.Contains("运单号")) throw new Exception("你导入的EXCEL不包含‘运单号’列！");
                if (!cols.Contains("执行人")) throw new Exception("你导入的EXCEL不包含‘执行人’列！");
                if (!cols.Contains("执行日期")) throw new Exception("你导入的EXCEL不包含‘执行日期’列！");
            }
            else if (type == 2)
            {
                if (!cols.Contains("订单号")) throw new Exception("你导入的EXCEL不包含‘订单号’列！");
                if (!cols.Contains("发票号")) throw new Exception("你导入的EXCEL不包含‘发票号’列！");
                if (!cols.Contains("发票金额")) throw new Exception("你导入的EXCEL不包含‘发票金额’列！");
                if (!cols.Contains("运单号")) throw new Exception("你导入的EXCEL不包含‘运单号’列！");
                if (!cols.Contains("执行人")) throw new Exception("你导入的EXCEL不包含‘执行人’列！");
                if (!cols.Contains("执行日期")) throw new Exception("你导入的EXCEL不包含‘执行日期’列！");
                if (!cols.Contains("执行月份")) throw new Exception("你导入的EXCEL不包含‘执行月份’列！");
            }
            else if (type == 3)
            {
                if (!cols.Contains("服务单号")) throw new Exception("你导入的EXCEL不包含‘服务单号’列！");
                if (!cols.Contains("需执行日期")) throw new Exception("你导入的EXCEL不包含‘需执行日期’列！");
                if (!cols.Contains("副卡卡号")) throw new Exception("你导入的EXCEL不包含‘副卡卡号’列！");
                if (!cols.Contains("充值金额")) throw new Exception("你导入的EXCEL不包含‘充值金额’列！");
                if (!cols.Contains("交易流水号")) throw new Exception("你导入的EXCEL不包含‘交易流水号’列！");
                if (!cols.Contains("交易日期")) throw new Exception("你导入的EXCEL不包含‘交易日期’列！");
            }
            else if (type == 4)
            {
                if (!cols.Contains("服务单号")) throw new Exception("你导入的EXCEL不包含‘服务单号’列！");
                if (!cols.Contains("子主卡卡号")) throw new Exception("你导入的EXCEL不包含‘子主卡卡号’列！");
                if (!cols.Contains("加油卡号")) throw new Exception("你导入的EXCEL不包含‘加油卡号’列！");
                if (!cols.Contains("运单号")) throw new Exception("你导入的EXCEL不包含‘运单号’列！");
                if (!cols.Contains("执行日期")) throw new Exception("你导入的EXCEL不包含‘执行日期’列！");
                if (!cols.Contains("执行人")) throw new Exception("你导入的EXCEL不包含‘执行人’列！");
            }
            else if (type == 5)
            {
                if (!cols.Contains("服务单号")) throw new Exception("你导入的EXCEL不包含‘服务单号’列！");
                if (!cols.Contains("需执行日期")) throw new Exception("你导入的EXCEL不包含‘需执行日期’列！");
                if (!cols.Contains("加油卡号")) throw new Exception("你导入的EXCEL不包含‘加油卡号’列！");
                if (!cols.Contains("运单号")) throw new Exception("你导入的EXCEL不包含‘运单号’列！");
                if (!cols.Contains("执行人")) throw new Exception("你导入的EXCEL不包含‘执行人’列！");
                if (!cols.Contains("快递公司")) throw new Exception("你导入的EXCEL不包含‘快递公司’列！");
                if (!cols.Contains("执行日期")) throw new Exception("你导入的EXCEL不包含‘执行日期’列！");
            }
            else if (type == 6)
            {
                if (!cols.Contains("服务单号")) throw new Exception("你导入的EXCEL不包含‘服务单号’列！");
                if (!cols.Contains("发票号")) throw new Exception("你导入的EXCEL不包含‘发票号’列！");
                if (!cols.Contains("发票金额")) throw new Exception("你导入的EXCEL不包含‘发票金额’列！");
                if (!cols.Contains("运单号")) throw new Exception("你导入的EXCEL不包含‘运单号’列！");
                if (!cols.Contains("执行人")) throw new Exception("你导入的EXCEL不包含‘执行人’列！");
                if (!cols.Contains("执行日期")) throw new Exception("你导入的EXCEL不包含‘执行日期’列！");
                if (!cols.Contains("执行月份")) throw new Exception("你导入的EXCEL不包含‘执行月份’列！");
                if (!cols.Contains("快递公司")) throw new Exception("你导入的EXCEL不包含‘快递公司’列！");
            }
            else if (type == 7)
            {
                if (!cols.Contains("订单号")) throw new Exception("你导入的EXCEL不包含‘订单号’列！");
                if (!cols.Contains("需执行日期")) throw new Exception("你导入的EXCEL不包含‘需执行日期’列！");
                if (!cols.Contains("NC单据号")) throw new Exception("你导入的EXCEL不包含‘NC单据号’列！");              
                if (!cols.Contains("执行人")) throw new Exception("你导入的EXCEL不包含‘执行人’列！");               
            }
            else if (type ==8)
            {
                if (!cols.Contains("预订单号")) throw new Exception("你导入的EXCEL不包含‘预订单号’列！");
                if (!cols.Contains("服务单号")) throw new Exception("你导入的EXCEL不包含‘服务单号’列！");
            } 
            else if (type == 9)
            {
                if (!cols.Contains("手机号")) throw new Exception("你导入的EXCEL不包含‘手机号’列！");
                //if (!cols.Contains("短信内容")) throw new Exception("你导入的EXCEL不包含‘短信内容’列！"); 
            }
            else
            {
                if (!cols.Contains("订单号")) throw new Exception("你导入的EXCEL不包含‘订单号’列！");
                if (!cols.Contains("加油卡号")) throw new Exception("你导入的EXCEL不包含‘加油卡号’列！");
                if (!cols.Contains("易捷订单号")) throw new Exception("你导入的EXCEL不包含‘易捷订单号’列！");
                if (!cols.Contains("执行人")) throw new Exception("你导入的EXCEL不包含‘执行人’列！");
                if (!cols.Contains("执行日期")) throw new Exception("你导入的EXCEL不包含‘执行日期’列！");
                if (!cols.Contains("易捷账户")) throw new Exception("你导入的EXCEL不包含‘易捷账户’列！");
                if (!cols.Contains("易捷密码")) throw new Exception("你导入的EXCEL不包含‘易捷密码’列！");
            }
        }
        #endregion

        #region 得到不同数据类型单元格的数据
        /// <summary>  
        /// 得到不同数据类型单元格的数据  
        /// </summary>  
        /// <param name="datatype">数据类型</param>  
        /// <param name="row">数据中的一行</param>  
        /// <param name="column">哪列</param>  
        /// <returns></returns>  
        public static object GetCellData(datatype datatype, HSSFRow row, int column)
        {

            switch (datatype)
            {
                case datatype.String:
                    try { return row.GetCell(column).StringCellValue; }
                    catch { return row.GetCell(column).NumericCellValue; }
                case datatype.Bool:
                    try { return row.GetCell(column).BooleanCellValue; }
                    catch { return row.GetCell(column).StringCellValue; }
                case datatype.Datetime:
                    try { return row.GetCell(column).DateCellValue; }
                    catch { return row.GetCell(column).StringCellValue; }
                case datatype.Double:
                    try { return row.GetCell(column).NumericCellValue; }
                    catch { return row.GetCell(column).StringCellValue; }
                case datatype.Richtext:
                    try { return row.GetCell(column).RichStringCellValue; }
                    catch { return row.GetCell(column).StringCellValue; }
                default: return "";
            }
        }
        #endregion

        #region 枚举（单元格数据类型）
        /// <summary>  
        /// 枚举（单元格数据类型）  
        /// </summary>  
        public enum datatype
        {
            /// <summary>  
            /// String=1  
            /// </summary>  
            String = 1,
            /// <summary>  
            /// Bool=2  
            /// </summary>  
            Bool = 2,
            /// <summary>  
            /// Datetime=3  
            /// </summary>  
            Datetime = 3,
            /// <summary>  
            /// Double=4  
            /// </summary>  
            Double = 4,
            /// <summary>  
            /// Richtext=5  
            /// </summary>  
            Richtext = 5
        }
        #endregion

        public static DataTable ExcelToDataTable(string FileName, string sheetName, int headerRowIndex)
        {
            var stream = new FileStream(@FileName, FileMode.Open, FileAccess.Read);
            HSSFWorkbook workbook = new HSSFWorkbook(stream);
            HSSFSheet sheet = workbook.GetSheet(sheetName);

            DataTable table = new DataTable();

            HSSFRow headerRow = sheet.GetRow(headerRowIndex);
            int cellCount = headerRow.LastCellNum;
            DataColumn column = new DataColumn("CardNo");
            table.Columns.Add(column);
            for (int i = sheet.FirstRowNum; i <= sheet.LastRowNum; i++)
            {
                HSSFRow row = sheet.GetRow(i);
                DataRow dataRow = table.NewRow();
                for (int j = row.FirstCellNum; j < 1; j++)
                    dataRow[j] = row.GetCell(j).ToString();
                table.Rows.Add(dataRow);
            }
            stream.Close();
            return table;
        }

        #region CloudCardSend将Excel转为DataTable

        public static DataTable CloudCardSendImport(string FileName)
        {
            return ReadExcel(FileName, 1);
        }

        public static DataTable ReadExcel(string FileName, int startRow)
        {
            // var ds = new DataSet("ds");
            var dt = new DataTable("dt");
            var sb = new StringBuilder();
            using (var stream = new FileStream(@FileName, FileMode.Open, FileAccess.Read))
            {
                var workbook = new HSSFWorkbook(stream);//整个Excel文件 
                var sheet = workbook.GetSheetAt(0);//得到里面第一个sheet  
                var rowTitle = sheet.GetRow(0);
                for (var i = 0; i < 8; i++)
                {
                    dt.Columns.Add(GetCellData(datatype.String, rowTitle, i).ToString(), Type.GetType("System.String"));
                }
                var cols = dt.Columns;
                for (var i = startRow; i <= sheet.LastRowNum; i++)
                {
                    var row = sheet.GetRow(i);//得到第i行
                    try
                    {
                        var dr = dt.NewRow();
                        for (var j = 0; j < dt.Columns.Count; j++)
                        {
                            if (cols[j].ColumnName.Contains("日期"))
                            {
                                dr[cols[j].ColumnName] = GetCellData(datatype.Datetime, row, j).ToString();
                            }
                            else
                            {
                                dr[cols[j].ColumnName] = GetCellData(datatype.String, row, j).ToString();
                            }
                        }
                        dt.Rows.Add(dr);
                    }
                    catch (Exception er)
                    {
                        sb.Append(string.Format("第{0}行出错：{1}\r\n", i + 1, er.Message));
                        continue;
                    }
                }
                if (dt.Rows.Count != sheet.LastRowNum - 1 && sb.ToString() != "")
                {
                    throw new Exception(sb.ToString());
                }
            }
            return dt;
        }

        #endregion

        public static DataTable TableFromExcel(Stream excelFileStream, int headerRowIndex)
        {
            HSSFWorkbook workbook = new HSSFWorkbook(excelFileStream);
            HSSFSheet sheet = workbook.GetSheetAt(0);

            DataTable table = new DataTable();

            HSSFRow headerRow = sheet.GetRow(headerRowIndex);
            int cellCount = headerRow.LastCellNum;

            for (int i = headerRow.FirstCellNum; i < cellCount; i++)
            {
                //string cellval = headerRow.GetCell(i).StringCellValue;
                //if (string.IsNullOrEmpty(headerRow.GetCell(i).StringCellValue))
                //    continue;
                DataColumn column = new DataColumn(headerRow.GetCell(i).ToString());
                table.Columns.Add(column);
            }
            for (int i = (sheet.FirstRowNum + 1); i < sheet.LastRowNum+1; i++)
            {
                HSSFRow row = sheet.GetRow(i);
                if (object.Equals(null, row))
                    break;
                DataRow dataRow = table.NewRow();

                for (int j = row.FirstCellNum; j < cellCount; j++)
                {
                    if (object.Equals(null, row.GetCell(j)))
                        continue;
                    dataRow[j] = row.GetCell(j).ToString();
                }
                table.Rows.Add(dataRow);
            }

            excelFileStream.Close();
            return table;
        }
    }
}
