﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace uni2uni.com.Utility
{
    /// <summary>
    /// memcache配置类
    /// </summary>
    public class MemcachedSetting : ConfigurationSection
    {
        [ConfigurationProperty("ExpireTime")]
        public string ExpireTime
        {
            get { return (string)this["ExpireTime"]; }
            set { this["ExpireTime"] = value; }
        }

        [ConfigurationProperty("DomainName")]
        public string DomainName
        {
            get { return (string)this["DomainName"]; }
            set { this["DomainName"] = value; }
        }

        [ConfigurationProperty("ServerNodes")]
        public string ServerNodes
        {
            get { return (string)this["ServerNodes"]; }
            set { this["ServerNodes"] = value; }
        }
    }   
}
