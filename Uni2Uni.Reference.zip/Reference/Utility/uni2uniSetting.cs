﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Configuration;

namespace uni2uni.com.Utility
{
    public class uni2uniSetting : ConfigurationSection
    {
        [ConfigurationProperty("siteName")]
        public SitName SiteName
        {
            get { return (SitName)this["siteName"]; }
            set { this["siteName"] = value; }
        }
    }

    public class SitName : ConfigurationElement
    {
        [ConfigurationProperty("DAL", IsRequired = true)]
        public string DAL
        {
            get { return (string)this["DAL"]; }
            set { this["DAL"] = value; }
        }

        [ConfigurationProperty("serviceBLL", IsRequired = true)]
        public string serviceBLL
        {
            get { return (string)this["serviceBLL"]; }
            set { this["serviceBLL"] = value; }
        }

        [ConfigurationProperty("Manage", IsRequired = true)]
        public string Manage
        {
            get { return (string)this["Manage"]; }
            set { this["Manage"] = value; }
        }

        [ConfigurationProperty("userBLL", IsRequired = true)]
        public string userBLL
        {
            get { return (string)this["userBLL"]; }
            set { this["userBLL"] = value; }
        }

        [ConfigurationProperty("infoBLL", IsRequired = true)]
        public string infoBLL
        {
            get { return (string)this["infoBLL"]; }
            set { this["infoBLL"] = value; }
        }

        [ConfigurationProperty("logBLL", IsRequired = true)]
        public string logBLL
        {
            get { return (string)this["logBLL"]; }
            set { this["logBLL"] = value; }
        }

        [ConfigurationProperty("commonBLL", IsRequired = true)]
        public string commonBLL
        {
            get { return (string)this["commonBLL"]; }
            set { this["commonBLL"] = value; }
        }

        [ConfigurationProperty("orderBLL", IsRequired = true)]
        public string orderBLL
        {
            get { return (string)this["orderBLL"]; }
            set { this["orderBLL"] = value; }
        }

        [ConfigurationProperty("cmsBLL", IsRequired = true)]
        public string cmsBLL
        {
            get { return (string)this["cmsBLL"]; }
            set { this["cmsBLL"] = value; }
        }


        [ConfigurationProperty("goodsInfoBLL", IsRequired = true)]
        public string goodsInfoBLL
        {
            get { return (string)this["goodsInfoBLL"]; }
            set { this["goodsInfoBLL"] = value; }
        }


        [ConfigurationProperty("baibianBLL", IsRequired = true)]
        public string baibianBLL
        {
            get { return (string)this["baibianBLL"]; }
            set { this["baibianBLL"] = value; }
        }

        [ConfigurationProperty("calculateChargeBLL", IsRequired = true)]
        public string calculateChargeBLL
        {
            get { return (string)this["calculateChargeBLL"]; }
            set { this["calculateChargeBLL"] = value; }
        }

        [ConfigurationProperty("NCRBLL", IsRequired = true)]
        public string NCRBLL
        {
            get { return (string)this["NCRBLL"]; }
            set { this["NCRBLL"] = value; }
        }

        [ConfigurationProperty("NCRDAL", IsRequired = true)]
        public string NCRDAL
        {
            get { return (string)this["NCRDAL"]; }
            set { this["NCRDAL"] = value; }
        }

    }
}
