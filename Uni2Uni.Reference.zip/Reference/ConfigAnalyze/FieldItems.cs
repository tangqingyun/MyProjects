﻿using System;
using System.Collections.Generic;
using System.Text;

namespace uni2uni.com.ConfigAnalyze
{

    public class FieldItems
    {
        public string ItemName { get; set; }

        public object ItemValue { get; set; }

        public FieldItems(string ItemName, object ItemValue)
        {
            this.ItemName = ItemName;
            this.ItemValue = ItemValue;
        }

        public static IList<FieldItems> GetItemList(string Items, ref string SelectedStr)
        {
            IList<FieldItems> iList = new List<FieldItems>();
            if (!string.IsNullOrEmpty(Items) && Items.Contains("@"))
            {
                string[] arrItemAndSelected = Items.Split('@');
                SelectedStr = arrItemAndSelected[1];

                if (arrItemAndSelected.Length == 2)
                {
                    if (!string.IsNullOrEmpty(arrItemAndSelected[0]) && arrItemAndSelected[0].Contains("$"))
                    {
                        string[] ArrItem = arrItemAndSelected[0].Split('$');
                        string[] SingleItem = null;
                        for (int i = 0; i < ArrItem.Length; i++)
                        {
                            SingleItem = ArrItem[i].Split('|');
                            if (SingleItem.Length == 2) iList.Add(new FieldItems(SingleItem[0], Convert.ChangeType(SingleItem[1], ((TypeCode)Enum.Parse(typeof(TypeCode), "Object")))));
                        }
                    }
                }
            }
            return iList;
        }
    }
}
