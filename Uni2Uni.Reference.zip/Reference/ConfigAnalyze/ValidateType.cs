﻿using System;
using System.Collections.Generic;
using System.Text;

namespace uni2uni.com.ConfigAnalyze
{
    public enum ValidateType
    {
        Null = 0,
        Email
    }
}
