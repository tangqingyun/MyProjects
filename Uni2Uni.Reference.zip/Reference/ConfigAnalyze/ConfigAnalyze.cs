﻿using System;
using System.Collections.Generic;
using uni2uni.com.Framework.Common;
using System.Web.UI;
using System.Xml;

namespace uni2uni.com.ConfigAnalyze
{

    public class ConfigAnalyze
    {
        #region 属性
        private static ConfigAnalyze configAnalyzeInstance = null;

        XmlHelper xmlHelper = new XmlHelper();
        IList<Field> iList = new List<Field>();
        string[] SearchStrings = new string[]{"\"\"\"","[[[","]]]","{{{","}}}"};
        string[] ReplaceStrings = new string[] { "","[","]","{","}"};
        #endregion

        #region 构造函数


        private ConfigAnalyze():this(null)
        {
        }

        private ConfigAnalyze(string ConfigName)
        {
            if (string.IsNullOrEmpty(ConfigName)) ConfigName = "XmlConfig";
            string FilePath = System.Configuration.ConfigurationSettings.AppSettings[ConfigName].ToString();
            //string strPath = HttpContext.Current.Server.MapPath(FilePath);
            xmlHelper.XmlDoc = CacheHelper.Get(ConfigName) as XmlDocument;
            if (xmlHelper.XmlDoc == null)
            {
                xmlHelper.XmlDoc = new XmlDocument();
                xmlHelper.Load(FilePath);
                CacheHelper.Insert(ConfigName, xmlHelper.XmlDoc, CacheHelper.DayFactor * 5);
            }
        }
        #endregion

        #region 实例化

        public static ConfigAnalyze Instance
        {
            get 
            {
                return ConfigInstance();
            }
        }

        public static ConfigAnalyze ConfigInstance()
        {
            return ConfigInstance(null);
        }

        public static ConfigAnalyze ConfigInstance(string ConfigName)
        {
            configAnalyzeInstance = new ConfigAnalyze(ConfigName);
            return configAnalyzeInstance;
        }
        #endregion

        #region public method
        /// <summary>
        /// 取xml配置文件某个对象ID的节点
        /// </summary>
        /// <param name="ServiceID"></param>
        /// <returns></returns>
        public IList<Field> GetFields(string ObjectID)
        {
            iList = new List<Field>();
            XmlNodeList xmlNodeList = xmlHelper.GetSectionList("XmlObject/Object");

            foreach (XmlNode xmlNode in xmlNodeList)
            {
                if (xmlNode.Attributes["ID"].Value == ObjectID.ToString())
                {
                    XmlNodeList xmlNodeField = xmlNode.SelectNodes("Field");
                    foreach (XmlNode xmlNodeSingleField in xmlNodeField)
                    {
                        iList.Add(ReflectHelper.GetEntityByXmlAttributeCollection<Field>(xmlNodeSingleField.Attributes));
                    }
                }
            }
            return iList;
        }
        #endregion

        /// <summary>
        /// LoadControl
        /// </summary>
        /// <param name="iList"></param>
        /// <param name="LoadCtl"></param>
        public void LoadControl(IList<Field> iList, Control LoadCtl)
        {
            if (iList != null && iList.Count > 0)
            {
                foreach (Field field in iList)
                {
                    LoadControlsFactory.GetInstance(field.Control).AddFormCtl(field, ref LoadCtl);
                }
            }
        }

        /// <summary>
        /// LoadControl
        /// </summary>
        /// <param name="iList">iList</param>
        /// <param name="LoadCtl">LoadCtl</param>
        /// <param name="TagName">最外层标签TagName</param>
        /// <param name="textTagName">文本外部标签的TagName</param>
        /// <param name="textAttributes">文本外部标签的属性集合</param>
        /// <param name="controlTagName">控件外部标签的TagName</param>
        /// <param name="controlAttributes">控件外部标签的属性集合</param>
        public void LoadControl(IList<Field> iList, Control LoadCtl, string TagName, string textTagName, IDictionary<string, string> textAttributes, string controlTagName, IDictionary<string, string> controlAttributes)
        {
            if (iList != null && iList.Count > 0)
            {
                foreach (Field field in iList)
                {
                    LoadControlsFactory.GetInstance(field.Control).AddFormCtl(field, ref LoadCtl, TagName, textTagName, textAttributes, controlTagName, controlAttributes);
                }
            }
        }


        public IList<Field> LoadFieldNonceValue(IList<Field> iList, string SerializationStr)
        {
            if (iList != null && iList.Count > 0 && !string.IsNullOrEmpty(SerializationStr))
            {
                SerializationStr = ReplaceChars(SerializationStr,this.SearchStrings,this.ReplaceStrings);
                string[] arrField = SerializationStr.Split(new string[] {",,,"},StringSplitOptions.RemoveEmptyEntries);
                string[] SingleField = null;
                foreach (Field field in iList)
                {
                    foreach (string strField in arrField)
                    {
                        SingleField = strField.Split(new string[] { ":::" },StringSplitOptions.RemoveEmptyEntries);
                        if (SingleField.Length == 2)
                        {
                            if (field.Key.ToLower() == SingleField[0].ToLower())
                            {
                                field.NonceValue = SingleField[1];
                                break;
                            }
                        }
                    }
                }
            }
            return iList;
        }

        /// <summary>
        /// Replace Char array
        /// </summary>
        /// <param name="SourceString">Source String</param>
        /// <param name="SearchStrings">Search String Array</param>
        /// <param name="ReplaceStrings">Replace String Array</param>
        /// <returns>After the replacement string</returns>
        public static string ReplaceChars(string SourceString, string[] SearchStrings, string[] ReplaceStrings)
        {
            if (!string.IsNullOrEmpty(SourceString) && SearchStrings.Length > 0 && ReplaceStrings.Length > 0 && SearchStrings.Length == ReplaceStrings.Length)
            {
                for (int i = 0; i < SearchStrings.Length; i++)
                {
                    SourceString = SourceString.Replace(SearchStrings[i], ReplaceStrings[i]);
                }
                return SourceString;
            }
            else
            {
                return null;
            }
        }
    }

}
