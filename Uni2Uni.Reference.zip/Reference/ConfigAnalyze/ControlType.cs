﻿using System;
using System.Collections.Generic;
using System.Text;

namespace uni2uni.com.ConfigAnalyze
{
    public enum ControlType
    {
        Null = 0,
        Text,
        Radio,
        Select,
        CheckBox,
        Textarea

    }
}
