﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace uni2uni.com.ConfigAnalyze
{

    public class LoadControlsFactory
    {
        public static LoadControls GetInstance(ControlType controlType)
        {
            LoadControls loadCtls = null;
            switch (controlType)
            {
                case ControlType.Text:
                    loadCtls = new LoadText();
                    break;
                case ControlType.Radio:
                    loadCtls = new LoadRadio();
                    break;
                case ControlType.CheckBox:
                    loadCtls = new LoadCheckBox();
                    break;
                case ControlType.Select:
                    loadCtls = new LoadSelect();
                    break;
                case ControlType.Textarea:
                    loadCtls = new LoadTextarea();
                    break;
                default:
                    break;
            }
            return loadCtls;
        }
    }

    public abstract class LoadControls
    {
        public Field field { get; set; }

        public string SelectedStr = string.Empty;

        public IList<FieldItems> ItemList = null;
        public Control ctl = null;
        HtmlGenericControl DivCtl = null;
        Literal Ltl = null;

        public LoadControls()
        {
            SelectedStr = string.Empty;
            ctl = new HtmlGenericControl();
            DivCtl = new HtmlGenericControl();
            Ltl = new Literal();
        }

        public virtual void AddFormCtl(Field field, ref Control LoadCtl)
        {
            this.field = field;
            DivCtl.TagName = "div";
            Ltl.Text = field.Show;
            ItemList = FieldItems.GetItemList(field.Items, ref SelectedStr);

            ToLoadControl(field);

            DivCtl.Controls.Add(Ltl);
            DivCtl.Controls.Add(ctl);
            LoadCtl.Controls.Add(DivCtl);
        }

        public virtual void AddFormCtl(Field field, ref Control LoadCtl, string TagName,string textTagName,IDictionary<string,string> textAttributes,string controlTagName,IDictionary<string,string> controlAttributes)
        {
            this.field = field;
            DivCtl.TagName = TagName;//<li>
            HtmlGenericControl divText = new HtmlGenericControl(); ;//text 外的 div 
            HtmlGenericControl divControl = new HtmlGenericControl(); ;//contro l外的 div 
            divText.TagName = textTagName;
            divControl.TagName = controlTagName;
            if (textAttributes != null && textAttributes.Count > 0)
            {
                foreach (KeyValuePair<string, string> Attribute in textAttributes)
                {
                    divText.Attributes.Add(Attribute.Key, Attribute.Value);
                }
            }
            if (controlAttributes != null && controlAttributes.Count > 0)
            {
                foreach (KeyValuePair<string, string> Attribute in controlAttributes)
                {
                    divControl.Attributes.Add(Attribute.Key, Attribute.Value);
                }
            }

            Ltl.Text = field.Show;

            ItemList = FieldItems.GetItemList(field.Items, ref SelectedStr);

            ToLoadControl(field);

            divText.Controls.Add(Ltl);
            divControl.Controls.Add(ctl);

            DivCtl.Controls.Add(divText);
            DivCtl.Controls.Add(divControl);

            LoadCtl.Controls.Add(DivCtl);
        }

        public abstract void ToLoadControl(Field field);
    }

    public class LoadText : LoadControls
    {
        public override void ToLoadControl(Field field)
        {
            HtmlInputText InputText = new HtmlInputText();
            InputText.ID = field.Key;
            if (!string.IsNullOrEmpty(field.NonceValue)) InputText.Value = field.NonceValue;
            this.ctl.Controls.Add(InputText);
        }
    }

    public class LoadRadio : LoadControls
    {
        public override void ToLoadControl(Field field)
        {
            HtmlInputRadioButton radioBtn = new HtmlInputRadioButton();
            HtmlGenericControl ShowDivCtl = new HtmlGenericControl();
            for (int i = 0; i < ItemList.Count; i++)
            {
                ShowDivCtl = new HtmlGenericControl();
                radioBtn = new HtmlInputRadioButton();
                ShowDivCtl.InnerText = ItemList[i].ItemName;
                radioBtn.Value = ItemList[i].ItemValue.ToString();
                radioBtn.ID = field.Key + "_" + i.ToString();
                radioBtn.Name = field.Key;
                string LoadValue = field.NonceValue;
                if (string.IsNullOrEmpty(field.NonceValue)) LoadValue = this.SelectedStr;
                if (LoadValue == ItemList[i].ItemValue.ToString()) radioBtn.Checked = true;
                this.ctl.Controls.Add(ShowDivCtl);
                this.ctl.Controls.Add(radioBtn);
            }
        }
    }

    public class LoadCheckBox : LoadControls
    {
        public override void ToLoadControl(Field field)
        {
            HtmlInputCheckBox CheckBoxBtn = new HtmlInputCheckBox();
            HtmlGenericControl ShowDivCtl = new HtmlGenericControl();
            for (int i = 0; i < ItemList.Count; i++)
            {
                ShowDivCtl = new HtmlGenericControl();
                CheckBoxBtn = new HtmlInputCheckBox();
                ShowDivCtl.InnerText = ItemList[i].ItemName;
                CheckBoxBtn.Value = ItemList[i].ItemValue.ToString();
                CheckBoxBtn.ID = field.Key + "_" + i.ToString();

                string LoadValue = field.NonceValue;
                if (string.IsNullOrEmpty(field.NonceValue) && !string.IsNullOrEmpty(this.SelectedStr)) LoadValue = this.SelectedStr;

                if (!string.IsNullOrEmpty(LoadValue))
                {
                    string[] TempFieldNonceValue = LoadValue.Split(',');
                    foreach (string TempArrValue in TempFieldNonceValue)
                    {
                        if (TempArrValue == ItemList[i].ItemValue.ToString())
                        {
                            CheckBoxBtn.Checked = true;
                            break;
                        }
                    }
                }

                this.ctl.Controls.Add(ShowDivCtl);
                this.ctl.Controls.Add(CheckBoxBtn);
            }
        }
    }

    public class LoadSelect : LoadControls
    {
        public override void ToLoadControl(Field field)
        {
            HtmlSelect SelectList = new HtmlSelect();
            SelectList.ID = field.Key;
            SelectList.DataSource = ItemList;
            SelectList.DataTextField = "ItemName";
            SelectList.DataValueField = "ItemValue";
            string LoadValue = field.NonceValue;
            if (string.IsNullOrEmpty(field.NonceValue)) LoadValue = this.SelectedStr;
            for (int i = 0; i < ItemList.Count; i++)
            {
                if (LoadValue == ItemList[i].ItemValue.ToString())
                {
                    SelectList.SelectedIndex = i;
                    break;
                }
            }
            
            SelectList.DataBind();
            this.ctl.Controls.Add(SelectList);
        }
    }

    public class LoadTextarea : LoadControls
    {
        public override void ToLoadControl(Field field)
        {
            HtmlTextArea TextArea = new HtmlTextArea();
            TextArea.Value = field.Items;
            TextArea.ID = field.Key;
            TextArea.Attributes.Add("style", "height:300px;width:500px;");
            if (!string.IsNullOrEmpty(field.NonceValue)) TextArea.Value = field.NonceValue;
            this.ctl.Controls.Add(TextArea);
        }
    }
}
