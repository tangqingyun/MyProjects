﻿using System;
using System.Collections.Generic;
using System.Text;

namespace uni2uni.com.ConfigAnalyze
{

    public class Field
    {
        private string _ZhName;
        /// <summary>
        /// 中文名称
        /// </summary>
        public string ZhName
        {
            get { return _ZhName; }
            set { _ZhName = value; }
        }

        private string _Show;
        /// <summary>
        /// 显示名称
        /// </summary>
        public string Show
        {
            get { return _Show; }
            set { _Show = value; }
        }

        private string _Key;
        /// <summary>
        /// 字段名
        /// </summary>
        public string Key
        {
            get { return _Key; }
            set { _Key = value; }
        }

        private TypeCode _DataType;
        /// <summary>
        /// 数据类型
        /// </summary>
        public TypeCode DataType
        {
            get { return _DataType; }
            set { _DataType = value; }
        }

        private ControlType _Control;
        /// <summary>
        /// 控件类型
        /// </summary>
        public ControlType Control
        {
            get { return _Control; }
            set { _Control = value; }
        }

        private string _Items;
        /// <summary>
        /// 值<集合>
        /// </summary>
        public string Items
        {
            get { return _Items; }
            set { _Items = value; }
        }

        private bool _Segmentation;
        /// <summary>
        /// 分词
        /// </summary>
        public bool Segmentation
        {
            get { return _Segmentation; }
            set { _Segmentation = value; }
        }

        private int _Boost;
        /// <summary>
        /// 权重
        /// </summary>
        public int Boost
        {
            get { return _Boost; }
            set { _Boost = value; }
        }

        private bool _IsSearch;
        /// <summary>
        /// 是否搜索条件
        /// </summary>
        public bool IsSearch
        {
            get { return _IsSearch; }
            set { _IsSearch = value; }
        }

        private ValidateType _Validate;
        /// <summary>
        /// 验证
        /// </summary>
        public ValidateType Validate
        {
            get { return _Validate; }
            set { _Validate = value; }
        }

        private string _NonceValue;
        /// <summary>
        /// 当前字段值
        /// </summary>
        public string NonceValue
        {
            get { return _NonceValue; }
            set { _NonceValue = value; }
        }

        private bool _IsIndex;
        /// <summary>
        /// 是否分词
        /// </summary>
        public bool IsIndex
        {
            get { return _IsIndex; }
            set { _IsIndex = value; }
        }

    }
}
